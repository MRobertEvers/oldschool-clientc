-- Royal Trouble (Quest Helper helpers/quests/royaltrouble/RoyalTrouble.java), authored as an
-- 8-leg relay (docs/quest_authoring/relay.md). Notes for the legs: docs/quests/ladders/royaltrouble.notes.md
return {
    id = "royaltrouble",
    fixture = "fresh_lumbridge.ini",
    setup = {
        "::clearinv",
        "::setlevel agility 40", -- guide requirement: 40 Agility (royal_royals.rs2:79 ~royaltrouble_meets_requirements)
        "::setlevel slayer 40",  -- guide requirement: 40 Slayer (same check; the snake needs it to attack)
        "::complete quest_heroes", -- guide requirement chain (Throne of Miscellania needs Heroes' Quest): misc_door_guard.rs2:10 gates the throne-room door on %varp188_heroquest = ^hero_complete
        "::royaltrouble",        -- royal_debug.rs2:35 stages Throne of Miscellania done + resets every Royal Trouble var, stands the player at the castle
    },
    bind = {
        varp = "varb2140_royal_quest",
        constants = { not_started = 0, chose_partner = 10, investigating = 20, complete = 30 },
        row = "quest_royaltrouble",
        display = "Royal Trouble",
        points = 1,
    },

    legs = {
        {
            name = "castle",
            run = function(t)
                t.ticks(3)
                t.expect("quest.stage.not_started", t.quest.expect_stage("not_started"))

                -- LEG 1 BEGIN: travelToMisc
                -- GUIDE-GAP: travelToMisc -- the pack has no boat or fairy ring from Rellekka to Miscellania (viking_sailor.rs2:1)
                -- (quest_viking/scripts/viking_sailor.rs2:1 only chats; the CIP ring is a house ring, poh_fairy_ring.rs2:72), so the
                -- sailor is talked to for real and the crossing is plain travel.
                t.exec("goto-travelToMisc", t.player.goto_tile, 2629, 3693, 0)
                t.exec("travelToMisc", t.player.talk_to, "viking_sailor", 1)
                t.exec("travelToMisc-dialog", t.chat.play, {
                    "player:Hiya.",
                    "npc:Don't talk to me outerlander",
                    "end",
                })
                t.exec("goto-misc-dock", t.player.goto_tile, 2506, 3853, 0)
                t.exec("castle-door-ground", t.player.click_loc, "castledoor", 1, { at = { 2506, 3851 } })
                t.ticks(3)

                -- goUpToGhrim / talkToGhrim
                t.exec("goUpToGhrim", t.player.click_loc, "spiralstairs_wooden", 1)
                t.ticks(3)
                t.check("goUpToGhrim-level", select(2, t.world.level()) == 1, "level " .. tostring(select(2, t.world.level())))
                t.exec("castle-door-upper", t.player.click_loc, "castledoor", 1, { at = { 2506, 3851 } })
                t.ticks(3)
                local door_r, door_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                local _, door_tile = t.world.tile()
                t.check("throneroom-door", door_tile ~= nil and door_tile.z >= 3857,
                    "click_loc -> " .. tostring(door_r) .. " (" .. tostring(door_d):sub(1, 80) .. "); tile after " .. tostring(door_tile and (door_tile.x .. "," .. door_tile.z)))
                t.ticks(3)
                t.exec("talkToGhrim", t.player.talk_to, "misc_advisor_ghrim", 1)
                t.exec("talkToGhrim-dialog", t.chat.play, {
                    "npc:Greetings, Your Royal Highness",
                    "choose:Has anything been happening in the kingdom recently?",
                    "player:Has anything been happening",
                    "npc:Interesting that you should ask",
                    "npc:the people are worried",
                    "npc:King Vargas has found himself",
                    "npc:Unfortunately, we still have not",
                    "player:So, what has he been doing",
                    "npc:He has been trying to rule",
                    "npc:The two of them have been writing",
                    "player:I see.",
                    "npc:Your Royal Highness, I suggest",
                    "choose:Yes.",
                    "player:Very well",
                    "npc:Thank you, Your Royal Highness",
                    "npc:I suggest you talk to the prince",
                })
                t.ticks(2)
                t.expect("quest.stage.chose_partner", t.quest.expect_stage("chose_partner"))

                -- goUpToPartner / talkToPartner: the guide sends the player up the north stairs to the Princess
                local back_r, back_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                local _, back_tile = t.world.tile()
                t.check("throneroom-door-out", back_tile ~= nil and back_tile.z <= 3857,
                    "click_loc -> " .. tostring(back_r) .. "; tile after " .. tostring(back_tile and (back_tile.x .. "," .. back_tile.z)))
                t.exec("goDown-afterGhrim", t.player.click_loc, "spiralstairsmiddle_wooden", 3, { at = { 2505, 3848, 1 } })
                t.ticks(3)
                t.exec("goto-goUpToPartner", t.player.goto_tile, 2506, 3867, 0)
                local n_r, n_d = t.player.click_loc("castledoor", 1, { at = { 2506, 3869, 0 } })
                t.ticks(8)
                t.check("castle-door-north-ground", true, "click_loc -> " .. tostring(n_r) .. " " .. tostring(n_d):sub(1, 80))
                t.exec("goUpToPartner", t.player.click_loc, "spiralstairs_wooden", 1, { at = { 2505, 3871, 0 } })
                t.ticks(3)
                t.check("goUpToPartner-level", select(2, t.world.level()) == 1, "level " .. tostring(select(2, t.world.level())))
                local nu_r, nu_d = t.player.click_loc("castledoor", 1, { at = { 2506, 3869, 1 } })
                t.ticks(6)
                t.check("castle-door-north-upper", true, "click_loc -> " .. tostring(nu_r) .. " " .. tostring(nu_d):sub(1, 80))
                local ar_r, ar_d = t.player.click_loc("castledoor", 1, { at = { 2504, 3867, 1 } })
                t.ticks(6)
                t.check("astrid-room-door", true, "click_loc -> " .. tostring(ar_r) .. " " .. tostring(ar_d):sub(1, 80))
                t.exec("talkToPartner", t.player.talk_to, "misc_princess_astrid", 1)
                t.exec("talkToPartner-dialog", t.chat.play, {
                    "player:Good day, your Highness",
                    "npc:Good day",
                    "player:Yes, Advisor Ghrim said",
                    "npc:I'll ask Father",
                    "player:Advisor Ghrim told me",
                    "player:What has happened while",
                    "npc:It's terrible, my dear",
                    "npc:It's awful that your work",
                    "player:What do you mean, 'an accident'",
                    "npc:Well, if my father",
                    "player:What would you suggest",
                    "npc:We can't have him declaring",
                    "npc:And I could finally show",
                    "npc:Astrid, I have an even better",
                    "npc:Better than archery",
                    "npc:I think we should persuade",
                    "npc:...What are you talking about",
                    "npc:Think of the poetic irony",
                    "npc:The best part is",
                    "npc:'Today is a happy day",
                    "npc:Our national anthems",
                    "player:I'm not sure that's such a good",
                    "npc:I quite agree",
                    "npc:Perhaps it's an odd idea",
                    "player:Are you sure it'll work",
                    "npc:Of course it will",
                    "npc:Two people who start out",
                    "player:That doesn't always work",
                    "npc:But we don't have an army",
                    "npc:So, will you talk to our father",
                    "npc:I'm sure you can manage",
                    "player:I'll give it a try",
                    "npc:I'm sure you'll manage",
                })
                t.ticks(2)
                t.expect("quest.stage.investigating", t.quest.expect_stage("investigating"))

                -- goUpToVargas / talkToVargas: back down the north stairs, along the corridor, up the south stairs
                local function door(name, sym, x, z, lvl)
                    local r, d = t.player.click_loc(sym, 1, { at = { x, z, lvl } })
                    t.ticks(6)
                    t.check(name, true, "click_loc -> " .. tostring(r) .. " " .. tostring(d):sub(1, 80))
                end
                local function level_is(name, want)
                    local lv = select(2, t.world.level())
                    t.check(name, lv == want, "level " .. tostring(lv))
                end
                t.exec("goDown-afterAstrid", t.player.click_loc, "spiralstairsmiddle_wooden", 3, { at = { 2505, 3871, 1 } })
                t.ticks(3)
                level_is("goDown-afterAstrid-level", 0)
                t.exec("goto-goUpToVargas", t.player.goto_tile, 2506, 3853, 0)
                door("castle-door-south-ground", "castledoor", 2506, 3851, 0)
                t.exec("goUpToVargas", t.player.click_loc, "spiralstairs_wooden", 1, { at = { 2505, 3848, 0 } })
                t.ticks(3)
                level_is("goUpToVargas-level", 1)
                door("castle-door-south-upper", "castledoor", 2506, 3851, 1)
                local v_r, v_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                t.check("throneroom-door-vargas", true, "click_loc -> " .. tostring(v_r) .. " " .. tostring(v_d):sub(1, 80))
                t.exec("talkToVargas", t.player.talk_to, "misc_king_vargas", 1)
                t.exec("talkToVargas-dialog", t.chat.play, {
                    "player:Your Majesty.",
                    "npc:What is it? You'll have to excuse me",
                    "player:What are you busy with",
                    "npc:Affairs of state",
                    "player:I thought I was supposed",
                    "npc:Well, there's not all that much",
                    "npc:And though you do make",
                    "player:So you're still helping",
                    "npc:In a manner of speaking",
                    "player:These 'affairs of state'",
                    "player:Would these involve",
                    "npc:Not exactly",
                    "npc:Well, yes",
                    "npc:And that's the least",
                    "npc:Some of Frodi's barrels",
                    "npc:Since you're the regent",
                    "choose:Right away, your Majesty.",
                    "player:Right away",
                    "npc:I'm glad to see",
                    "npc:All you need to do",
                    "npc:It might also be useful",
                })
                t.ticks(2)
                t.check("quest.stage.misc_set_task", select(2, t.var.server("varb2141_royal_misc")) == 10,
                    "varb2141_royal_misc = " .. tostring(select(2, t.var.server("varb2141_royal_misc"))))

                -- goDownFromVargas / talkToGunnhild
                local o_r, o_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                t.check("throneroom-door-out-vargas", true, "click_loc -> " .. tostring(o_r) .. " " .. tostring(o_d):sub(1, 80))
                t.exec("goDownFromVargas", t.player.click_loc, "spiralstairsmiddle_wooden", 3, { at = { 2505, 3848, 1 } })
                t.ticks(3)
                level_is("goDownFromVargas-level", 0)
                local function tile_is(name)
                    local _, tl = t.world.tile()
                    t.check(name, true, "tile " .. tostring(tl and (tl.x .. "," .. tl.z)))
                end
                door("castle-door-south-ground-out", "castledoor", 2506, 3851, 0)
                tile_is("walk-castle-1")
                t.player.walk_to(2505, 3853, 10)
                t.ticks(6)
                door("castle-door-west-hall", "castledoor", 2504, 3853, 0)
                tile_is("walk-castle-2")
                t.player.walk_to(2504, 3860, 20)
                t.ticks(12)
                tile_is("walk-castle-3")
                door("castle-door-lobby-west", "castledoor", 2505, 3860, 0)
                tile_is("walk-castle-4")
                t.player.walk_to(2509, 3860, 10)
                t.ticks(8)
                door("castle-door-east-exit", "castledoor", 2510, 3860, 0)
                tile_is("walk-castle-5")
                t.player.walk_to(2525, 3855, 40)
                t.ticks(30)
                tile_is("walk-castle-6")
                t.exec("talkToGunnhild", t.player.talk_to, "misc_gardener", 1)
                t.exec("talkToGunnhild-dialog", t.chat.play, {
                    "npc:Good day, Your Royal Highness",
                    "player:King Vargas tells me",
                    "npc:You mean you hadn't heard",
                    "npc:You're the only person",
                })
                t.ticks(2)
                t.check("quest.stage.misc_aboutthefts", select(2, t.var.server("varb2143_royal_misc_villagers_aboutthefts")) == 1,
                    "varb2143_royal_misc_villagers_aboutthefts = " .. tostring(select(2, t.var.server("varb2143_royal_misc_villagers_aboutthefts"))))

                -- goDownFromVargas2: the guide's route to Queen Sigrid starts down the same stairs; go back up and down once
                t.exec("goto-goDownFromVargas2", t.player.goto_tile, 2506, 3853, 0)
                door("castle-door-south-ground-2", "castledoor", 2506, 3851, 0)
                t.exec("goUp-forVargas2", t.player.click_loc, "spiralstairs_wooden", 1, { at = { 2505, 3848, 0 } })
                t.ticks(3)
                level_is("goUp-forVargas2-level", 1)
                door("castle-door-south-upper-2", "castledoor", 2506, 3851, 1)
                t.exec("goDownFromVargas2", t.player.click_loc, "spiralstairsmiddle_wooden", 3, { at = { 2505, 3848, 1 } })
                t.ticks(3)
                level_is("goDownFromVargas2-level", 0)
                local _, e_tile = t.world.tile()
                local _, e_stage = t.var.server("varb2140_royal_quest")
                local _, e_misc = t.var.server("varb2141_royal_misc")
                t.check("leg.1.state", t.chat.kind() == "none", "tile " .. tostring(e_tile and (e_tile.x .. "," .. e_tile.z)) .. " level 0, varb2140_royal_quest=" .. tostring(e_stage) .. " varb2141_royal_misc=" .. tostring(e_misc) .. ", backpack empty")
                -- LEG 1 END
            end,
        },
        {
            name = "etceteria",
            run = function(t)
                -- LEG 2 BEGIN: goUpToSigrid
                local function door(name, sym, x, z, lvl)
                    local r, d = t.player.click_loc(sym, 1, { at = { x, z, lvl } })
                    t.ticks(6)
                    t.check(name, true, "click_loc -> " .. tostring(r) .. " " .. tostring(d):sub(1, 80))
                end
                local function level_is(name, want)
                    local lv = select(2, t.world.level())
                    t.check(name, lv == want, "level " .. tostring(lv))
                end
                local function stage_is(name, var, want)
                    local v = select(2, t.var.server(var))
                    t.check(name, v == want, var .. " = " .. tostring(v) .. " (want " .. tostring(want) .. ")")
                end

                -- goUpToSigrid / talkToSigrid
                t.exec("goto-goUpToSigrid", t.player.goto_tile, 2614, 3865, 0)
                t.exec("goUpToSigrid", t.player.click_loc, "spiralstairs", 1, { at = { 2613, 3867, 0 } })
                t.ticks(3)
                level_is("goUpToSigrid-level", 1)
                door("castle-door-sigrid", "castledoor", 2615, 3870, 1)
                t.exec("talkToSigrid", t.player.talk_to, "misc_queen_sigrid", 1)
                t.exec("talkToSigrid-dialog", t.chat.play, {
                    "player:Your Majesty, do you have a moment?",
                    "npc:Incompetent!",
                    "npc:Yes, what is it?",
                    "player:I hear from King Vargas",
                    "npc:Of course not!",
                    "npc:That idiot Vargas",
                    "npc:I suppose all those insults",
                    "npc:Even so, that doesn't excuse",
                    "player:What happened, your Majesty?",
                    "npc:My citizens have told me",
                    "npc:Since you're the one",
                    "choose:Of course, it's my duty.",
                    "player:Of course, it's my duty.",
                    "npc:I'm glad you understand.",
                    "npc:If you talk to the citizens",
                    "npc:I would find out for myself",
                })
                t.ticks(2)
                stage_is("quest.stage.etc_sigrid_talked", "varb2142_royal_etc", 10)

                -- goDownFromSigridToMatilda / talkToMatilda
                t.exec("goDownFromSigridToMatilda", t.player.click_loc, "spiralstairstop", 1)
                t.ticks(3)
                level_is("goDownFromSigridToMatilda-level", 0)
                door("castle-door-matilda", "castledoor", 2613, 3864, 0)
                do local _, pt = t.world.tile(); local _, nr = t.npc.by_symbol("misc_etc_woman_2"); t.check("probe-1", true, "player " .. tostring(pt and (pt.x..","..pt.z)) .. " matilda " .. tostring(nr and (nr.x..","..nr.z))) end
                t.player.walk_to(2613, 3862, 15)
                t.ticks(3)
                do local _, pt = t.world.tile(); t.check("probe-2", true, "player " .. tostring(pt and (pt.x..","..pt.z))) end
                door("matilda-house-door", "misc_viking_abode_door_low", 2603, 3874, 0)
                t.player.walk_near(t.player.by_symbol("npc", "misc_etc_woman_2"), 20)
                t.ticks(2)
                t.exec("talkToMatilda", t.player.talk_to, "misc_etc_woman_2", 1)
                t.exec("talkToMatilda-dialog", t.chat.play, {
                    "player:Excuse me...",
                    "npc:Yes?",
                    "player:Queen Sigrid tells me",
                    "npc:You haven't heard about that",
                    "npc:I'm surprised.",
                    "npc:Well, Miscellanian soldiers came",
                    "npc:When I told them to leave",
                    "npc:It was a wonderful hat",
                    "npc:Could you please get it back",
                    "player:I'll see what I can do.",
                })
                t.ticks(2)
                stage_is("quest.stage.etc_aboutthefts", "varb2144_royal_etc_villagers_aboutthefts", 1)

                -- getCoalOrPickaxe: the guide's bank visit (Etceteria's booth); nothing is banked on a fresh
                -- account and the pickaxe is picked up in the dungeon (royal_dungeon.rs2:195), so the booth is opened and closed
                t.exec("goto-getCoalOrPickaxe", t.player.goto_tile, 2612, 3898, 0)
                t.exec("getCoalOrPickaxe", t.player.click_loc, "dwarf_keldagrim_bankbooth", 2, { at = { 2612, 3900, 0 } })
                t.ticks(4)
                t.check("getCoalOrPickaxe-open", t.ui.is_modal() == true, "bank booth op2 -> modal open=" .. tostring(t.ui.is_modal()))
                t.key("escape")
                t.ticks(2)

                -- goDownFromSigridToVargas: the guide's second descent of Sigrid's stairs (back up once, then down)
                t.exec("goto-goDownFromSigridToVargas", t.player.goto_tile, 2614, 3865, 0)
                t.exec("goUp-forSigrid2", t.player.click_loc, "spiralstairs", 1, { at = { 2613, 3867, 0 } })
                t.ticks(3)
                level_is("goUp-forSigrid2-level", 1)
                t.exec("goDownFromSigridToVargas", t.player.click_loc, "spiralstairstop", 1)
                t.ticks(3)
                level_is("goDownFromSigridToVargas-level", 0)

                -- goBackUpToVargasFromSigrid / talkToVargasAfterSigrid
                t.exec("goto-goBackUpToVargasFromSigrid", t.player.goto_tile, 2506, 3853, 0)
                door("castle-door-south-ground-3", "castledoor", 2506, 3851, 0)
                t.exec("goBackUpToVargasFromSigrid", t.player.click_loc, "spiralstairs_wooden", 1, { at = { 2505, 3848, 0 } })
                t.ticks(3)
                level_is("goBackUpToVargasFromSigrid-level", 1)
                door("castle-door-south-upper-3", "castledoor", 2506, 3851, 1)
                local v_r, v_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                t.check("throneroom-door-vargas-2", true, "click_loc -> " .. tostring(v_r) .. " " .. tostring(v_d):sub(1, 80))
                t.exec("talkToVargasAfterSigrid", t.player.talk_to, "misc_king_vargas", 1)
                t.exec("talkToVargasAfterSigrid-dialog", t.chat.play, {
                    "player:Your Majesty.",
                    "player:I've spoken to the Miscellanian citizens, and also",
                    "npc:What did they say?",
                    "player:The Miscellanian citizens said",
                    "npc:What?",
                    "npc:I see. Sigrid thinks",
                    "player:...and the Etceterian citizens",
                    "npc:And she's even started",
                    "player:Your Majesty...",
                    "npc:Lying to her own people",
                    "npc:Which makes it all the worse",
                    "player:I'm not sure that would work",
                    "npc:Perhaps not",
                    "npc:In any case",
                    "npc:Ask Advisor Ghrim",
                    "npc:He's a capable advisor",
                    "player:I'll do that, your Majesty.",
                })
                t.ticks(2)
                stage_is("quest.stage.misc_reported", "varb2141_royal_misc", 20)

                -- goUpToGhrim2 / talkToGhrim2: down the stairs and up again, as the guide routes it
                local o_r, o_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                t.check("throneroom-door-out-2", true, "click_loc -> " .. tostring(o_r) .. " " .. tostring(o_d):sub(1, 80))
                t.exec("goDown-beforeGhrim2", t.player.click_loc, "spiralstairsmiddle_wooden", 3, { at = { 2505, 3848, 1 } })
                t.ticks(3)
                level_is("goDown-beforeGhrim2-level", 0)
                door("castle-door-south-ground-4", "castledoor", 2506, 3851, 0)
                t.exec("goUpToGhrim2", t.player.click_loc, "spiralstairs_wooden", 1, { at = { 2505, 3848, 0 } })
                t.ticks(3)
                level_is("goUpToGhrim2-level", 1)
                door("castle-door-south-upper-4", "castledoor", 2506, 3851, 1)
                local g_r, g_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                t.check("throneroom-door-ghrim-2", true, "click_loc -> " .. tostring(g_r) .. " " .. tostring(g_d):sub(1, 80))
                t.exec("talkToGhrim2", t.player.talk_to, "misc_advisor_ghrim", 1)
                t.exec("talkToGhrim2-dialog", t.chat.play, {
                    "npc:Greetings, Your Royal Highness",
                    "choose:King Vargas asked me to talk to you.",
                    "player:King Vargas asked me to talk to you.",
                    "player:He said you might know",
                    "npc:I'm not sure what you're implying",
                    "player:Er... that you could advise",
                    "npc:Ah, of course.",
                    "npc:Assuming that nobody",
                    "npc:it is of course likely",
                    "npc:The sailor who brought you",
                    "npc:I suggest you ask him",
                })
                t.ticks(2)
                stage_is("quest.stage.misc_ghrim_talked", "varb2141_royal_misc", 30)
                local _, e_tile = t.world.tile()
                local _, e_stage = t.var.server("varb2140_royal_quest")
                local _, e_misc = t.var.server("varb2141_royal_misc")
                t.check("leg.2.end", t.chat.kind() == "none", "tile " .. tostring(e_tile and (e_tile.x .. "," .. e_tile.z)) .. " level " .. tostring(select(2, t.world.level())) .. ", varb2140_royal_quest=" .. tostring(e_stage) .. " varb2141_royal_misc=" .. tostring(e_misc) .. " (Ghrim sent the player to the sailor), backpack empty")
                -- LEG 2 END
            end,
        },
    },
}
