## leg 1 (UNFINISHED, gave_up; see leg1.progress.md)
- Setup gives: agility 40, slayer 40, ::complete quest_heroes (throne-room door gate), ::royaltrouble (stages Misc done, stands at 2510,3846,0).
- Passes: travelToMisc (GUIDE-GAP no boat), goUpToGhrim, talkToGhrim (stage 10), goUpToPartner, talkToPartner (stage 20), goUpToVargas, talkToVargas (varb2141_royal_misc=10).
- Not done: talkToGunnhild (route out of the castle's ground floor), goDownFromVargas2.
- Castle doors must be clicked open (castledoor); coordinates in leg1.progress.md.

## leg 1 (DONE, final; supersedes the UNFINISHED block above)
- Ends at 2505,3850,0 (the pocket south of the castle's south stair door), quest varb2140_royal_quest=20, varb2141_royal_misc=10 (task set, Gunnhild thefts told); backpack empty, nothing worn.
- Setup: agility 40, slayer 40, ::complete quest_heroes (throne-room door), ::royaltrouble.
- Castle doors (castledoor) are clicked with click_loc(..., {at={x,z,level}}): ground 2506,3851 / 2504,3853 / 2505,3860 / 2510,3860; throne door misc_ulby_throneroomdoor 2506,3857 L1. Stairs at 2505,3848.
- Route out to Gunnhild (2527,3855): door 2506,3851 -> corridor -> door 2504,3853 -> west hall -> 2504,3860 -> door 2505,3860 -> lobby -> door 2510,3860 -> east.
- Sailor in Rellekka is chat only (GUIDE-GAP no boat); crossing is goto_tile.
