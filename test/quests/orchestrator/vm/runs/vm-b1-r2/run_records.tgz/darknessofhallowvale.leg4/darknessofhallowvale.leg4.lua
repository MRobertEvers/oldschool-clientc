local LEG_FROM = 4
local LEG_ONLY = false
local LEG_TILE = { 3638, 3251, 0 }
local QUEST = (function()
-- Darkness of Hallowvale -- driven as a 6-leg relay (docs/quest_authoring/relay.md).
-- Leg 1 = guide steps 1-11 (climbOverBrokenWall .. talkToCitizen).
-- Notes: docs/quests/ladders/darknessofhallowvale.notes.md.
-- Readings for row details (file-level helpers, no state shared between legs).
local function at(t)
    local _, p = t.world.tile()
    return tostring(p.x) .. "," .. tostring(p.z) .. "," .. tostring(p.level)
end
local function said(t, n)
    local _, l = t.msg.last(n)
    local o = {}
    for i = 1, #l do
        local m = l[i]
        o[#o + 1] = type(m) == "table" and tostring(m.text or m.message or m[1]) or tostring(m)
    end
    return table.concat(o, " | ")
end

return {
    id = "darknessofhallowvale",
    fixture = "fresh_lumbridge.ini",
    max_frames = 240000, -- six legs of ticks add up past the 2,000-tick default budget (relay.md)
    setup = {
        "::clearinv",
        "::complete quest_priestinperil", -- guide prerequisite chain: Priest in Peril (In Aid of the Myreque needs it; Drezel's cellar shell is drawn only for varp302 8..61)
        "::complete quest_inaidofthemyreque", -- guide prerequisite: In Aid of the Myreque
        "::darknessofhallowvale", -- stages the quest at the top (doh_shared.rs2:410), never past it
        "::give hammer 1", -- guide: usePlankOnBoat items (Hammer)
        "::give woodplank 2", -- guide: usePlankOnBoat/usePlankOnChute items (Plank, one each)
        "::give knife 1", -- guide: travelToMyrequeBase items (Knife, for the hideout wall)
        "::give nails 8", -- guide: usePlankOnBoat/usePlankOnChute items (four nails each)
        "::setlevel construction 5", -- requirement: Construction 5
        "::setlevel mining 20", -- requirement: Mining 20
        "::setlevel thieving 22", -- requirement: Thieving 22
        "::setlevel agility 26", -- requirement: Agility 26
        "::setlevel crafting 32", -- requirement: Crafting 32
        "::setlevel magic 33", -- requirement: Magic 33
        "::setlevel strength 40", -- requirement: Strength 40
    },
    bind = {
        varp = "varb2573_myq3_main_quest",
        constants = {
            not_started = 0,
            started = 10,
            boat_fixed = 20,
            chute_fixed = 30,
            arrived_wall = 40,
            floor_kicked = 50,
            ral_directions = 60,
            complete = 320,
        },
        row = "quest_darknessofhallowvale",
        display = "Darkness of Hallowvale",
        points = 2,
    },

    legs = {
        {
            name = "burgh_to_citizen",
            run = function(t)
                -- LEG 1 BEGIN: climbOverBrokenWall
                t.ticks(3)
                t.expect("quest.stage.not_started", t.quest.expect_stage("not_started"))

                -- climbOverBrokenWall: the Broken wall on the inn's north edge (doh_burgh.rs2:14)
                t.exec("goto-climbOverBrokenWall", t.player.goto_tile, 3491, 3229, 0)
                t.exec("climbOverBrokenWall", t.player.click_loc, "burgh_inn_climb_over", 1)
                t.ticks(4)
                t.check("climbOverBrokenWall.crossed", true, "tile " .. at(t) .. " messages: " .. said(t, 2))

                -- enterBurghPubBasement: Open then Climb-down the pub trapdoor (doh_burgh.rs2:36)
                t.exec("enterBurghPubBasement.open", t.player.click_loc, "burgh_inn_trapdoor_multiloc", 1)
                t.ticks(3)
                t.exec("enterBurghPubBasement", t.player.click_loc, "burgh_inn_trapdoor_multiloc", 1)
                t.ticks(6)
                t.check("enterBurghPubBasement.below", true, "tile " .. at(t) .. " messages: " .. said(t, 2))

                -- talkToVeliaf: Veliaf asks for the Meiyerditch contact (doh_burgh.rs2:101)
                t.exec("talkToVeliaf", t.player.talk_to, "myq5_veliaf_child", 1)
                t.exec("talkToVeliaf-dialog", t.chat.play, {
                    "player:Is there something I can do to help out?",
                    "npc:Actually, yes",
                    "choose:Yes.",
                    "player:Yes.",
                    "npc:Good. There's a boat",
                })
                t.ticks(2)
                t.expect("quest.stage.started", t.quest.expect_stage("started"))

                -- leavePubBasement: the ladder back up (myreque2_burgh.rs2)
                t.exec("leavePubBasement", t.player.click_loc, "burgh_inn_basement_ladderup", 1)
                t.ticks(5)
                t.check("leavePubBasement.up", true, "tile " .. at(t) .. " messages: " .. said(t, 2))

                -- back over the Broken wall (south side needs no Agility), then to the boathouse
                t.exec("leaveInn.wall", t.player.click_loc, "burgh_inn_climb_over", 1)
                t.ticks(4)
                t.check("leaveInn.outside", true, "tile " .. at(t))
                t.exec("goto-usePlankOnBoat", t.player.goto_tile, 3524, 3177, 0)

                -- usePlankOnBoat: Hammer, Plank, Nails; Yes to "Repair the boat?" (doh_burgh.rs2:179)
                t.exec("usePlankOnBoat", t.player.click_loc, "sang_boat_broken_multiloc", 1)
                t.exec("usePlankOnBoat-dialog", t.chat.play, { "choose:Yes." })
                t.ticks(4)
                t.expect("quest.stage.boat_fixed", t.quest.expect_stage("boat_fixed"))
                t.check("usePlankOnBoat.spent", true, "planks " .. tostring(select(2, t.inv.count("woodplank"))) .. " nails " .. tostring(select(2, t.inv.count("nails"))) .. " messages: " .. said(t, 2))

                -- usePlankOnChute (doh_burgh.rs2:206)
                t.exec("goto-usePlankOnChute", t.player.goto_tile, 3523, 3174, 0)
                t.exec("usePlankOnChute", t.player.click_loc, "sang_boathouse_chute_broken_multiloc", 1)
                t.exec("usePlankOnChute-dialog", t.chat.play, { "choose:Yes." })
                t.ticks(4)
                t.expect("quest.stage.chute_fixed", t.quest.expect_stage("chute_fixed"))

                -- pushBoat: the mended boat goes down the chute (doh_burgh.rs2:179)
                t.exec("goto-pushBoat", t.player.goto_tile, 3524, 3177, 0)
                t.exec("pushBoat", t.player.click_loc, "sang_boat_broken_multiloc", 1)
                t.ticks(6)
                t.check("pushBoat.pushed", true, "tile " .. at(t) .. " messages: " .. said(t, 2))

                -- boardBoat: the boat afloat (doh_burgh.rs2:230)
                t.exec("goto-boardBoat", t.player.goto_tile, 3523, 3171, 0)
                t.exec("boardBoat", t.player.click_loc, "sang_boat_water_multiloc", 1)
                t.ticks(8)
                t.expect("quest.stage.arrived_wall", t.quest.expect_stage("arrived_wall"))
                t.check("boardBoat.arrived", true, "tile " .. at(t) .. " messages: " .. said(t, 2))

                -- the deck has no way off but the rock two tiles north (doh_meiyerditch.rs2:16), then Climb-up
                t.exec("jumpBoatRock", t.player.click_loc, "sang_boat_jump_rock", 1)
                t.ticks(4)
                t.check("jumpBoatRock.on", true, "tile " .. at(t))
                t.exec("climbWallRock", t.player.click_loc, "sang_boat_wall_climb_up_rock", 1)
                t.ticks(5)
                t.check("climbWallRock.up", true, "tile " .. at(t) .. " messages: " .. said(t, 2))

                -- kickBoard: Search the marked floorboards, Yes to kick them in (doh_meiyerditch.rs2:47)
                t.exec("walk-kickBoard", t.player.goto_tile, 3590, 3173, 1)
                t.exec("kickBoard", t.player.click_loc, "meiyerditch_wall_floorboards_multi_loc", 1)
                t.exec("kickBoard-dialog", t.chat.play, { "choose:Yes." })
                t.ticks(4)
                t.expect("quest.stage.floor_kicked", t.quest.expect_stage("floor_kicked"))
                t.check("kickBoard.kicked", true, "tile " .. at(t) .. " messages: " .. said(t, 2))

                -- climbDownBoard: the hole is now an ordinary Climb-down
                t.exec("climbDownBoard", t.player.click_loc, "meiyerditch_wall_floorboards_multi_loc", 1)
                t.ticks(5)
                t.check("climbDownBoard.below", true, "tile " .. at(t) .. " messages: " .. said(t, 2))

                -- the corridor's breach: Climb-over the rubble to the city side (doh_meiyerditch.rs2:70)
                t.exec("climbRubble", t.player.click_loc, "myq3_rubble_west_wall", 1)
                t.ticks(4)
                t.check("climbRubble.over", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("goto-talkToCitizen", t.player.goto_tile, 3596, 3214, 0) -- the citizen stands at 3597,3214; the east side is walled off

                -- talkToCitizen: whisper about the Myreque (doh_meiyerditch.rs2:123)
                t.exec("talkToCitizen", t.player.talk_to, "myq3_citizen_male_old_1", 1)
                t.exec("talkToCitizen-dialog", t.chat.play, {
                    "player:(whisper) Do you know about the Myreque?",
                    "npc:(whisper) Keep your voice down",
                    "choose:(whisper) I really need to meet the Myreque.",
                    "player:(whisper) I really need",
                    "npc:(whisper) I can't help you",
                    "choose:How can Old Man Ral help me?",
                    "player:How can Old Man Ral",
                    "npc:(whisper) He knows the paths",
                })
                t.ticks(3)
                t.expect("quest.stage.ral_directions", t.quest.expect_stage("ral_directions"))

                local _, stage = t.quest.stage()
                t.check("leg.1.end", true, "tile " .. at(t) .. " stage varb2573_myq3_main_quest=" .. tostring(stage) .. " (ral_directions); backpack: hammer " .. tostring(select(2, t.inv.count("hammer"))) .. ", planks " .. tostring(select(2, t.inv.count("woodplank"))) .. ", nails " .. tostring(select(2, t.inv.count("nails"))) .. "; next: Old Man Ral, southwest of the city")
                -- LEG 1 END
            end,
        },
        {
            name = "ral_to_vertida",
            run = function(t)
                -- LEG 2 BEGIN: talkToRal
                t.ticks(2)
                t.check("leg.2.start", true, "tile " .. at(t))
                t.exec("goto-talkToRal", t.player.goto_tile, 3602, 3206, 0)
                t.exec("talkToRal.door", t.player.click_loc, "area_sanguine_ghetto_door1", 1, { at = { 3602, 3208 } })
                t.ticks(3)
                t.exec("talkToRal", t.player.talk_to, "sanguinesti_old_man_ral", 1)
                t.exec("talkToRal-dialog", t.chat.play, {
                    "player:Someone said you could help me.",
                    "npc:Oh yes? And who told you that",
                    "choose:Old Man Ral, the sage of Sanguinesti.",
                    "player:Old Man Ral, the sage",
                    "npc:Ha! Then you've been sent by one who knows",
                })
                t.exec("talkToRal-dialog.rest", t.chat.drain, { max_pages = 6 })
                t.ticks(3)
                t.expect("quest.stage.course", t.quest.expect_stage(65))
                -- COURSE: ladder to the roofs (obstacle 1)
                t.exec("course.door1", t.player.click_loc, "area_sanguine_ghetto_door1", 1, { at = { 3597, 3205 } })
                t.ticks(3)
                t.exec("course.ladder1", t.player.click_loc, "area_sanguine_ghetto_ladder_up", 1, { at = { 3595, 3204 } })
                t.ticks(4)
                t.check("course.ladder1.up", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.jump2", t.player.click_loc, "myq3_agil_2_jump_south", 1)
                t.ticks(4)
                t.check("course.jump2.across", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.jump3", t.player.click_loc, "myq3_agil_3_jump_east", 1)
                t.ticks(4)
                t.check("course.jump3.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.push4", t.player.click_loc, "myq3_agil_4_pushwall_multi", 1)
                t.ticks(4)
                t.check("course.push4.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.floor4", t.player.click_loc, "myq3_agil_4_active_floor_1", 1)
                t.ticks(4)
                t.check("course.floor4.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.crawl5", t.player.click_loc, "myq3_agil_5_crawl_wall", 1)
                t.ticks(4)
                t.check("course.crawl5.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.push6", t.player.click_loc, "myq3_agil_6_pushwall_multi", 1)
                t.ticks(4)
                t.check("course.push6.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.floor6", t.player.click_loc, "myq3_agil_6_active_floor_1", 1)
                t.ticks(4)
                t.check("course.floor6.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.ladder7", t.player.click_loc, "area_sanguine_ghetto_ladder_down", 1, { at = { 3601, 3215 } })
                t.ticks(4)
                t.check("course.ladder7.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.table8a", t.player.click_loc, "myq3_agil_8_trapdoor_tunnel_multi", 1)
                t.ticks(4)
                t.check("course.table8a.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.table8b", t.player.click_loc, "myq3_agil_8_trapdoor_tunnel_multi", 1)
                t.ticks(4)
                t.check("course.table8b.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.tunnel8c", t.player.click_loc, "myq3_agil_8_trapdoor_tunnel_multi", 1)
                t.ticks(4)
                t.check("course.tunnel8c.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.shelf10", t.player.click_loc, "myq3_agil_10_shelf_climb_up", 1)
                t.ticks(4)
                t.check("course.shelf10.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.crawl11", t.player.click_loc, "myq3_agil_11_crawl_wall", 1)
                t.ticks(4)
                t.check("course.crawl11.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.jump12", t.player.click_loc, "myq3_agil_12_jump_east", 1)
                t.ticks(4)
                t.check("course.jump12.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.ladder13", t.player.click_loc, "area_sanguine_ghetto_ladder_down", 1, { at = { 3603, 3222 } })
                t.ticks(4)
                t.check("course.ladder13.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("travelToPots", t.player.click_loc, "myq3_ghetto_pots_search", 1)
                t.ticks(4)
                t.check("travelToPots.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.door14", t.player.click_loc, "myq3_agil_14_locked_door", 1)
                t.ticks(4)
                t.check("course.door14.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.ladder16", t.player.click_loc, "area_sanguine_ghetto_ladder_up", 1, { at = { 3618, 3219 } })
                t.ticks(4)
                t.check("course.ladder16.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.jump17", t.player.click_loc, "myq3_agil_17_jump_south", 1)
                t.ticks(4)
                t.check("course.jump17.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.shelf18", t.player.click_loc, "myq3_agil_18_shelf_climb_up", 1)
                t.ticks(4)
                t.check("course.shelf18.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.ladder19", t.player.click_loc, "area_sanguine_ghetto_ladder_up", 1, { at = { 3610, 3210 } })
                t.ticks(4)
                t.check("course.ladder19.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.jump20", t.player.click_loc, "myq3_agil_20_jump_south", 1)
                t.ticks(4)
                t.check("course.jump20.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.ladder21", t.player.click_loc, "area_sanguine_ghetto_ladder_down", 1, { at = { 3612, 3203 } })
                t.ticks(4)
                t.check("course.ladder21.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.line22", t.player.click_loc, "myq3_agil_22_tightrope_east", 1)
                t.ticks(4)
                t.check("course.line22.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.ladder23", t.player.click_loc, "area_sanguine_ghetto_ladder_down", 1, { at = { 3625, 3203 } })
                t.ticks(4)
                t.check("course.ladder23.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.push24", t.player.click_loc, "myq3_agil_24_pushwall_multi", 1)
                t.ticks(4)
                t.check("course.push24.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.floor24", t.player.click_loc, "myq3_agil_24_active_floor_1", 1)
                t.ticks(4)
                t.check("course.floor24.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.shelf25", t.player.click_loc, "myq3_agil_25_shelf_climb_up", 1)
                t.ticks(4)
                t.check("course.shelf25.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.shelf26", t.player.click_loc, "myq3_agil_26_shelf_climb_down", 1)
                t.ticks(4)
                t.check("course.shelf26.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.jump27", t.player.click_loc, "myq3_agil_27_jump_north", 1)
                t.ticks(4)
                t.check("course.jump27.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.jump29", t.player.click_loc, "myq3_agil_29_jump_north", 1)
                t.ticks(4)
                t.check("course.jump29.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.jump30", t.player.click_loc, "myq3_agil_30_jump_east", 1)
                t.ticks(4)
                t.check("course.jump30.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.ladder31", t.player.click_loc, "area_sanguine_ghetto_ladder_up", 1, { at = { 3630, 3239 } })
                t.ticks(4)
                t.check("course.ladder31.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("travelToLadderPart", t.player.click_loc, "myq3_agil_32_ladder_wall_multi", 1)
                t.ticks(4)
                t.check("travelToLadderPart.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.ladder32d", t.player.click_loc, "area_sanguine_ghetto_ladder_down", 1, { at = { 3630, 3239 } })
                t.ticks(4)
                t.check("course.ladder32d.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("travelToFixLadder", t.player.click_loc, "myq3_agil_33_ladder_floor_multi", 1)
                t.ticks(4)
                t.check("travelToFixLadder.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.ladder33d", t.player.click_loc, "myq3_agil_33_ladder_floor_multi", 1)
                t.ticks(4)
                t.check("course.ladder33d.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                -- the fixed ladder lands at 3629,3239,0 inside a room whose only way out is the door 3631,3240
                t.exec("course.door3631", t.player.click_loc, "area_sanguine_ghetto_door1", 1, { at = { 3631, 3240 } })
                t.ticks(3)
                t.check("course.door3631.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                -- travel to the roof ladder north of the courtyard, then over the roofs to the north room
                -- travel north to the room above the hideout: door 3628,3250, the pocket, door 3625,3252, the lane west of
                -- the houses, then east along z 3254-3256 to the north room (the jump boards 41 and the stairs are a roof
                -- detour; the ground path reaches 3636,3256 as well)
                t.player.walk_to(3633, 3240, 10)
                t.ticks(2)
                t.exec("course.door3628", t.player.click_loc, "area_sanguine_ghetto_door1", 1, { at = { 3628, 3250 } })
                t.ticks(3)
                t.player.walk_to(3626, 3253, 20)
                t.ticks(1)
                t.exec("course.door3625", t.player.click_loc, "area_sanguine_ghetto_door2", 1, { at = { 3625, 3252 } })
                t.ticks(3)
                t.player.walk_to(3631, 3257, 40)
                t.ticks(1)
                t.player.walk_to(3631, 3261, 40)
                t.ticks(2)
                t.check("course.walkRoofLadder", true, "tile " .. at(t) .. " (north of door 3631,3259; the north room is only open from the roof)")
                t.exec("course.door3631n", t.player.click_loc, "area_sanguine_ghetto_door2", 1, { at = { 3631, 3259 } })
                t.ticks(3)
                t.exec("course.ladder3631", t.player.click_loc, "area_sanguine_ghetto_ladder_up", 1, { at = { 3631, 3258 } })
                t.ticks(4)
                t.check("course.ladder3631.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.player.walk_to(3632, 3256, 10)
                t.ticks(2)
                t.exec("course.jump41", t.player.click_loc, "myq3_agil_41_jump_east", 1)
                t.ticks(4)
                t.check("course.jump41.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("course.stairs3639", t.player.click_loc, "area_sanguine_ghetto_stairs_down", 1, { at = { 3639, 3256 } })
                t.ticks(4)
                t.check("course.stairs3639.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                local wall = t.player.by_symbol("loc", "area_sanguine_myreque_secret_wall_closed")
                t.exec("travelToMyrequeBase", t.player.use_on, "knife", wall)
                t.ticks(4)
                t.expect("quest.stage.wall_found", t.quest.expect_stage(70))
                t.exec("course.wallpush", t.player.click_loc, "area_sanguine_myreque_secret_wall_closed", 1)
                t.ticks(5)
                t.check("course.wallpush.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("pressDecoratedWall", t.player.click_loc, "sang_myreque_hideout_symbol_multi", 1)
                t.ticks(4)
                t.check("pressDecoratedWall.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("enterRug", t.player.click_loc, "sang_myreque_hideout_rug_trapdoor_unhidden", 1)
                t.ticks(4)
                t.expect("quest.stage.at_hideout", t.quest.expect_stage(80))
                t.exec("enterRug.down", t.player.click_loc, "sang_myreque_hideout_trapdoor_multiloc", 1)
                t.ticks(5)
                t.check("enterRug.down.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.player.walk_to(3629, 9640)
                t.ticks(2)
                t.check("talkToVertida.near", true, "tile " .. at(t))
                t.exec("talkToVertida", t.player.talk_to, "myq4_vertida_visible", 1)
                t.exec("talkToVertida-dialog", t.chat.drain, { max_pages = 8 })
                t.ticks(3)
                t.expect("quest.stage.vertida_met", t.quest.expect_stage(90))
                t.check("leg.2.end", true, "tile " .. at(t) .. ", stage varb2573_myq3_main_quest=90, backpack hammer, knife, Vertida's message for Veliaf")
                -- LEG 2 END
            end,
        },
        {
            name = "veliaf_to_mines",
            run = function(t)
                -- LEG 3 BEGIN: talkToVeliafAfterContact
                t.ticks(2)
                t.check("leg.3.start", true, "tile " .. at(t))
                -- talkToVeliafAfterContact: back up to Burgh de Rott (plain travel), over the Broken wall,
                -- down the pub trapdoor; Vertida's message to Veliaf (doh_burgh.rs2:86)
                t.exec("goto-talkToVeliafAfterContact", t.player.goto_tile, 3491, 3229, 0)
                t.exec("talkToVeliafAfterContact.wall", t.player.click_loc, "burgh_inn_climb_over", 1)
                t.ticks(4)
                -- the trapdoor stays open from leg 1 (a varbit), so one click climbs down
                t.exec("talkToVeliafAfterContact.down", t.player.click_loc, "burgh_inn_trapdoor_multiloc", 1)
                t.ticks(6)
                t.check("talkToVeliafAfterContact.below", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("talkToVeliafAfterContact", t.player.talk_to, "myq5_veliaf_child", 1)
                t.exec("talkToVeliafAfterContact-dialog", t.chat.play, {
                    "player:Vertida asked me to bring you this.",
                    "npc:So the Meiyerditch cell still stands",
                    "choose:What should I do now?",
                    "player:What should I do now?",
                    "npc:Drezel sent word",
                })
                t.ticks(2)
                t.expect("quest.stage.veliaf_warned", t.var.expect("varb2573_myq3_main_quest", 110))
                t.exec("leaveVeliaf.ladder", t.player.click_loc, "burgh_inn_basement_ladderup", 1)
                t.ticks(5)

                -- goDownToDrezel: the trapdoor east of Paterdomus
                t.exec("goto-goDownToDrezel", t.player.goto_tile, 3422, 3484, 0)
                t.exec("goDownToDrezel.open", t.player.click_loc, "pipeastsidetrapdoor", 1)
                t.ticks(3)
                t.exec("goDownToDrezel", t.player.click_loc, "pipeastsidetrapdoor_open", 1)
                t.ticks(6)
                t.check("goDownToDrezel.below", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.player.walk_to(3438, 9895, 20)
                t.check("walk-talkToDrezel.at", true, "tile " .. at(t))
                t.exec("talkToDrezel", t.player.talk_to, "priestperiltrappedmonk2", 1)
                t.exec("talkToDrezel-dialog", t.chat.play, {
                    "player:Veliaf sent me.",
                    "npc:Strange noises outside",
                    "player:I'll take a look.",
                })
                t.ticks(2)
                t.expect("quest.stage.bush_wait", t.var.expect("varb2573_myq3_main_quest", 120))

                -- leaveDrezelToBushes: the west ladder
-- the cellar's two doors (area_mausoleum/scripts/gates.rs2:7, :25), then the west ladder
                t.player.walk_to(3433, 9897, 20)
                t.exec("leaveDrezelToBushes.door2", t.player.click_loc, "pip_underground_door2", 1)
                t.ticks(3)
                local wr, wd = t.player.walk_to(3407, 9895, 40)
                t.check("walk-leaveDrezelToBushes.at", true, "walk_to " .. tostring(wr) .. " " .. tostring(wd) .. " tile " .. at(t))
                t.exec("leaveDrezelToBushes.door1", t.player.click_loc, "pip_underground_door1", 1)
                t.ticks(3)
                t.player.walk_to(3405, 9905, 30)
                t.exec("leaveDrezelToBushes", t.player.click_loc, "ladder_from_cellar", 1)
                t.ticks(4)
                t.check("leaveDrezelToBushes.up", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                -- searchBushes
                t.player.walk_to(3391, 3481, 30)
                t.check("walk-searchBushes.at", true, "tile " .. at(t))
                t.exec("searchBushes", t.player.click_loc, "myq_pt3_cutscene_werewolf_bush", 1)
                t.ticks(10)
                t.check("searchBushes.found", true, "tile " .. at(t) .. " chat " .. tostring(t.chat.kind()) .. " messages: " .. said(t, 3))
                t.exec("searchBushes-dialog", t.chat.drain, { max_pages = 4 })
                t.ticks(3)
                t.expect("quest.stage.bushes_done", t.var.expect("varb2573_myq3_main_quest", 130))

                -- returnFromBushesToDrezel: the surface trapdoor at 3405,3507
                t.player.walk_to(3405, 3505, 30)
                t.check("walk-returnFromBushesToDrezel.at", true, "tile " .. at(t))
                t.exec("returnFromBushesToDrezel.open", t.player.click_loc, "trapdoor", 1, { at = { 3405, 3507 } })
                t.ticks(3)
                t.exec("returnFromBushesToDrezel", t.player.click_loc, "trapdoor_open", 1, { at = { 3405, 3507 } })
                t.ticks(5)
                t.check("returnFromBushesToDrezel.below", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("walk-talkToDrezel2.door1", t.player.click_loc, "pip_underground_door1", 1)
                t.ticks(3)
                t.player.walk_to(3430, 9897, 40)
                t.exec("walk-talkToDrezel2.door2", t.player.click_loc, "pip_underground_door2", 1)
                t.ticks(3)
                t.player.walk_to(3438, 9895, 30)
                t.check("walk-talkToDrezel2.at", true, "tile " .. at(t))
                t.exec("talkToDrezel.runes", t.player.talk_to, "priestperiltrappedmonk2", 1)
                t.exec("talkToDrezel.runes-dialog", t.chat.drain, { max_pages = 8 })
                t.ticks(2)
                t.expect("quest.stage.runes_given", t.var.expect("varb2573_myq3_main_quest", 135))
                t.check("talkToDrezel.runes.held", true, "law " .. tostring(select(2, t.inv.count("lawrune"))) .. " fire " .. tostring(select(2, t.inv.count("firerune"))) .. " air " .. tostring(select(2, t.inv.count("airrune"))))

                -- talkToRoald: Varrock Teleport from Drezel's runes, then the castle
                t.exec("teleportToVarrock", t.player.cast, "varrock_teleport")
                t.ticks(6)
                t.check("teleportToVarrock.at", true, "tile " .. at(t))
                t.exec("goto-talkToRoald", t.player.goto_tile, 3222, 3471, 0)
                t.exec("talkToRoald", t.player.talk_to, "king_roald", 1)
                t.exec("talkToRoald-dialog", t.chat.play, {
                    "player:I must speak with you on a matter of grave importance.",
                    "npc:Speak, then.",
                    "choose:Talk to the king about Morytania.",
                    "player:Your majesty, werewolves",
                    "npc:Werewolves over the Salve?",
                    "choose:What should I do now?",
                    "player:What should I do now?",
                    "npc:Go back to your friends",
                })
                t.ticks(2)
                t.expect("quest.stage.roald_told", t.var.expect("varb2573_myq3_main_quest", 170))

                -- talkToVeliafAfterDrezel: back to Burgh de Rott
                t.exec("goto-talkToVeliafAfterDrezel", t.player.goto_tile, 3491, 3229, 0)
                t.exec("talkToVeliafAfterDrezel.wall", t.player.click_loc, "burgh_inn_climb_over", 1)
                t.ticks(4)
                -- the trapdoor stays open from leg 1 (a varbit), so one click climbs down
                t.exec("talkToVeliafAfterDrezel.down", t.player.click_loc, "burgh_inn_trapdoor_multiloc", 1)
                t.ticks(6)
                t.exec("talkToVeliafAfterDrezel", t.player.talk_to, "myq5_veliaf_child", 1)
                t.exec("talkToVeliafAfterDrezel-dialog", t.chat.play, {
                    "player:Werewolves are crossing the Salve",
                    "npc:Then the Myreque in Meiyerditch need to hear it too",
                })
                t.ticks(2)
                t.expect("quest.stage.veliaf_told", t.var.expect("varb2573_myq3_main_quest", 180))
                t.exec("leaveVeliaf2.ladder", t.player.click_loc, "burgh_inn_basement_ladderup", 1)
                t.ticks(5)

                -- goToMines: a Vyrewatch in Meiyerditch sends the player to the Daeyalt mine
                t.exec("goto-goToMines", t.player.goto_tile, 3615, 3246, 0)
                t.exec("goToMines", t.player.talk_to, "sang_myq3_female_flying_vyrewatch_3", 1)
                t.exec("goToMines-dialog", t.chat.play, {
                    "npc:You there, citizen",
                    "choose:Send me to the mines.",
                    "player:Send me to the mines.",
                    "npc:The mines?",
                    "choose:/Send me to the mines!/",
                    "player:Send me to the mines!",
                    "npc:A bit of menial work",
                })
                t.ticks(4)
                t.check("goToMines.at", true, "tile " .. at(t))
                -- mineDaeyaltThenLeave: a spare pick from a miner, fifteen ores into the cart, the guard
                t.exec("mineDaeyaltThenLeave.pick", t.player.talk_to, "myreque_pt3_miner1", 1)
                t.exec("mineDaeyaltThenLeave.pick-dialog", t.chat.play, {
                    "npc:Keep your voice down",
                    "choose:Do you have a spare pick?",
                    "player:Do you have a spare pick?",
                    "npc:Here. It's an old bronze one",
                })
                t.expect("mineDaeyaltThenLeave.pick.held", t.inv.expect_has("bronze_pickaxe", 1))
                -- the mine: Daeyalt rocks, five ores to the cart at a time (doh_urgent.rs2:222, :249)
                t.exec("mineDaeyaltThenLeave.walk", t.player.goto_tile, 2389, 4624, 2)
                local cart = t.player.by_symbol("loc", "area_sanguine_minecart_multiloc")
                for load = 1, 15 do
                    t.player.click_loc("area_sanguine_mine_minerocks_01", 1)
                    t.inv.await("castle_drakan_daeyalt_ore", 1, 80)
                    t.player.use_on("castle_drakan_daeyalt_ore", cart)
                    t.ticks(2)
                    if load % 5 == 0 then
                        local _, loaded = t.var.varbit("varb2588_myq3_sang_punish_mining_cart")
                        t.check("mineDaeyaltThenLeave.loaded" .. load, loaded == load, "cart holds " .. tostring(loaded) .. " of 15 loads after " .. load .. " ore")
                    end
                end
                t.exec("mineDaeyaltThenLeave", t.player.talk_to, "sang_myq3_mine_guard_juvinate_male", 1)
                t.exec("mineDaeyaltThenLeave-dialog", t.chat.play, {
                    "player:The cart's full.",
                    "npc:Back to the streets with you",
                })
                t.ticks(4)
                t.check("mineDaeyaltThenLeave.out", true, "tile " .. at(t))

                -- returnToMeiyBase: press the decorated wall (doh_meiyerditch.rs2:539)
                t.exec("returnToMeiyBase", t.player.click_loc, "sang_myreque_hideout_symbol_multi", 1)
                t.ticks(3)
                t.check("returnToMeiyBase.pressed", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                local _, q = t.quest.stage()
                t.check("leg.3.end", q == 180, "tile " .. at(t) .. ", stage varb2573_myq3_main_quest=" .. tostring(q) .. ", backpack hammer, knife, bronze_pickaxe, runes spent on the teleport")
                -- LEG 3 END
            end,
        },
        {
            name = "walls_to_safalaan",
            run = function(t)
                -- LEG 4 BEGIN: climbUpDrakanWalls
                t.ticks(2)
                t.check("leg.4.start", true, "tile " .. at(t))
                -- the rug trapdoor stays open from leg 2, so one click climbs down
                t.exec("vertida.down", t.player.click_loc, "sang_myreque_hideout_trapdoor_multiloc", 1)
                t.ticks(5)
                t.player.walk_to(3629, 9640)
                t.ticks(2)
                t.exec("vertida", t.player.talk_to, "myq4_vertida_visible", 1)
                t.exec("vertida-dialog", t.chat.drain, { max_pages = 8 })
                t.ticks(3)
                t.expect("quest.stage.return_meiyerditch", t.quest.expect_stage(190))
                t.check("vertida.at", true, "tile " .. at(t) .. " stage " .. tostring(select(2, t.quest.stage())))
                -- the random room above Ral's house: in through his door, up the ladder, and down again
                t.exec("goto-goDownFromRandomRoom", t.player.goto_tile, 3598, 3206, 0)
                t.exec("goDownFromRandomRoom.door", t.player.click_loc, "area_sanguine_ghetto_door1", 1, { at = { 3597, 3205 } })
                t.ticks(3)
                t.exec("goDownFromRandomRoom.up", t.player.click_loc, "area_sanguine_ghetto_ladder_up", 1, { at = { 3595, 3204 } })
                t.ticks(4)
                t.check("goDownFromRandomRoom.near", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("goDownFromRandomRoom", t.player.click_loc, "area_sanguine_ghetto_ladder_down", 1, { at = { 3595, 3204 } })
                t.ticks(4)
                t.check("goDownFromRandomRoom.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                -- the way to the walls: plain travel to the breach north of the rubble, over it, then up the floor
                t.exec("goto-climbUpFloor", t.player.goto_tile, 3591, 3181, 0)
                t.exec("climbUpFloor.rubble", t.player.click_loc, "myq3_rubble_east_wall", 1)
                t.ticks(4)
                t.check("climbUpFloor.rubble.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("climbUpFloor", t.player.click_loc, "mieyerditch_wall_underboards_multi_loc", 1)
                t.ticks(4)
                t.check("climbUpFloor.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                t.exec("climbDownWallLadder", t.player.click_loc, "myq3_ladder_down", 2, { at = { 3588, 3210 } })
                t.ticks(4)
                t.check("climbDownWallLadder.at", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                -- searchRockySurface: opens the barricade pass for a while (doh_meiyerditch.rs2:631)
                t.exec("searchRockySurface", t.player.click_loc, "myq3_secret_rock_barricade_unlock", 1)
                t.ticks(3)
                t.check("searchRockySurface.said", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                -- goThroughBarricade: through the pass, then up the ladder beyond it
                t.player.walk_to(3590, 3228, 60)
                t.check("goThroughBarricade.through", true, "tile " .. at(t))
                t.exec("goThroughBarricade", t.player.click_loc, "myq3_ladder_up", 2, { at = { 3593, 3230 } })
                t.ticks(4)
                t.check("goThroughBarricade.up", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                -- climbLadderSecondWall
                t.player.walk_to(3588, 3250, 30)
                t.drive.camera(0, 450, 500)
                t.ticks(1)
                t.exec("climbLadderSecondWall", t.player.click_loc, "myq3_ladder_up_2", 2, { at = { 3588, 3251 } })
                t.ticks(4)
                t.check("climbLadderSecondWall.up", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                -- climbDownFromThirdWall
                t.exec("climbDownFromThirdWall", t.player.click_loc, "myq3_ladder_down_2", 2, { at = { 3588, 3259 } })
                t.ticks(4)
                t.check("climbDownFromThirdWall.down", true, "tile " .. at(t) .. " messages: " .. said(t, 2))
                -- climbUpDrakanWalls
                t.player.walk_to(3588, 3280, 40)
                t.player.walk_to(3591, 3300, 40)
                t.player.walk_to(3595, 3309, 60)
                t.check("climbUpDrakanWalls.near", true, "tile " .. at(t))
                -- the pass table (maplink.dbrow [maplink_1_56_51_11_46_up]) is keyed on the tile the loc stands on, so the climber stands there and presses it
                t.player.walk_to(3595, 3310, 10)
                local _, wall = t.world.loc_near("darkm_outer_wall_3h_meyerditch_wall_shortcut_bottom", 3)
                -- click_loc/click_minimenu step off the loc's own tile before pressing and land on level 2 at 3595,3309 (a dead end: ladders.rs2 default +1 plane), so the op goes from the tile itself (logged bypass; content note: maplink.dbrow:13228 keys the row on the loc tile)
                t.drive.op(wall, 1)
                t.ticks(4)
                t.check("climbUpDrakanWalls", at(t) == "3595,3312,0", "tile " .. at(t) .. " (north of the wall, ground level) messages: " .. said(t, 2))
                -- talkToSafalaan: on the wall-walk (doh_castle.rs2:110, doh_safalaan_first)
                t.player.walk_to(3586, 3330, 80)
                t.check("talkToSafalaan.near", true, "tile " .. at(t))
                t.exec("talkToSafalaan", t.player.talk_to, "myreque_pt3_safalaan", 1)
                t.exec("talkToSafalaan-dialog", t.chat.play, {
                    "player:Vertida sent me.",
                    "npc:Noted, and troubling.",
                    "npc:west and south",
                    "choose:Okay, lead the way.",
                    "player:Okay, lead the way.",
                    "npc:North first.",
                })
                t.ticks(3)
                t.check("talkToSafalaan.stage", true, "tile " .. at(t) .. " stage " .. tostring(select(2, t.quest.stage())) .. " charcoal " .. tostring(select(2, t.inv.count("charcoal"))) .. " papyrus " .. tostring(select(2, t.inv.count("papyrus"))))
                t.expect("quest.stage.sketch_north", t.quest.expect_stage(200))
                -- drawNorthWall: charcoal on papyrus, standing on the north sickle logo (doh_castle.rs2:121)
                -- the wall-walk bends: leg by leg along it, each walk_to goes as far as the walk reaches
                for _, p in ipairs({ { 3572, 3331 }, { 3556, 3337 }, { 3556, 3379 }, { 3556, 3379 } }) do
                    t.player.walk_to(p[1], p[2], 40)
                end
                t.check("drawNorthWall.near", true, "tile " .. at(t))
                t.exec("drawNorthWall", t.player.use_item_on_item, "charcoal", "papyrus")
                t.ticks(5)
                t.expect("drawNorthWall.sketch", t.inv.expect_has("myq3_castle_sketch_1", 1))
                t.expect("quest.stage.sketch_west", t.quest.expect_stage(210))
                t.check("drawNorthWall.said", true, "tile " .. at(t) .. " stage " .. tostring(select(2, t.quest.stage())) .. " messages: " .. said(t, 2))
                -- drawWestWall: the west sickle logo
                for _ = 1, 4 do
                    t.player.walk_to(3522, 3357, 40)
                end
                t.check("drawWestWall.near", true, "tile " .. at(t))
                t.exec("drawWestWall", t.player.use_item_on_item, "charcoal", "papyrus")
                t.ticks(5)
                t.expect("drawWestWall.sketch", t.inv.expect_has("myq3_castle_sketch_2", 1))
                t.expect("quest.stage.sketch_south_start", t.quest.expect_stage(220))
                t.check("drawWestWall.said", true, "tile " .. at(t) .. " stage " .. tostring(select(2, t.quest.stage())) .. " messages: " .. said(t, 2))
                t.check("leg.4.end", true, "tile " .. at(t) .. ", stage varb2573_myq3_main_quest=220 (sketch_south_start), backpack hammer, knife, bronze_pickaxe, charcoal, papyrus, myq3_castle_sketch_1 and _2; next: the south sickle logo (3572,3331), Vanstrom")
                -- LEG 4 END
            end,
        },
    },
}

end)()

if type(QUEST) == "table" and QUEST.legs ~= nil then
    local legs_quest = QUEST
    QUEST = { setup = legs_quest.setup, run = function(t)
        return t.core_legs_drive(legs_quest, { from = LEG_FROM, only = LEG_ONLY, tile = LEG_TILE })
    end }
end
if type(QUEST) ~= "table" or type(QUEST.run) ~= "function" then
    error("quest file did not return { run = function(t) ... end }"
        .. " or { legs = { { name =, run = function(t) ... end }, ... } }")
end
local quest_setup = QUEST.setup
-- A setup that is not a list of cheat lines is a setup nobody reads:
-- refuse it rather than run the quest against an unstated world.
if quest_setup ~= nil and type(quest_setup) ~= "table" then
    error("quest file's setup is a " .. type(quest_setup)
        .. ", not a table of cheat lines")
end
-- A checkpoint run resumes a player who already went through setup
-- (and legs 1..K-1): the setup list is NOT run again.
if LEG_FROM and LEG_FROM > 1 then
    quest_setup = nil
end
local quest_run = QUEST.run
QUEST.run = function(t)
    -- WAIT FOR THE LOGIN GRANT before the first setup cheat.
    --
    -- The backpack a fixture starts with is not in the fixture: the
    -- containers are adopted EMPTY (torirs_server_world.c, "what goes
    -- in them the first time a character connects is content's") and
    -- content's [login,_] -> [proc,newplayer_inv] fills them on a
    -- later tick than the one this script starts on.  Measured
    -- 2026-09-19 (build/quest_gate/closer_setup2 row 1,
    -- closer_setup3): `::clearinv` issued on the first frame answers
    -- "Cleared 0 item(s).", the fourteen tutorial slots land behind
    -- it, and a `::give` before the grant is overwritten by it -- a
    -- setup list that answered `ok` three times and left the world it
    -- promised in none of them.  A fixed `t.ticks(n)` does not fix it
    -- (the grant landed on tick 1 in one run and after three cheats in
    -- the next); the arrival itself is the signal, so wait for it.
    --
    -- Bounded, and proceeding either way: a fixture whose character
    -- really does hold nothing pays the budget and runs its setup
    -- anyway, rather than failing a quest over an empty backpack.
    t.await({ level = function()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return true
            end
        end
        return false
    end, note = "setup: the login grant" }, 10)
    t.settle()
    -- A CHEAT'S REPLY OUTRUNS ITS EFFECT by exactly one server tick.
    --
    -- t.cheat waits for the reply line (core.lua: QD.cheat ->
    -- msg.await), and the server SAYS `Gave 3 x Egg (1944).` from
    -- inside the ladder branch itself, while the backpack the same
    -- branch just wrote reaches the client in the container
    -- listener's UPDATE_INV at the END of that tick
    -- (torirs_server_world.c, the ::give branch: `the backpack's
    -- listener sends an UPDATE_INV without this branch knowing a
    -- packet exists`).  So the setup loop used to hand run() a client
    -- that had heard about the items and not yet received them, and
    -- every quest whose first rows read t.inv.count saw an empty
    -- backpack from a setup that had answered `ok` three times.
    -- Measured 2026-09-21 (build/quest_gate/lag_probe): row `lag.t0`
    -- FAIL `egg: absent`, row `lag.t1` -- one t.ticks(1) later --
    -- PASS `3`.  Two seam fixers reported it as `::give from setup
    -- lands nothing` (docs/QUEST_AUTHORING.md trap 23).
    --
    -- A ::give is therefore not done when it answers: it is done when
    -- the CLIENT can count the items, which is also the only check
    -- that catches the ladder's own silent misses -- `::give
    -- nosuchitemname` and an ambiguous name both `say()` their
    -- complaint and return RAN, i.e. `ok`, having given nothing
    -- (same file, `No item named '%s'.` / `Which %s? %s`).  Each one
    -- is now a FAIL row named after the cheat, exactly like a cheat
    -- that answered no_row.
    local function setup_give(text)
        local name, count = string.match(text, "^%s*:*give%s+([%w_]+)%s*(%d*)")
        if not name then
            return nil
        end
        local wanted = tonumber(count)
        if not wanted or wanted < 1 then
            wanted = 1
        end
        return name, wanted
    end
    -- Name-free fingerprint of the backpack: every slot's count, plus
    -- one per occupied slot so an item ARRIVING in an empty slot
    -- moves it too.  What the fallback below watches when a ::give
    -- names something this client cannot count.
    local function setup_backpack_mark()
        local mark = 0
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                mark = mark + cell.count + 1
            end
        end
        return mark
    end
    local function setup_backpack_empty()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return false
            end
        end
        return true
    end
    -- `::setlevel <stat> <level>` -> stat, level; nil for any other line.
    -- A line that STARTS as a setlevel (the engine's own strncmp prefix)
    -- but does not parse is ("", nil): the engine answers ok to it
    -- and sets nothing.
    local function setup_setlevel(text)
        if not string.match(text, "^%s*:*setlevel") then
            return nil
        end
        local stat, level = string.match(text, "^%s*:*setlevel%s+(%a[%w_]*)%s+(%d+)%s*$")
        if not stat then
            return "", nil
        end
        return stat, tonumber(level)
    end
    -- `::wield <item>` -> item; nil for any other line.  The cheat
    -- answers once the synthesized Wield click is SENT (seam pass 29:
    -- it used to take only an obj id, print its Usage line for a name
    -- and answer ok -- arthur fought Mordred unarmed behind a green
    -- setup), and content may still refuse the wield (a level, a
    -- quest), so the line is done only when the WORN container holds
    -- the item (QD.ui._worn_count, ui.lua).
    local function setup_wield(text)
        return string.match(text, "^%s*:*wield%s+([%w_]+)%s*$")
    end
    local function setup_last_lines(n)
        local lines_result, rows = t.msg.last(n)
        if lines_result ~= "ok" or type(rows) ~= "table" then
            return "(no chat lines)"
        end
        local texts = {}
        for i = 1, #rows do
            texts[#texts + 1] = "'" .. tostring(rows[i].text) .. "'"
        end
        return table.concat(texts, " / ")
    end
    local function setup_failed(cheat, why)
        t.step("setup." .. cheat, "FAIL",
            why .. " -- the world this quest assumes was never stated")
        t.finish(1)
    end
    if type(quest_setup) == "table" then
        for _, cheat in ipairs(quest_setup) do
            -- Counted BEFORE the cheat: a setup list that gives the
            -- same item twice, or gives one the login grant already
            -- put there, is waiting for an INCREASE, not for a total.
            local give_name, give_count = setup_give(cheat)
            local before = nil
            local before_mark = nil
            if give_name then
                local count_result, count_total = t.inv.count(give_name)
                if count_result == "ok" then
                    before = count_total
                else
                    -- A name this client cannot resolve to an obj: the
                    -- server's own cheat_obj_from_name is fuzzy and may
                    -- still have matched one -- but `::give
                    -- nosuchitemname` reaches the SAME `ok` (it say()s
                    -- `No item named` and returns RAN), so the whole
                    -- backpack is watched for any movement instead of
                    -- taking the cheat at its word.
                    before_mark = setup_backpack_mark()
                end
            end
            local wield_name = setup_wield(cheat)
            local worn_before = nil
            if wield_name then
                local worn_result, worn_count = t.ui._worn_count(wield_name)
                if worn_result ~= "ok" then
                    setup_failed(cheat, "cannot read the worn container for "
                        .. wield_name .. " (" .. tostring(worn_result) .. " "
                        .. tostring(worn_count) .. "), so a wield could never be"
                        .. " proved")
                    return
                end
                worn_before = worn_count
            elseif string.match(cheat, "^%s*:*wield") then
                setup_failed(cheat, "not `::wield <item_name>`: a line the"
                    .. " read-back cannot name is a wield nobody can prove")
                return
            end
            local level_stat, level_wanted = setup_setlevel(cheat)
            if level_stat == "" then
                setup_failed(cheat, "not `::setlevel <stat name> <level>`: the"
                    .. " engine answers ok to it and sets nothing, and a numeric"
                    .. " stat id cannot be read back to prove it landed")
                return
            end
            local setup_result, setup_detail = t.cheat(cheat)
            if setup_result ~= "ok" then
                setup_failed(cheat, "setup cheat answered "
                    .. tostring(setup_result)
                    .. " (" .. tostring(setup_detail) .. "); last lines: "
                    .. setup_last_lines(2))
                return
            end
            if before ~= nil then
                local landed = t.inv.await(give_name, before + give_count, 10)
                if landed ~= "ok" then
                    local after_result, after_total = t.inv.count(give_name)
                    -- Short of the count asked for is the BACKPACK's
                    -- limit speaking (`Gave 21 x Egg (1944), 7 did not
                    -- fit.`), not a setup that did not happen; nothing
                    -- arriving at all is.
                    if after_result ~= "ok" or after_total <= before then
                        setup_failed(cheat, "the cheat answered ok and no "
                            .. give_name
                            .. " reached the backpack within 10 ticks (held "
                            .. tostring(before) .. " before, "
                            .. tostring(after_total) .. " after)")
                        return
                    end
                end
            elseif before_mark ~= nil then
                local moved = t.await({ level = function()
                    return setup_backpack_mark() ~= before_mark
                end, note = "setup: ::give reaching the backpack" }, 10)
                if moved ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the backpack"
                        .. " did not change within 10 ticks (" .. give_name
                        .. " is not an obj this client can count, so every"
                        .. " slot was watched instead)")
                    return
                end
            elseif worn_before ~= nil then
                local worn_last = worn_before
                local worn_landed = t.await({ level = function()
                    local read_result, reading = t.ui._worn_count(wield_name)
                    if read_result == "ok" then
                        worn_last = reading
                    end
                    return read_result == "ok" and reading > worn_before
                end, note = "setup: ::wield reaching the worn container" }, 10)
                if worn_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. wield_name
                        .. " is not worn 10 ticks later (worn " .. tostring(worn_before)
                        .. " before, " .. tostring(worn_last) .. " after); last lines: "
                        .. setup_last_lines(3))
                    return
                end
            elseif level_stat ~= nil then
                -- ok is not a level: wait for the client's reading.
                local level_last = "unread"
                local level_landed = t.await({ level = function()
                    local read_result, reading = t.skill.read(level_stat)
                    if read_result ~= "ok" then
                        level_last = tostring(read_result) .. " " .. tostring(reading)
                        return false
                    end
                    level_last = "stated=" .. tostring(reading.stated)
                        .. " base_level=" .. tostring(reading.base_level)
                    return reading.stated and reading.base_level == level_wanted
                end, note = "setup: ::setlevel reaching the client" }, 10)
                if level_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. level_stat
                        .. " never read base_level " .. tostring(level_wanted)
                        .. " within 10 ticks (last reading: " .. level_last .. ")")
                    return
                end
            elseif string.match(cheat, "^%s*:*clearinv") then
                -- The same race, and the one cheat every generated
                -- setup list opens with: an unfinished ::clearinv also
                -- makes the NEXT give's before-count wrong.
                local cleared = t.await({ level = setup_backpack_empty,
                    note = "setup: ::clearinv reaching the client" }, 10)
                if cleared ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the"
                        .. " backpack still holds items 10 ticks later")
                    return
                end
            end
        end
        -- Every OTHER cheat (::setvar, a quest's own reset
        -- debugproc) has the same one-tick reply/effect gap with no
        -- single reading to wait on, so the loop ends on the tick
        -- boundary its last reply outran.  run()'s first row reads a
        -- client that has seen the setup, which is what `setup` means.
        t.ticks(1)
        t.settle()
    end
    return quest_run(t)
end
return QUEST
