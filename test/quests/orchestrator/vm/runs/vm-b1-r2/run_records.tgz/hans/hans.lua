local LEG_FROM = nil
local LEG_ONLY = false
local LEG_TILE = nil
local QUEST = (function()
-- Hans, the Lumbridge castle greeter: talk to him, read his menu, pick the
-- "I have come to kill everyone in this castle!" row, and watch him actually
-- flee and come back -- docs/QUEST_DRIVER_REMAINING.md phase D1. Hans has no
-- Quest Helper guide, so this file has no scaffold to regenerate from
-- (tools/quest_gate/new_quest.py); it is rewritten by hand onto the driver
-- kit instead (docs/QUEST_SUITE_KIT.md phase 3, worker 3d): t.exec for every
-- click, npc.await_present/npc.await_gone (worker 2c) for the flee/return
-- waits, and player.teleport to stand the player at a known tile rather than
-- trusting the fixture's exact placement. No local helper function -- the
-- Chebyshev tile distance the D1 pass used is inlined at its two call sites
-- below instead of a `local function` (a plain local variable, not a
-- function, is still just an ordinary Lua local inside `run`, same as every
-- other quest file's own `local result, detail = ...`).
--
-- Both clocks (how long he stays gone, how long until he is back on his
-- route) are read at RUNTIME through the test-only
-- `[debugproc,hans_test_constants]` (OSRS-Content/.../areas/lumbridge/
-- scripts/hans_test_constants.rs2), never pinned as literals here -- the
-- rule this file exists to keep (docs/QUEST_DRIVER_PLAN.md phase-1 gate).
--
-- The server selftest (src/torirsserver/torirs_server_world_selftest.c,
-- "hans selftest") checks three separable claims after the flee: he leaves,
-- a respawn clock is armed, and he comes back AT HIS SPAWN TILE IN PATROL
-- MODE rather than standing wherever the escape mode ran out of steps. This
-- driver has no seam onto `srv->npcs[].mode` or `.spawn_x/.spawn_z` --
-- `api_drive.npcs` (verbs-ui) reports only tile position and identity, never
-- server AI state -- so what the CLIENT can see of that third claim is
-- position: the merged "hans.returns" row below compares where he reappears
-- against where he was standing right after `hans.locate`, captured before
-- the flee ever starts and therefore before the escape branch has moved him
-- anywhere. That capture is not exactly his spawn tile (a few ticks of
-- ordinary patrol motion may have already carried him toward patrol2 by
-- then), so HOME_TILE_TOLERANCE below is generous enough to absorb that
-- drift while staying far tighter than the ~20-tile spread the escape
-- flight and the rest of the patrol loop cover. A second check,
-- `hans.patrolling`, waits a few more ticks and confirms he has actually
-- taken a further step rather than sitting frozen at the respawn tile:
-- patrol resumes walking immediately (patrol1's pause is 0), so a Hans
-- stuck in place there is exactly the bug class `npc_setmode`/
-- `ToriRSServer_WorldNpcDefaultMode` existed to close.
--
-- Every row here goes through t.exec or t.check, both
-- of which shoot the row they write (gate.py's minimum-shape rule is per
-- row -- `shooting_row_names` -- and those are the two verbs it names). Two
-- pairs that would otherwise fire back to back with no world change between
-- them (locate + home-tile; the return-await + the spawn-tile distance) are
-- merged into ONE row each rather than two, so as not to hand gate.py's
-- duplicate-MD5 rule two captures of the same still frame.

return {
    id = "hans",
    fixture = "fresh_lumbridge.ini",
    setup = {},

    run = function(t)
        -- ---------------------------------------------------- the clocks
        -- The cheat dispatches synchronously against the embedded server,
        -- but its mes() reaches the CLIENT's own chat log only after the
        -- packet round-trips through a frame or two -- so this settles
        -- first, and then searches the last few lines rather than assuming
        -- the newest one is it. A wide window, not a narrow one: measured
        -- live, the login banner (music-track unlock, crop-circle notice,
        -- "::style" hint, the welcome lines, ...) keeps dribbling in for a
        -- few ticks after login and buries this cheat's own line seven deep
        -- by the time this reads -- msg.last(5) missed it outright.
        local cheat_result, cheat_detail = t.cheat("::hans_test_constants")
        t.ticks(2)
        local msg_result, lines = t.msg.last(30)
        local flee_ticks, respawn_ticks, source_line = nil, nil, nil
        if msg_result == "ok" and type(lines) == "table" then
            for _, entry in ipairs(lines) do
                local flee_text, respawn_text = string.match(entry.text,
                    "hans_flee_ticks=(%d+)%s+hans_respawn_ticks=(%d+)")
                if flee_text then
                    flee_ticks = tonumber(flee_text)
                    respawn_ticks = tonumber(respawn_text)
                    source_line = entry.text
                end
            end
        end
        t.check("hans.constants", (flee_ticks ~= nil and respawn_ticks ~= nil),
            "cheat=" .. tostring(cheat_result) .. "/" .. tostring(cheat_detail)
                .. " flee_ticks=" .. tostring(flee_ticks)
                .. " respawn_ticks=" .. tostring(respawn_ticks)
                .. " (from " .. tostring(source_line or msg_result) .. ")")
        if not (flee_ticks and respawn_ticks) then
            t.finish(1)
            return
        end

        -- ------------------------------------------- stand somewhere known
        -- A server-side setpos onto the respawn tile, never the fixture's
        -- own placement -- see the file banner.
        t.exec("stand_lumbridge", t.player.teleport, "lumbridge")

        -- ------------------------------------------------------- find him
        -- Recorded now, before anything else touches him -- the closest
        -- available client-visible stand-in for "his spawn tile" (see the
        -- file banner). One row: both reads are the same still world, so
        -- one shot, not two.
        local target, sym_result, sym_name = t.player.by_symbol("npc", "hans")
        local home_result, home_row = t.npc.by_symbol("hans")
        local home_x, home_z = nil, nil
        if home_result == "ok" then
            home_x, home_z = home_row.x, home_row.z
        end
        t.check("hans.locate", (target ~= nil and home_x ~= nil),
            "target=" .. (target and "built" or tostring(sym_name))
                .. " home=" .. tostring(home_x) .. "," .. tostring(home_z)
                .. " (" .. tostring(home_result) .. ")")
        if not (target and home_x) then
            t.finish(1)
            return
        end

        t.exec("walk_near_hans", t.player.walk_near, target)

        -- ------------------------------------------------------------ talk
        t.exec("talk_hans", t.player.talk_to, "hans")
        t.check("hans.expect_head", t.chat.expect_head("hans"))

        local drain_result, drain_detail = t.chat.drain({ stop_at = "options" })
        t.check("hans.drain_to_menu", drain_result == "ok", drain_detail)

        -- ------------------------------------------------------ the menu
        local options_result, options = t.chat.options()
        local FLEE_ROW_TEXT = "I have come to kill everyone in this castle!"
        local flee_row = nil
        if options_result == "ok" then
            for index, text in ipairs(options) do
                if text == FLEE_ROW_TEXT then
                    flee_row = index
                end
            end
        end
        t.check("hans.flee_row_present", flee_row ~= nil,
            flee_row and ("row " .. flee_row)
                or ("'" .. FLEE_ROW_TEXT .. "' not among the rows -- "
                    .. (options_result == "ok" and table.concat(options, " | ") or tostring(options))))
        if not flee_row then
            t.finish(1)
            return
        end

        t.exec("choose_flee", t.chat.choose, flee_row)

        -- Choosing the row only sets $option; the script's own next line is
        -- `~chatplayer_anim(^chat_angry, "I have come to kill everyone...")`
        -- -- a player page that has to be dismissed itself before if_close /
        -- npc_setmode(playerescape) / npc_say / npc_queue ever run. Measured
        -- live (D1 pass): without this, Hans never left at all -- the
        -- "gone" await below timed out with the same chat page still on
        -- screen the whole time.
        local drain2_result, drain2_detail = t.chat.drain({ stop_at = "none" })
        t.check("hans.drain_flee_line", drain2_result == "ok", drain2_detail)

        -- -------------------------------- point the camera at his tile
        -- The three rows below are claims about a PLACE -- he is gone from
        -- it, he is back on it, he has stepped off it -- and until this
        -- landed their shots were three pictures of the same castle wall
        -- with neither Hans nor the player in frame (measured in review:
        -- 15 vs 16 differed in 0.31% of bytes, all of it minimap dots and
        -- the run-energy orb). The camera the talk left behind is
        -- whichever pose `_ensure_visible` stopped at, and that pose is
        -- chosen to make a CLICK land, not to photograph a tile: it early-
        -- outs the moment the projection answers at all (pointer.lua:143),
        -- so a target clinging to the edge of the viewport never gets
        -- re-aimed. This aims it deliberately, once, from the player's own
        -- tile at the tile `hans.locate` recorded -- and the player does
        -- not move again for the rest of the run, so one aim serves all
        -- three shots. The pose is `_frame_poses`' own PULLED-BACK entry
        -- (pitch 300 / zoom 1200, pointer.lua:64-71). Measured, not
        -- guessed: the "high and close" pose (340/400) was tried first and
        -- put Hans's tile hard against the TOP edge of the viewport with
        -- only the player in frame -- a steep pitch over a six-tile offset
        -- throws the far end of it off screen. Pulling back fits the
        -- player and his tile in the same picture.
        local eye_result, eye_tile = t.world.tile()
        local watch_yaw = nil
        if eye_result == "ok" then
            watch_yaw = t.drive._yaw_towards(home_x - eye_tile.x, home_z - eye_tile.z)
        end
        local camera_result = "no_row"
        if watch_yaw ~= nil then
            camera_result = t.drive.camera(watch_yaw, 300, 1200)
        end
        -- drive.camera writes the orbit angles; app->world_camera_pos is only
        -- rebuilt by the follow step on the NEXT frame (pointer.lua:134-139),
        -- so the shot this row takes must come a tick later or it photographs
        -- the old eye.
        t.ticks(1)
        t.check("hans.watch_camera", camera_result == "ok" and watch_yaw ~= nil,
            "aimed from " .. tostring(eye_result == "ok" and eye_tile.x) .. ","
                .. tostring(eye_result == "ok" and eye_tile.z)
                .. " at hans_home=" .. tostring(home_x) .. "," .. tostring(home_z)
                .. " yaw=" .. tostring(watch_yaw) .. " pitch=300 zoom=1200 ("
                .. tostring(camera_result) .. ")")

        -- ---------------------------------------------------- he leaves
        local left_result, left_detail = t.npc.await_gone("hans", 15, flee_ticks + 5)
        t.check("hans.leaves", left_result == "ok",
            "gone within hans_flee_ticks+5=" .. (flee_ticks + 5) .. " ticks -- " .. tostring(left_detail))

        -- --------------------------------- he returns, at his spawn tile
        -- Claim 3 (file banner): read his position the instant
        -- npc.await_present says he is back, before any further tick can
        -- carry him along the route, and compare it against home_x/home_z
        -- rather than against wherever the flight ended. Merged into one
        -- row/shot with the return-await itself -- see the file banner on
        -- duplicate-MD5.
        local back_result, back_detail = t.npc.await_present("hans", 60, respawn_ticks + 10)
        local returned_result, returned_row = t.npc.by_symbol("hans")
        local returned_x, returned_z, spawn_distance = nil, nil, nil
        if returned_result == "ok" then
            returned_x, returned_z = returned_row.x, returned_row.z
            local dx = returned_x - home_x
            if dx < 0 then
                dx = -dx
            end
            local dz = returned_z - home_z
            if dz < 0 then
                dz = -dz
            end
            spawn_distance = (dx > dz) and dx or dz
        end
        local HOME_TILE_TOLERANCE = 15
        t.check("hans.returns",
            back_result == "ok" and spawn_distance ~= nil and spawn_distance <= HOME_TILE_TOLERANCE,
            "back within hans_respawn_ticks+10=" .. (respawn_ticks + 10) .. " ticks -- "
                .. tostring(back_detail)
                .. " home=" .. home_x .. "," .. home_z
                .. " returned=" .. tostring(returned_x) .. "," .. tostring(returned_z)
                .. " distance=" .. tostring(spawn_distance)
                .. " tolerance=" .. HOME_TILE_TOLERANCE)

        -- A few more ticks: a patrol resumes walking immediately (patrol1's
        -- own pause is 0), so a Hans who reappeared but never took another
        -- step is stuck, not patrolling -- the regression
        -- `ToriRSServer_WorldNpcDefaultMode` exists to close. npc.nearest
        -- (not by_symbol, which scans the whole pool) also re-confirms he
        -- has not vanished again in the meantime.
        t.ticks(5)
        local still_result = t.npc.nearest("hans", 60)
        local moved_result, moved_row = t.npc.by_symbol("hans")
        local moved_x, moved_z, moved_distance = nil, nil, nil
        if moved_result == "ok" then
            moved_x, moved_z = moved_row.x, moved_row.z
            local base_x = returned_x or moved_x
            local base_z = returned_z or moved_z
            local mdx = moved_x - base_x
            if mdx < 0 then
                mdx = -mdx
            end
            local mdz = moved_z - base_z
            if mdz < 0 then
                mdz = -mdz
            end
            moved_distance = (mdx > mdz) and mdx or mdz
        end
        t.check("hans.patrolling",
            (still_result == "ok" and moved_distance ~= nil and moved_distance > 0),
            "still_present=" .. tostring(still_result)
                .. " returned_tile=" .. tostring(returned_x) .. "," .. tostring(returned_z)
                .. " five_ticks_later=" .. tostring(moved_x) .. "," .. tostring(moved_z)
                .. " moved=" .. tostring(moved_distance) .. " tile(s)")

        t.finish(0)
    end,
}

end)()

if type(QUEST) == "table" and QUEST.legs ~= nil then
    local legs_quest = QUEST
    QUEST = { setup = legs_quest.setup, run = function(t)
        return t.core_legs_drive(legs_quest, { from = LEG_FROM, only = LEG_ONLY, tile = LEG_TILE })
    end }
end
if type(QUEST) ~= "table" or type(QUEST.run) ~= "function" then
    error("quest file did not return { run = function(t) ... end }"
        .. " or { legs = { { name =, run = function(t) ... end }, ... } }")
end
local quest_setup = QUEST.setup
-- A setup that is not a list of cheat lines is a setup nobody reads:
-- refuse it rather than run the quest against an unstated world.
if quest_setup ~= nil and type(quest_setup) ~= "table" then
    error("quest file's setup is a " .. type(quest_setup)
        .. ", not a table of cheat lines")
end
-- A checkpoint run resumes a player who already went through setup
-- (and legs 1..K-1): the setup list is NOT run again.
if LEG_FROM and LEG_FROM > 1 then
    quest_setup = nil
end
local quest_run = QUEST.run
QUEST.run = function(t)
    -- WAIT FOR THE LOGIN GRANT before the first setup cheat.
    --
    -- The backpack a fixture starts with is not in the fixture: the
    -- containers are adopted EMPTY (torirs_server_world.c, "what goes
    -- in them the first time a character connects is content's") and
    -- content's [login,_] -> [proc,newplayer_inv] fills them on a
    -- later tick than the one this script starts on.  Measured
    -- 2026-09-19 (build/quest_gate/closer_setup2 row 1,
    -- closer_setup3): `::clearinv` issued on the first frame answers
    -- "Cleared 0 item(s).", the fourteen tutorial slots land behind
    -- it, and a `::give` before the grant is overwritten by it -- a
    -- setup list that answered `ok` three times and left the world it
    -- promised in none of them.  A fixed `t.ticks(n)` does not fix it
    -- (the grant landed on tick 1 in one run and after three cheats in
    -- the next); the arrival itself is the signal, so wait for it.
    --
    -- Bounded, and proceeding either way: a fixture whose character
    -- really does hold nothing pays the budget and runs its setup
    -- anyway, rather than failing a quest over an empty backpack.
    t.await({ level = function()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return true
            end
        end
        return false
    end, note = "setup: the login grant" }, 10)
    t.settle()
    -- A CHEAT'S REPLY OUTRUNS ITS EFFECT by exactly one server tick.
    --
    -- t.cheat waits for the reply line (core.lua: QD.cheat ->
    -- msg.await), and the server SAYS `Gave 3 x Egg (1944).` from
    -- inside the ladder branch itself, while the backpack the same
    -- branch just wrote reaches the client in the container
    -- listener's UPDATE_INV at the END of that tick
    -- (torirs_server_world.c, the ::give branch: `the backpack's
    -- listener sends an UPDATE_INV without this branch knowing a
    -- packet exists`).  So the setup loop used to hand run() a client
    -- that had heard about the items and not yet received them, and
    -- every quest whose first rows read t.inv.count saw an empty
    -- backpack from a setup that had answered `ok` three times.
    -- Measured 2026-09-21 (build/quest_gate/lag_probe): row `lag.t0`
    -- FAIL `egg: absent`, row `lag.t1` -- one t.ticks(1) later --
    -- PASS `3`.  Two seam fixers reported it as `::give from setup
    -- lands nothing` (docs/QUEST_AUTHORING.md trap 23).
    --
    -- A ::give is therefore not done when it answers: it is done when
    -- the CLIENT can count the items, which is also the only check
    -- that catches the ladder's own silent misses -- `::give
    -- nosuchitemname` and an ambiguous name both `say()` their
    -- complaint and return RAN, i.e. `ok`, having given nothing
    -- (same file, `No item named '%s'.` / `Which %s? %s`).  Each one
    -- is now a FAIL row named after the cheat, exactly like a cheat
    -- that answered no_row.
    local function setup_give(text)
        local name, count = string.match(text, "^%s*:*give%s+([%w_]+)%s*(%d*)")
        if not name then
            return nil
        end
        local wanted = tonumber(count)
        if not wanted or wanted < 1 then
            wanted = 1
        end
        return name, wanted
    end
    -- Name-free fingerprint of the backpack: every slot's count, plus
    -- one per occupied slot so an item ARRIVING in an empty slot
    -- moves it too.  What the fallback below watches when a ::give
    -- names something this client cannot count.
    local function setup_backpack_mark()
        local mark = 0
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                mark = mark + cell.count + 1
            end
        end
        return mark
    end
    local function setup_backpack_empty()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return false
            end
        end
        return true
    end
    -- `::setlevel <stat> <level>` -> stat, level; nil for any other line.
    -- A line that STARTS as a setlevel (the engine's own strncmp prefix)
    -- but does not parse is ("", nil): the engine answers ok to it
    -- and sets nothing.
    local function setup_setlevel(text)
        if not string.match(text, "^%s*:*setlevel") then
            return nil
        end
        local stat, level = string.match(text, "^%s*:*setlevel%s+(%a[%w_]*)%s+(%d+)%s*$")
        if not stat then
            return "", nil
        end
        return stat, tonumber(level)
    end
    -- `::wield <item>` -> item; nil for any other line.  The cheat
    -- answers once the synthesized Wield click is SENT (seam pass 29:
    -- it used to take only an obj id, print its Usage line for a name
    -- and answer ok -- arthur fought Mordred unarmed behind a green
    -- setup), and content may still refuse the wield (a level, a
    -- quest), so the line is done only when the WORN container holds
    -- the item (QD.ui._worn_count, ui.lua).
    local function setup_wield(text)
        return string.match(text, "^%s*:*wield%s+([%w_]+)%s*$")
    end
    local function setup_last_lines(n)
        local lines_result, rows = t.msg.last(n)
        if lines_result ~= "ok" or type(rows) ~= "table" then
            return "(no chat lines)"
        end
        local texts = {}
        for i = 1, #rows do
            texts[#texts + 1] = "'" .. tostring(rows[i].text) .. "'"
        end
        return table.concat(texts, " / ")
    end
    local function setup_failed(cheat, why)
        t.step("setup." .. cheat, "FAIL",
            why .. " -- the world this quest assumes was never stated")
        t.finish(1)
    end
    if type(quest_setup) == "table" then
        for _, cheat in ipairs(quest_setup) do
            -- Counted BEFORE the cheat: a setup list that gives the
            -- same item twice, or gives one the login grant already
            -- put there, is waiting for an INCREASE, not for a total.
            local give_name, give_count = setup_give(cheat)
            local before = nil
            local before_mark = nil
            if give_name then
                local count_result, count_total = t.inv.count(give_name)
                if count_result == "ok" then
                    before = count_total
                else
                    -- A name this client cannot resolve to an obj: the
                    -- server's own cheat_obj_from_name is fuzzy and may
                    -- still have matched one -- but `::give
                    -- nosuchitemname` reaches the SAME `ok` (it say()s
                    -- `No item named` and returns RAN), so the whole
                    -- backpack is watched for any movement instead of
                    -- taking the cheat at its word.
                    before_mark = setup_backpack_mark()
                end
            end
            local wield_name = setup_wield(cheat)
            local worn_before = nil
            if wield_name then
                local worn_result, worn_count = t.ui._worn_count(wield_name)
                if worn_result ~= "ok" then
                    setup_failed(cheat, "cannot read the worn container for "
                        .. wield_name .. " (" .. tostring(worn_result) .. " "
                        .. tostring(worn_count) .. "), so a wield could never be"
                        .. " proved")
                    return
                end
                worn_before = worn_count
            elseif string.match(cheat, "^%s*:*wield") then
                setup_failed(cheat, "not `::wield <item_name>`: a line the"
                    .. " read-back cannot name is a wield nobody can prove")
                return
            end
            local level_stat, level_wanted = setup_setlevel(cheat)
            if level_stat == "" then
                setup_failed(cheat, "not `::setlevel <stat name> <level>`: the"
                    .. " engine answers ok to it and sets nothing, and a numeric"
                    .. " stat id cannot be read back to prove it landed")
                return
            end
            local setup_result, setup_detail = t.cheat(cheat)
            if setup_result ~= "ok" then
                setup_failed(cheat, "setup cheat answered "
                    .. tostring(setup_result)
                    .. " (" .. tostring(setup_detail) .. "); last lines: "
                    .. setup_last_lines(2))
                return
            end
            if before ~= nil then
                local landed = t.inv.await(give_name, before + give_count, 10)
                if landed ~= "ok" then
                    local after_result, after_total = t.inv.count(give_name)
                    -- Short of the count asked for is the BACKPACK's
                    -- limit speaking (`Gave 21 x Egg (1944), 7 did not
                    -- fit.`), not a setup that did not happen; nothing
                    -- arriving at all is.
                    if after_result ~= "ok" or after_total <= before then
                        setup_failed(cheat, "the cheat answered ok and no "
                            .. give_name
                            .. " reached the backpack within 10 ticks (held "
                            .. tostring(before) .. " before, "
                            .. tostring(after_total) .. " after)")
                        return
                    end
                end
            elseif before_mark ~= nil then
                local moved = t.await({ level = function()
                    return setup_backpack_mark() ~= before_mark
                end, note = "setup: ::give reaching the backpack" }, 10)
                if moved ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the backpack"
                        .. " did not change within 10 ticks (" .. give_name
                        .. " is not an obj this client can count, so every"
                        .. " slot was watched instead)")
                    return
                end
            elseif worn_before ~= nil then
                local worn_last = worn_before
                local worn_landed = t.await({ level = function()
                    local read_result, reading = t.ui._worn_count(wield_name)
                    if read_result == "ok" then
                        worn_last = reading
                    end
                    return read_result == "ok" and reading > worn_before
                end, note = "setup: ::wield reaching the worn container" }, 10)
                if worn_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. wield_name
                        .. " is not worn 10 ticks later (worn " .. tostring(worn_before)
                        .. " before, " .. tostring(worn_last) .. " after); last lines: "
                        .. setup_last_lines(3))
                    return
                end
            elseif level_stat ~= nil then
                -- ok is not a level: wait for the client's reading.
                local level_last = "unread"
                local level_landed = t.await({ level = function()
                    local read_result, reading = t.skill.read(level_stat)
                    if read_result ~= "ok" then
                        level_last = tostring(read_result) .. " " .. tostring(reading)
                        return false
                    end
                    level_last = "stated=" .. tostring(reading.stated)
                        .. " base_level=" .. tostring(reading.base_level)
                    return reading.stated and reading.base_level == level_wanted
                end, note = "setup: ::setlevel reaching the client" }, 10)
                if level_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. level_stat
                        .. " never read base_level " .. tostring(level_wanted)
                        .. " within 10 ticks (last reading: " .. level_last .. ")")
                    return
                end
            elseif string.match(cheat, "^%s*:*clearinv") then
                -- The same race, and the one cheat every generated
                -- setup list opens with: an unfinished ::clearinv also
                -- makes the NEXT give's before-count wrong.
                local cleared = t.await({ level = setup_backpack_empty,
                    note = "setup: ::clearinv reaching the client" }, 10)
                if cleared ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the"
                        .. " backpack still holds items 10 ticks later")
                    return
                end
            end
        end
        -- Every OTHER cheat (::setvar, a quest's own reset
        -- debugproc) has the same one-tick reply/effect gap with no
        -- single reading to wait on, so the loop ends on the tick
        -- boundary its last reply outran.  run()'s first row reads a
        -- client that has seen the setup, which is what `setup` means.
        t.ticks(1)
        t.settle()
    end
    return quest_run(t)
end
return QUEST
