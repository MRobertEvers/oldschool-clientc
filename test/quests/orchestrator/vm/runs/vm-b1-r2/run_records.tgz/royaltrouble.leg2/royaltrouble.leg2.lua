local LEG_FROM = 2
local LEG_ONLY = false
local LEG_TILE = { 2505, 3850, 0 }
local QUEST = (function()
-- Royal Trouble (Quest Helper helpers/quests/royaltrouble/RoyalTrouble.java), authored as an
-- 8-leg relay (docs/quest_authoring/relay.md). Notes for the legs: docs/quests/ladders/royaltrouble.notes.md
return {
    id = "royaltrouble",
    fixture = "fresh_lumbridge.ini",
    setup = {
        "::clearinv",
        "::setlevel agility 40", -- guide requirement: 40 Agility (royal_royals.rs2:79 ~royaltrouble_meets_requirements)
        "::setlevel slayer 40",  -- guide requirement: 40 Slayer (same check; the snake needs it to attack)
        "::complete quest_heroes", -- guide requirement chain (Throne of Miscellania needs Heroes' Quest): misc_door_guard.rs2:10 gates the throne-room door on %varp188_heroquest = ^hero_complete
        "::royaltrouble",        -- royal_debug.rs2:35 stages Throne of Miscellania done + resets every Royal Trouble var, stands the player at the castle
    },
    bind = {
        varp = "varb2140_royal_quest",
        constants = { not_started = 0, chose_partner = 10, investigating = 20, complete = 30 },
        row = "quest_royaltrouble",
        display = "Royal Trouble",
        points = 1,
    },

    legs = {
        {
            name = "castle",
            run = function(t)
                t.ticks(3)
                t.expect("quest.stage.not_started", t.quest.expect_stage("not_started"))

                -- LEG 1 BEGIN: travelToMisc
                -- GUIDE-GAP: travelToMisc -- the pack has no boat or fairy ring from Rellekka to Miscellania (viking_sailor.rs2:1)
                -- (quest_viking/scripts/viking_sailor.rs2:1 only chats; the CIP ring is a house ring, poh_fairy_ring.rs2:72), so the
                -- sailor is talked to for real and the crossing is plain travel.
                t.exec("goto-travelToMisc", t.player.goto_tile, 2629, 3693, 0)
                t.exec("travelToMisc", t.player.talk_to, "viking_sailor", 1)
                t.exec("travelToMisc-dialog", t.chat.play, {
                    "player:Hiya.",
                    "npc:Don't talk to me outerlander",
                    "end",
                })
                t.exec("goto-misc-dock", t.player.goto_tile, 2506, 3853, 0)
                t.exec("castle-door-ground", t.player.click_loc, "castledoor", 1, { at = { 2506, 3851 } })
                t.ticks(3)

                -- goUpToGhrim / talkToGhrim
                t.exec("goUpToGhrim", t.player.click_loc, "spiralstairs_wooden", 1)
                t.ticks(3)
                t.check("goUpToGhrim-level", select(2, t.world.level()) == 1, "level " .. tostring(select(2, t.world.level())))
                t.exec("castle-door-upper", t.player.click_loc, "castledoor", 1, { at = { 2506, 3851 } })
                t.ticks(3)
                local door_r, door_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                local _, door_tile = t.world.tile()
                t.check("throneroom-door", door_tile ~= nil and door_tile.z >= 3857,
                    "click_loc -> " .. tostring(door_r) .. " (" .. tostring(door_d):sub(1, 80) .. "); tile after " .. tostring(door_tile and (door_tile.x .. "," .. door_tile.z)))
                t.ticks(3)
                t.exec("talkToGhrim", t.player.talk_to, "misc_advisor_ghrim", 1)
                t.exec("talkToGhrim-dialog", t.chat.play, {
                    "npc:Greetings, Your Royal Highness",
                    "choose:Has anything been happening in the kingdom recently?",
                    "player:Has anything been happening",
                    "npc:Interesting that you should ask",
                    "npc:the people are worried",
                    "npc:King Vargas has found himself",
                    "npc:Unfortunately, we still have not",
                    "player:So, what has he been doing",
                    "npc:He has been trying to rule",
                    "npc:The two of them have been writing",
                    "player:I see.",
                    "npc:Your Royal Highness, I suggest",
                    "choose:Yes.",
                    "player:Very well",
                    "npc:Thank you, Your Royal Highness",
                    "npc:I suggest you talk to the prince",
                })
                t.ticks(2)
                t.expect("quest.stage.chose_partner", t.quest.expect_stage("chose_partner"))

                -- goUpToPartner / talkToPartner: the guide sends the player up the north stairs to the Princess
                local back_r, back_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                local _, back_tile = t.world.tile()
                t.check("throneroom-door-out", back_tile ~= nil and back_tile.z <= 3857,
                    "click_loc -> " .. tostring(back_r) .. "; tile after " .. tostring(back_tile and (back_tile.x .. "," .. back_tile.z)))
                t.exec("goDown-afterGhrim", t.player.click_loc, "spiralstairsmiddle_wooden", 3, { at = { 2505, 3848, 1 } })
                t.ticks(3)
                t.exec("goto-goUpToPartner", t.player.goto_tile, 2506, 3867, 0)
                local n_r, n_d = t.player.click_loc("castledoor", 1, { at = { 2506, 3869, 0 } })
                t.ticks(8)
                t.check("castle-door-north-ground", true, "click_loc -> " .. tostring(n_r) .. " " .. tostring(n_d):sub(1, 80))
                t.exec("goUpToPartner", t.player.click_loc, "spiralstairs_wooden", 1, { at = { 2505, 3871, 0 } })
                t.ticks(3)
                t.check("goUpToPartner-level", select(2, t.world.level()) == 1, "level " .. tostring(select(2, t.world.level())))
                local nu_r, nu_d = t.player.click_loc("castledoor", 1, { at = { 2506, 3869, 1 } })
                t.ticks(6)
                t.check("castle-door-north-upper", true, "click_loc -> " .. tostring(nu_r) .. " " .. tostring(nu_d):sub(1, 80))
                local ar_r, ar_d = t.player.click_loc("castledoor", 1, { at = { 2504, 3867, 1 } })
                t.ticks(6)
                t.check("astrid-room-door", true, "click_loc -> " .. tostring(ar_r) .. " " .. tostring(ar_d):sub(1, 80))
                t.exec("talkToPartner", t.player.talk_to, "misc_princess_astrid", 1)
                t.exec("talkToPartner-dialog", t.chat.play, {
                    "player:Good day, your Highness",
                    "npc:Good day",
                    "player:Yes, Advisor Ghrim said",
                    "npc:I'll ask Father",
                    "player:Advisor Ghrim told me",
                    "player:What has happened while",
                    "npc:It's terrible, my dear",
                    "npc:It's awful that your work",
                    "player:What do you mean, 'an accident'",
                    "npc:Well, if my father",
                    "player:What would you suggest",
                    "npc:We can't have him declaring",
                    "npc:And I could finally show",
                    "npc:Astrid, I have an even better",
                    "npc:Better than archery",
                    "npc:I think we should persuade",
                    "npc:...What are you talking about",
                    "npc:Think of the poetic irony",
                    "npc:The best part is",
                    "npc:'Today is a happy day",
                    "npc:Our national anthems",
                    "player:I'm not sure that's such a good",
                    "npc:I quite agree",
                    "npc:Perhaps it's an odd idea",
                    "player:Are you sure it'll work",
                    "npc:Of course it will",
                    "npc:Two people who start out",
                    "player:That doesn't always work",
                    "npc:But we don't have an army",
                    "npc:So, will you talk to our father",
                    "npc:I'm sure you can manage",
                    "player:I'll give it a try",
                    "npc:I'm sure you'll manage",
                })
                t.ticks(2)
                t.expect("quest.stage.investigating", t.quest.expect_stage("investigating"))

                -- goUpToVargas / talkToVargas: back down the north stairs, along the corridor, up the south stairs
                local function door(name, sym, x, z, lvl)
                    local r, d = t.player.click_loc(sym, 1, { at = { x, z, lvl } })
                    t.ticks(6)
                    t.check(name, true, "click_loc -> " .. tostring(r) .. " " .. tostring(d):sub(1, 80))
                end
                local function level_is(name, want)
                    local lv = select(2, t.world.level())
                    t.check(name, lv == want, "level " .. tostring(lv))
                end
                t.exec("goDown-afterAstrid", t.player.click_loc, "spiralstairsmiddle_wooden", 3, { at = { 2505, 3871, 1 } })
                t.ticks(3)
                level_is("goDown-afterAstrid-level", 0)
                t.exec("goto-goUpToVargas", t.player.goto_tile, 2506, 3853, 0)
                door("castle-door-south-ground", "castledoor", 2506, 3851, 0)
                t.exec("goUpToVargas", t.player.click_loc, "spiralstairs_wooden", 1, { at = { 2505, 3848, 0 } })
                t.ticks(3)
                level_is("goUpToVargas-level", 1)
                door("castle-door-south-upper", "castledoor", 2506, 3851, 1)
                local v_r, v_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                t.check("throneroom-door-vargas", true, "click_loc -> " .. tostring(v_r) .. " " .. tostring(v_d):sub(1, 80))
                t.exec("talkToVargas", t.player.talk_to, "misc_king_vargas", 1)
                t.exec("talkToVargas-dialog", t.chat.play, {
                    "player:Your Majesty.",
                    "npc:What is it? You'll have to excuse me",
                    "player:What are you busy with",
                    "npc:Affairs of state",
                    "player:I thought I was supposed",
                    "npc:Well, there's not all that much",
                    "npc:And though you do make",
                    "player:So you're still helping",
                    "npc:In a manner of speaking",
                    "player:These 'affairs of state'",
                    "player:Would these involve",
                    "npc:Not exactly",
                    "npc:Well, yes",
                    "npc:And that's the least",
                    "npc:Some of Frodi's barrels",
                    "npc:Since you're the regent",
                    "choose:Right away, your Majesty.",
                    "player:Right away",
                    "npc:I'm glad to see",
                    "npc:All you need to do",
                    "npc:It might also be useful",
                })
                t.ticks(2)
                t.check("quest.stage.misc_set_task", select(2, t.var.server("varb2141_royal_misc")) == 10,
                    "varb2141_royal_misc = " .. tostring(select(2, t.var.server("varb2141_royal_misc"))))

                -- goDownFromVargas / talkToGunnhild
                local o_r, o_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                t.check("throneroom-door-out-vargas", true, "click_loc -> " .. tostring(o_r) .. " " .. tostring(o_d):sub(1, 80))
                t.exec("goDownFromVargas", t.player.click_loc, "spiralstairsmiddle_wooden", 3, { at = { 2505, 3848, 1 } })
                t.ticks(3)
                level_is("goDownFromVargas-level", 0)
                local function tile_is(name)
                    local _, tl = t.world.tile()
                    t.check(name, true, "tile " .. tostring(tl and (tl.x .. "," .. tl.z)))
                end
                door("castle-door-south-ground-out", "castledoor", 2506, 3851, 0)
                tile_is("walk-castle-1")
                t.player.walk_to(2505, 3853, 10)
                t.ticks(6)
                door("castle-door-west-hall", "castledoor", 2504, 3853, 0)
                tile_is("walk-castle-2")
                t.player.walk_to(2504, 3860, 20)
                t.ticks(12)
                tile_is("walk-castle-3")
                door("castle-door-lobby-west", "castledoor", 2505, 3860, 0)
                tile_is("walk-castle-4")
                t.player.walk_to(2509, 3860, 10)
                t.ticks(8)
                door("castle-door-east-exit", "castledoor", 2510, 3860, 0)
                tile_is("walk-castle-5")
                t.player.walk_to(2525, 3855, 40)
                t.ticks(30)
                tile_is("walk-castle-6")
                t.exec("talkToGunnhild", t.player.talk_to, "misc_gardener", 1)
                t.exec("talkToGunnhild-dialog", t.chat.play, {
                    "npc:Good day, Your Royal Highness",
                    "player:King Vargas tells me",
                    "npc:You mean you hadn't heard",
                    "npc:You're the only person",
                })
                t.ticks(2)
                t.check("quest.stage.misc_aboutthefts", select(2, t.var.server("varb2143_royal_misc_villagers_aboutthefts")) == 1,
                    "varb2143_royal_misc_villagers_aboutthefts = " .. tostring(select(2, t.var.server("varb2143_royal_misc_villagers_aboutthefts"))))

                -- goDownFromVargas2: the guide's route to Queen Sigrid starts down the same stairs; go back up and down once
                t.exec("goto-goDownFromVargas2", t.player.goto_tile, 2506, 3853, 0)
                door("castle-door-south-ground-2", "castledoor", 2506, 3851, 0)
                t.exec("goUp-forVargas2", t.player.click_loc, "spiralstairs_wooden", 1, { at = { 2505, 3848, 0 } })
                t.ticks(3)
                level_is("goUp-forVargas2-level", 1)
                door("castle-door-south-upper-2", "castledoor", 2506, 3851, 1)
                t.exec("goDownFromVargas2", t.player.click_loc, "spiralstairsmiddle_wooden", 3, { at = { 2505, 3848, 1 } })
                t.ticks(3)
                level_is("goDownFromVargas2-level", 0)
                local _, e_tile = t.world.tile()
                local _, e_stage = t.var.server("varb2140_royal_quest")
                local _, e_misc = t.var.server("varb2141_royal_misc")
                t.check("leg.1.state", t.chat.kind() == "none", "tile " .. tostring(e_tile and (e_tile.x .. "," .. e_tile.z)) .. " level 0, varb2140_royal_quest=" .. tostring(e_stage) .. " varb2141_royal_misc=" .. tostring(e_misc) .. ", backpack empty")
                -- LEG 1 END
            end,
        },
        {
            name = "etceteria",
            run = function(t)
                -- LEG 2 BEGIN: goUpToSigrid
                local function door(name, sym, x, z, lvl)
                    local r, d = t.player.click_loc(sym, 1, { at = { x, z, lvl } })
                    t.ticks(6)
                    t.check(name, true, "click_loc -> " .. tostring(r) .. " " .. tostring(d):sub(1, 80))
                end
                local function level_is(name, want)
                    local lv = select(2, t.world.level())
                    t.check(name, lv == want, "level " .. tostring(lv))
                end
                local function stage_is(name, var, want)
                    local v = select(2, t.var.server(var))
                    t.check(name, v == want, var .. " = " .. tostring(v) .. " (want " .. tostring(want) .. ")")
                end

                -- goUpToSigrid / talkToSigrid
                t.exec("goto-goUpToSigrid", t.player.goto_tile, 2614, 3865, 0)
                t.exec("goUpToSigrid", t.player.click_loc, "spiralstairs", 1, { at = { 2613, 3867, 0 } })
                t.ticks(3)
                level_is("goUpToSigrid-level", 1)
                door("castle-door-sigrid", "castledoor", 2615, 3870, 1)
                t.exec("talkToSigrid", t.player.talk_to, "misc_queen_sigrid", 1)
                t.exec("talkToSigrid-dialog", t.chat.play, {
                    "player:Your Majesty, do you have a moment?",
                    "npc:Incompetent!",
                    "npc:Yes, what is it?",
                    "player:I hear from King Vargas",
                    "npc:Of course not!",
                    "npc:That idiot Vargas",
                    "npc:I suppose all those insults",
                    "npc:Even so, that doesn't excuse",
                    "player:What happened, your Majesty?",
                    "npc:My citizens have told me",
                    "npc:Since you're the one",
                    "choose:Of course, it's my duty.",
                    "player:Of course, it's my duty.",
                    "npc:I'm glad you understand.",
                    "npc:If you talk to the citizens",
                    "npc:I would find out for myself",
                })
                t.ticks(2)
                stage_is("quest.stage.etc_sigrid_talked", "varb2142_royal_etc", 10)

                -- goDownFromSigridToMatilda / talkToMatilda
                t.exec("goDownFromSigridToMatilda", t.player.click_loc, "spiralstairstop", 1)
                t.ticks(3)
                level_is("goDownFromSigridToMatilda-level", 0)
                -- Etceteria's street is walled off from the stair room's south door (2613,3864 only opens onto a
                -- closed alley); the way to Matilda's hut is west through the hall door 2611,3866, north along the
                -- hall and out through the double castle doors 2609,3875 / 2608,3875 into the market lane
                door("castle-door-hall", "castledoor", 2611, 3866, 0)
                t.player.walk_to(2609, 3874, 20)
                t.ticks(2)
                t.check("walk-to-hall-north", select(2, t.world.tile()).x == 2609, "stood at " .. tostring(select(2, t.world.tile()).x) .. "," .. tostring(select(2, t.world.tile()).z))
                door("castle-door-lane-east", "castledoor", 2609, 3875, 0)
                door("castle-door-lane-west", "castledoor", 2608, 3875, 0)
                t.player.walk_to(2603, 3875, 20)
                t.ticks(2)
                t.check("walk-to-matilda-street", select(2, t.world.tile()).z == 3875, "stood at " .. tostring(select(2, t.world.tile()).x) .. "," .. tostring(select(2, t.world.tile()).z))
                door("matilda-house-door", "misc_viking_abode_door_low", 2603, 3874, 0)
                t.player.walk_near(t.player.by_symbol("npc", "misc_etc_woman_2"), 20)
                t.ticks(2)
                t.exec("talkToMatilda", t.player.talk_to, "misc_etc_woman_2", 1)
                t.exec("talkToMatilda-dialog", t.chat.play, {
                    "player:Excuse me...",
                    "npc:Yes?",
                    "player:Queen Sigrid tells me",
                    "npc:You haven't heard about that",
                    "npc:I'm surprised.",
                    "npc:Well, Miscellanian soldiers came",
                    "npc:When I told them to leave",
                    "npc:It was a wonderful hat",
                    "npc:Could you please get it back",
                    "player:I'll see what I can do.",
                })
                t.ticks(2)
                stage_is("quest.stage.etc_aboutthefts", "varb2144_royal_etc_villagers_aboutthefts", 1)

                -- getCoalOrPickaxe: the guide's bank visit. Etceteria's cache has no dwarf_keldagrim_bankbooth at the
                -- guide's 2612,3900 (that tile is a house wall); the town's bank is the bank table
                -- banktable_breakroute_bankable 2619,3894 (bank_booths.rs2:72 oploc2, the same ~openbank). Nothing is
                -- banked on a fresh account and the pickaxe is picked up in the dungeon (royal_dungeon.rs2:195), so it is opened and closed
                t.exec("getCoalOrPickaxe", t.player.click_loc, "banktable_breakroute_bankable", 2, { at = { 2619, 3894, 0 } })
                t.ticks(4)
                local _, bank_open = t.ui.is_modal()
                t.check("getCoalOrPickaxe-open", bank_open == true, "bank table op2 -> modal open=" .. tostring(bank_open))
                t.key("escape")
                t.ticks(2)

                -- goDownFromSigridToVargas: the guide's second descent of Sigrid's stairs (back up once, then down)
                t.exec("goto-goDownFromSigridToVargas", t.player.goto_tile, 2614, 3865, 0)
                t.exec("goUp-forSigrid2", t.player.click_loc, "spiralstairs", 1, { at = { 2613, 3867, 0 } })
                t.ticks(3)
                level_is("goUp-forSigrid2-level", 1)
                t.exec("goDownFromSigridToVargas", t.player.click_loc, "spiralstairstop", 1)
                t.ticks(3)
                level_is("goDownFromSigridToVargas-level", 0)

                -- goBackUpToVargasFromSigrid / talkToVargasAfterSigrid
                t.exec("goto-goBackUpToVargasFromSigrid", t.player.goto_tile, 2506, 3853, 0)
                door("castle-door-south-ground-3", "castledoor", 2506, 3851, 0)
                t.exec("goBackUpToVargasFromSigrid", t.player.click_loc, "spiralstairs_wooden", 1, { at = { 2505, 3848, 0 } })
                t.ticks(3)
                level_is("goBackUpToVargasFromSigrid-level", 1)
                door("castle-door-south-upper-3", "castledoor", 2506, 3851, 1)
                local v_r, v_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                t.check("throneroom-door-vargas-2", true, "click_loc -> " .. tostring(v_r) .. " " .. tostring(v_d):sub(1, 80))
                t.exec("talkToVargasAfterSigrid", t.player.talk_to, "misc_king_vargas", 1)
                t.exec("talkToVargasAfterSigrid-dialog", t.chat.play, {
                    "player:Your Majesty.",
                    "npc:Have you spoken to the citizens yet",
                    "player:I've spoken to the Miscellanian citizens, and also",
                    "npc:What did they say?",
                    "player:The Miscellanian citizens said",
                    "npc:What?",
                    "npc:I see. Sigrid thinks",
                    "player:...and the Etceterian citizens",
                    "npc:And she's even started",
                    "player:Your Majesty...",
                    "npc:Lying to her own people",
                    "npc:Which makes it all the worse",
                    "player:I'm not sure that would work",
                    "npc:Perhaps not",
                    "npc:In any case",
                    "npc:Ask Advisor Ghrim",
                    "npc:He's a capable advisor",
                    "player:I'll do that, your Majesty.",
                })
                t.ticks(2)
                stage_is("quest.stage.misc_reported", "varb2141_royal_misc", 20)

                -- goUpToGhrim2 / talkToGhrim2: down the stairs and up again, as the guide routes it
                local o_r, o_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                t.check("throneroom-door-out-2", true, "click_loc -> " .. tostring(o_r) .. " " .. tostring(o_d):sub(1, 80))
                t.exec("goDown-beforeGhrim2", t.player.click_loc, "spiralstairsmiddle_wooden", 3, { at = { 2505, 3848, 1 } })
                t.ticks(3)
                level_is("goDown-beforeGhrim2-level", 0)
                door("castle-door-south-ground-4", "castledoor", 2506, 3851, 0)
                t.exec("goUpToGhrim2", t.player.click_loc, "spiralstairs_wooden", 1, { at = { 2505, 3848, 0 } })
                t.ticks(3)
                level_is("goUpToGhrim2-level", 1)
                door("castle-door-south-upper-4", "castledoor", 2506, 3851, 1)
                local g_r, g_d = t.player.click_loc("misc_ulby_throneroomdoor", 1, { at = { 2506, 3857, 1 } })
                t.ticks(8)
                t.check("throneroom-door-ghrim-2", true, "click_loc -> " .. tostring(g_r) .. " " .. tostring(g_d):sub(1, 80))
                t.exec("talkToGhrim2", t.player.talk_to, "misc_advisor_ghrim", 1)
                t.exec("talkToGhrim2-dialog", t.chat.play, {
                    "npc:Greetings, Your Royal Highness",
                    "choose:King Vargas asked me to talk to you.",
                    "player:King Vargas asked me to talk to you.",
                    "player:He said you might know",
                    "npc:I'm not sure what you're implying",
                    "player:Er... that you could advise",
                    "npc:Ah, of course.",
                    "npc:Assuming that nobody",
                    "npc:it is of course likely",
                    "npc:The sailor who brought you",
                    "npc:I suggest you ask him",
                })
                t.ticks(2)
                stage_is("quest.stage.misc_ghrim_talked", "varb2141_royal_misc", 30)
                local _, e_tile = t.world.tile()
                local _, e_stage = t.var.server("varb2140_royal_quest")
                local _, e_misc = t.var.server("varb2141_royal_misc")
                t.check("leg.2.end", t.chat.kind() == "none", "tile " .. tostring(e_tile and (e_tile.x .. "," .. e_tile.z)) .. " level " .. tostring(select(2, t.world.level())) .. ", varb2140_royal_quest=" .. tostring(e_stage) .. " varb2141_royal_misc=" .. tostring(e_misc) .. " (Ghrim sent the player to the sailor), backpack empty")
                -- LEG 2 END
            end,
        },
    },
}

end)()

if type(QUEST) == "table" and QUEST.legs ~= nil then
    local legs_quest = QUEST
    QUEST = { setup = legs_quest.setup, run = function(t)
        return t.core_legs_drive(legs_quest, { from = LEG_FROM, only = LEG_ONLY, tile = LEG_TILE })
    end }
end
if type(QUEST) ~= "table" or type(QUEST.run) ~= "function" then
    error("quest file did not return { run = function(t) ... end }"
        .. " or { legs = { { name =, run = function(t) ... end }, ... } }")
end
local quest_setup = QUEST.setup
-- A setup that is not a list of cheat lines is a setup nobody reads:
-- refuse it rather than run the quest against an unstated world.
if quest_setup ~= nil and type(quest_setup) ~= "table" then
    error("quest file's setup is a " .. type(quest_setup)
        .. ", not a table of cheat lines")
end
-- A checkpoint run resumes a player who already went through setup
-- (and legs 1..K-1): the setup list is NOT run again.
if LEG_FROM and LEG_FROM > 1 then
    quest_setup = nil
end
local quest_run = QUEST.run
QUEST.run = function(t)
    -- WAIT FOR THE LOGIN GRANT before the first setup cheat.
    --
    -- The backpack a fixture starts with is not in the fixture: the
    -- containers are adopted EMPTY (torirs_server_world.c, "what goes
    -- in them the first time a character connects is content's") and
    -- content's [login,_] -> [proc,newplayer_inv] fills them on a
    -- later tick than the one this script starts on.  Measured
    -- 2026-09-19 (build/quest_gate/closer_setup2 row 1,
    -- closer_setup3): `::clearinv` issued on the first frame answers
    -- "Cleared 0 item(s).", the fourteen tutorial slots land behind
    -- it, and a `::give` before the grant is overwritten by it -- a
    -- setup list that answered `ok` three times and left the world it
    -- promised in none of them.  A fixed `t.ticks(n)` does not fix it
    -- (the grant landed on tick 1 in one run and after three cheats in
    -- the next); the arrival itself is the signal, so wait for it.
    --
    -- Bounded, and proceeding either way: a fixture whose character
    -- really does hold nothing pays the budget and runs its setup
    -- anyway, rather than failing a quest over an empty backpack.
    t.await({ level = function()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return true
            end
        end
        return false
    end, note = "setup: the login grant" }, 10)
    t.settle()
    -- A CHEAT'S REPLY OUTRUNS ITS EFFECT by exactly one server tick.
    --
    -- t.cheat waits for the reply line (core.lua: QD.cheat ->
    -- msg.await), and the server SAYS `Gave 3 x Egg (1944).` from
    -- inside the ladder branch itself, while the backpack the same
    -- branch just wrote reaches the client in the container
    -- listener's UPDATE_INV at the END of that tick
    -- (torirs_server_world.c, the ::give branch: `the backpack's
    -- listener sends an UPDATE_INV without this branch knowing a
    -- packet exists`).  So the setup loop used to hand run() a client
    -- that had heard about the items and not yet received them, and
    -- every quest whose first rows read t.inv.count saw an empty
    -- backpack from a setup that had answered `ok` three times.
    -- Measured 2026-09-21 (build/quest_gate/lag_probe): row `lag.t0`
    -- FAIL `egg: absent`, row `lag.t1` -- one t.ticks(1) later --
    -- PASS `3`.  Two seam fixers reported it as `::give from setup
    -- lands nothing` (docs/QUEST_AUTHORING.md trap 23).
    --
    -- A ::give is therefore not done when it answers: it is done when
    -- the CLIENT can count the items, which is also the only check
    -- that catches the ladder's own silent misses -- `::give
    -- nosuchitemname` and an ambiguous name both `say()` their
    -- complaint and return RAN, i.e. `ok`, having given nothing
    -- (same file, `No item named '%s'.` / `Which %s? %s`).  Each one
    -- is now a FAIL row named after the cheat, exactly like a cheat
    -- that answered no_row.
    local function setup_give(text)
        local name, count = string.match(text, "^%s*:*give%s+([%w_]+)%s*(%d*)")
        if not name then
            return nil
        end
        local wanted = tonumber(count)
        if not wanted or wanted < 1 then
            wanted = 1
        end
        return name, wanted
    end
    -- Name-free fingerprint of the backpack: every slot's count, plus
    -- one per occupied slot so an item ARRIVING in an empty slot
    -- moves it too.  What the fallback below watches when a ::give
    -- names something this client cannot count.
    local function setup_backpack_mark()
        local mark = 0
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                mark = mark + cell.count + 1
            end
        end
        return mark
    end
    local function setup_backpack_empty()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return false
            end
        end
        return true
    end
    -- `::setlevel <stat> <level>` -> stat, level; nil for any other line.
    -- A line that STARTS as a setlevel (the engine's own strncmp prefix)
    -- but does not parse is ("", nil): the engine answers ok to it
    -- and sets nothing.
    local function setup_setlevel(text)
        if not string.match(text, "^%s*:*setlevel") then
            return nil
        end
        local stat, level = string.match(text, "^%s*:*setlevel%s+(%a[%w_]*)%s+(%d+)%s*$")
        if not stat then
            return "", nil
        end
        return stat, tonumber(level)
    end
    -- `::wield <item>` -> item; nil for any other line.  The cheat
    -- answers once the synthesized Wield click is SENT (seam pass 29:
    -- it used to take only an obj id, print its Usage line for a name
    -- and answer ok -- arthur fought Mordred unarmed behind a green
    -- setup), and content may still refuse the wield (a level, a
    -- quest), so the line is done only when the WORN container holds
    -- the item (QD.ui._worn_count, ui.lua).
    local function setup_wield(text)
        return string.match(text, "^%s*:*wield%s+([%w_]+)%s*$")
    end
    local function setup_last_lines(n)
        local lines_result, rows = t.msg.last(n)
        if lines_result ~= "ok" or type(rows) ~= "table" then
            return "(no chat lines)"
        end
        local texts = {}
        for i = 1, #rows do
            texts[#texts + 1] = "'" .. tostring(rows[i].text) .. "'"
        end
        return table.concat(texts, " / ")
    end
    local function setup_failed(cheat, why)
        t.step("setup." .. cheat, "FAIL",
            why .. " -- the world this quest assumes was never stated")
        t.finish(1)
    end
    if type(quest_setup) == "table" then
        for _, cheat in ipairs(quest_setup) do
            -- Counted BEFORE the cheat: a setup list that gives the
            -- same item twice, or gives one the login grant already
            -- put there, is waiting for an INCREASE, not for a total.
            local give_name, give_count = setup_give(cheat)
            local before = nil
            local before_mark = nil
            if give_name then
                local count_result, count_total = t.inv.count(give_name)
                if count_result == "ok" then
                    before = count_total
                else
                    -- A name this client cannot resolve to an obj: the
                    -- server's own cheat_obj_from_name is fuzzy and may
                    -- still have matched one -- but `::give
                    -- nosuchitemname` reaches the SAME `ok` (it say()s
                    -- `No item named` and returns RAN), so the whole
                    -- backpack is watched for any movement instead of
                    -- taking the cheat at its word.
                    before_mark = setup_backpack_mark()
                end
            end
            local wield_name = setup_wield(cheat)
            local worn_before = nil
            if wield_name then
                local worn_result, worn_count = t.ui._worn_count(wield_name)
                if worn_result ~= "ok" then
                    setup_failed(cheat, "cannot read the worn container for "
                        .. wield_name .. " (" .. tostring(worn_result) .. " "
                        .. tostring(worn_count) .. "), so a wield could never be"
                        .. " proved")
                    return
                end
                worn_before = worn_count
            elseif string.match(cheat, "^%s*:*wield") then
                setup_failed(cheat, "not `::wield <item_name>`: a line the"
                    .. " read-back cannot name is a wield nobody can prove")
                return
            end
            local level_stat, level_wanted = setup_setlevel(cheat)
            if level_stat == "" then
                setup_failed(cheat, "not `::setlevel <stat name> <level>`: the"
                    .. " engine answers ok to it and sets nothing, and a numeric"
                    .. " stat id cannot be read back to prove it landed")
                return
            end
            local setup_result, setup_detail = t.cheat(cheat)
            if setup_result ~= "ok" then
                setup_failed(cheat, "setup cheat answered "
                    .. tostring(setup_result)
                    .. " (" .. tostring(setup_detail) .. "); last lines: "
                    .. setup_last_lines(2))
                return
            end
            if before ~= nil then
                local landed = t.inv.await(give_name, before + give_count, 10)
                if landed ~= "ok" then
                    local after_result, after_total = t.inv.count(give_name)
                    -- Short of the count asked for is the BACKPACK's
                    -- limit speaking (`Gave 21 x Egg (1944), 7 did not
                    -- fit.`), not a setup that did not happen; nothing
                    -- arriving at all is.
                    if after_result ~= "ok" or after_total <= before then
                        setup_failed(cheat, "the cheat answered ok and no "
                            .. give_name
                            .. " reached the backpack within 10 ticks (held "
                            .. tostring(before) .. " before, "
                            .. tostring(after_total) .. " after)")
                        return
                    end
                end
            elseif before_mark ~= nil then
                local moved = t.await({ level = function()
                    return setup_backpack_mark() ~= before_mark
                end, note = "setup: ::give reaching the backpack" }, 10)
                if moved ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the backpack"
                        .. " did not change within 10 ticks (" .. give_name
                        .. " is not an obj this client can count, so every"
                        .. " slot was watched instead)")
                    return
                end
            elseif worn_before ~= nil then
                local worn_last = worn_before
                local worn_landed = t.await({ level = function()
                    local read_result, reading = t.ui._worn_count(wield_name)
                    if read_result == "ok" then
                        worn_last = reading
                    end
                    return read_result == "ok" and reading > worn_before
                end, note = "setup: ::wield reaching the worn container" }, 10)
                if worn_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. wield_name
                        .. " is not worn 10 ticks later (worn " .. tostring(worn_before)
                        .. " before, " .. tostring(worn_last) .. " after); last lines: "
                        .. setup_last_lines(3))
                    return
                end
            elseif level_stat ~= nil then
                -- ok is not a level: wait for the client's reading.
                local level_last = "unread"
                local level_landed = t.await({ level = function()
                    local read_result, reading = t.skill.read(level_stat)
                    if read_result ~= "ok" then
                        level_last = tostring(read_result) .. " " .. tostring(reading)
                        return false
                    end
                    level_last = "stated=" .. tostring(reading.stated)
                        .. " base_level=" .. tostring(reading.base_level)
                    return reading.stated and reading.base_level == level_wanted
                end, note = "setup: ::setlevel reaching the client" }, 10)
                if level_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. level_stat
                        .. " never read base_level " .. tostring(level_wanted)
                        .. " within 10 ticks (last reading: " .. level_last .. ")")
                    return
                end
            elseif string.match(cheat, "^%s*:*clearinv") then
                -- The same race, and the one cheat every generated
                -- setup list opens with: an unfinished ::clearinv also
                -- makes the NEXT give's before-count wrong.
                local cleared = t.await({ level = setup_backpack_empty,
                    note = "setup: ::clearinv reaching the client" }, 10)
                if cleared ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the"
                        .. " backpack still holds items 10 ticks later")
                    return
                end
            end
        end
        -- Every OTHER cheat (::setvar, a quest's own reset
        -- debugproc) has the same one-tick reply/effect gap with no
        -- single reading to wait on, so the loop ends on the tick
        -- boundary its last reply outran.  run()'s first row reads a
        -- client that has seen the setup, which is what `setup` means.
        t.ticks(1)
        t.settle()
    end
    return quest_run(t)
end
return QUEST
