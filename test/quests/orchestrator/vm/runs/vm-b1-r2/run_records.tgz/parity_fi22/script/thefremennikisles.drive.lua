local LEG_FROM = nil
local LEG_ONLY = false
local LEG_TILE = nil
local QUEST = (function()
-- The Fremennik Isles parity driver (scratch; vm-b1). Every guide step in TheFremennikIsles.java is a
-- click, a talk, a use, a shop buy or a fight. START picks the first leg, LAST the final one: a run of
-- one leg stages the earlier ones with ::setvar/::give (the full run is START=1, LAST=99).
local START = 15
local LAST = 15

return {
    id = "thefremennikisles_parity",
    fixture = "fresh_lumbridge.ini",
    setup = {
        "::clearinv",
        "::setlevel mining 2",
        "::setlevel agility 45",
        "::setlevel construction 45",
        "::setlevel woodcutting 70",
        "::setlevel crafting 70",
        "::setlevel hitpoints 99",
        "::setlevel attack 90",
        "::setlevel strength 90",
        "::setlevel defence 99",
        "::setlevel prayer 60",
        "::fremennikisles",
        "::give coins 120000",
        "::give knife 1",
        "::give needle 1",
        "::give thread 6",
        "::give hammer 1",
        "::give nails_bronze 2",
        "::give rune_axe 1",
        "::give rune_scimitar 1",
    },

    run = function(t)
        t.quest.bind({
            varp = "varb3311_fris_quest",
            constants = { not_started = 0, complete = 340 },
            display = "The Fremennik Isles",
            points = 1,
        })
        t.ticks(3)

        local function say(name, npc, op)
            return t.exec(name, t.player.talk_to, npc, op or 1)
        end
        -- walk a conversation through every page; pick `choices` rows in order when options appear;
        -- `counts` answers count prompts in order
        local function convo(name, choices, counts)
            local i, c, stuck = 0, 0, 0
            for guard = 1, 160 do
                local r, k = t.chat.drain({ stop_at = "options" })
                local want_count = counts and counts[c + 1] ~= nil
                if k == "options" then
                    i = i + 1
                    local ch = choices and choices[i]
                    if ch == nil then
                        t.check(name .. ".unexpected_options", false, "no choice scripted for options page " .. i .. ": " .. tostring(select(2, t.chat.options())))
                        return
                    end
                    t.exec(name .. ".choose" .. i, t.chat.choose, ch)
                elseif want_count and (k == "count" or (r == "refused" and string.find(tostring(k), "resume is already outstanding", 1, true))) then
                    -- an "Enter amount:" count prompt (chat.kind() can still read the page before it)
                    local cr, cd = t.chat.count(counts[c + 1])
                    if cr == "ok" then
                        c = c + 1
                        t.check(name .. ".count" .. c, true, tostring(cd))
                        stuck = 0
                    else
                        stuck = stuck + 1
                        if stuck > 12 then
                            t.check(name .. ".count_stuck", false, "chat.count answered " .. tostring(cr))
                            return
                        end
                    end
                    t.ticks(2)
                else
                    t.check(name .. ".done", r, "drain " .. tostring(r) .. " kind=" .. tostring(k))
                    return
                end
            end
        end
        local function var(name, want)
            local r, v = t.var.server(name)
            t.check("var." .. name .. "=" .. tostring(want), v == want, name .. " server=" .. tostring(v))
        end
        local function stage(want) var("varb3311_fris_quest", want) end
        local function count(item) t.ticks(2); local r, c = t.inv.count(item); return c or 0 end
        local function has(item, n)
            local c = count(item)
            t.check("inv." .. item .. ">=" .. n, c >= n, item .. " count=" .. tostring(c))
        end
        local function setv(name, val)
            t.cheat("::setvar " .. name .. " " .. tostring(val), true)
            t.ticks(2)
        end
        local function setstage(n) setv("varb3311_fris_quest", n) end
        local function give(item, n) t.cheat("::give " .. item .. " " .. tostring(n or 1), true); t.ticks(1) end
        local function at(name, x, z, l) return t.exec("goto-" .. name, t.player.goto_tile, x, z, l or 0) end
        local function tile_near(name, x, z, r)
            local _, tl = t.world.tile()
            local ok = tl ~= nil and math.abs(tl.x - x) <= r and math.abs(tl.z - z) <= r
            t.check(name, ok, "tile " .. tostring(tl and tl.x) .. "," .. tostring(tl and tl.z) .. " want near " .. x .. "," .. z)
        end


        local function wear_jester()
            for _, it in ipairs({ "frisd_jester_hat", "frisd_jester_top", "frisd_jester_legs", "frisd_jester_boots" }) do
                t.exec("wear-" .. it, t.player.equip, it)
                t.ticks(1)
            end
        end
        local function strip_jester()
            for _, it in ipairs({ "frisd_jester_hat", "frisd_jester_top", "frisd_jester_legs", "frisd_jester_boots" }) do
                t.exec("remove-" .. it, t.player.unequip, it)
                t.ticks(1)
            end
        end
        local BUTTONS = { "frisd_talkbutton", "frisd_dancebutton", "frisd_jugglebutton", "frisd_skipbutton", "frisd_piebutton", "frisd_jigbutton", "frisd_bowbutton" }
        -- play the whole act: read the instruction Mawnis shouted (the server's want var) and press that button;
        -- `wrong` = press the wrong one on instruction number `wrong` to fail the act on purpose
        local function perform(name, wrong)
            -- the fade and the council's lines come after the intro: keep paging until the act is running
            for guard = 1, 60 do
                local _, st = t.var.server("varp7214_fris_jester_step")
                if st ~= nil and st > 0 then break end
                t.chat.drain({ stop_at = "options" })
                t.ticks(2)
            end
            t.ticks(2)
            local _, w0 = t.ui.widget("frisd_jestertask:frisd_dancebutton")
            t.check(name .. ".panel_open", w0 ~= nil, "frisd_jestertask panel mounted: " .. tostring(w0))
            local _, mm = t.var.varbit("varb6719_minimap_state")
            t.check(name .. ".minimap_blank", mm == 2, "minimap_state=" .. tostring(mm))
            local done, n = false, 0
            do
                local r1, v1 = t.var.server("varp7214_fris_jester_step")
                local r2, v2 = t.var.server("varp7215_fris_jester_want")
                t.check(name .. ".vars_readable", v1 ~= nil, "step=" .. tostring(v1) .. " (" .. tostring(r1) .. ") want=" .. tostring(v2) .. " (" .. tostring(r2) .. ")")
            end
            for tick = 1, 260 do
                local _, step = t.var.server("varp7214_fris_jester_step")
                if step == 0 and n > 0 then done = true; break end
                local _, want = t.var.server("varp7215_fris_jester_want")
                if want ~= nil and want > 0 then
                    n = n + 1
                    local btn = BUTTONS[want]
                    if wrong and n == wrong then btn = BUTTONS[(want % 7) + 1] end
                    local _, w = t.ui.widget("frisd_jestertask:" .. btn)
                    local pr = t.ui.invoke(w, 1)
                    t.check(name .. ".press" .. n .. "." .. btn, pr == "ok", "invoked " .. btn .. " for want=" .. tostring(want) .. (wrong and n == wrong and " (deliberately wrong)" or ""))
                    t.ticks(1)
                else
                    t.ticks(1)
                end
            end
            t.check(name .. ".act_over", done, "instructions pressed: " .. n)
            return n
        end


        local function heal(minhp)
            for k = 1, 12 do
                local _, rd = t.skill.read("hitpoints")
                if rd ~= nil and rd.level >= minhp then return end
                local food = "lobster"
                if count("lobster") == 0 then food = "tuna" end
                t.player.inv_op(food, 1)
                t.ticks(3)
            end
        end
        local PINES = { { 2315, 3788 }, { 2319, 3787 }, { 2322, 3786 }, { 2325, 3788 }, { 2328, 3790 }, { 2334, 3792 }, { 2338, 3791 }, { 2348, 3793 } }
        -- fell arctic pines until `want` logs are held (real clicks; level 54 needed)
        local function chop_to(want)
            for ti, tr in ipairs(PINES) do
                if count("arctic_pine_log") >= want then break end
                at("pine" .. ti, tr[1] - 1, tr[2] + 1)
                for k = 1, 8 do
                    if count("arctic_pine_log") >= want then break end
                    local got = count("arctic_pine_log")
                    t.exec("chop" .. ti .. "." .. k, t.player.click_loc, "arctic_pine", 1)
                    t.inv.await("arctic_pine_log", got + 1, 60)
                end
            end
            has("arctic_pine_log", want)
        end
        local function spin_all_hair()
            local wheel = t.player.by_symbol("loc", "iznot_spinning_wheel")
            for i = 1, 9 do
                local before = count("rope")
                local ur, ud = t.player.use_on("yak_hair", wheel)
                local mr = t.ui.await_open("skillmulti", 10)
                local cr, cell = t.ui.widget("skillmulti:a")
                local pr = t.ui.invoke(cell, 1)
                t.inv.await("rope", before + 1, 40)
                t.check("spinHair" .. i, mr == "ok" and cr == "ok" and pr == "ok" and count("rope") == before + 1, "use_on=" .. tostring(ur) .. " skillmulti open=" .. tostring(mr) .. " cell=" .. tostring(cr) .. " invoke=" .. tostring(pr) .. " rope " .. before .. " -> " .. count("rope"))
            end
        end

        -- ------------------------------------------------ leg 1: Mord, the king, the cat, the ore
        if START <= 1 and LAST >= 1 then
            at("mord", 2644, 3708)
            say("talkToMord", "fris_r_ferryman_rellekka")
            convo("mord.start", { "Yes.", "Can you ferry me to Jatizso?" })
            stage(5)
            t.ticks(3)
            tile_near("travelToJatizso", 2421, 3783, 6)

            at("king", 2407, 3801)
            say("talkToGjuki", "fris_r_king")
            convo("gjuki.intro", {})
            stage(10)

            -- raw tuna: buy it from Flosi Dalksson (the wiki's other source is the south pier)
            at("flosi", 2418, 3812)
            t.exec("flosi.shop", t.shop.open, "frisd_fishmerchant", 3, "frisd_fishmonger")
            t.exec("flosi.buy_tuna", t.shop.buy, "raw_tuna", 1)
            t.shop.close()
            has("raw_tuna", 1)

            at("cat", 2407, 3801)
            local cat = t.player.by_symbol("npc", "fris_r_kingscat")
            t.exec("feedHrafn", t.player.use_on, "raw_tuna", cat)
            t.ticks(2)
            convo("hrafn", {})
            stage(20)
            say("talkToGjuki-ore", "fris_r_king")
            convo("gjuki.ore_speech", {})
            stage(30)

            -- Mining level 2: seven coal, bought from Hring Hring (the wiki: coal can be bought from him)
            at("hring", 2398, 3797)
            t.exec("hring.shop", t.shop.open, "frisd_oremerchant", 3, "frisd_oreshop")
            t.exec("hring.buy_coal", t.shop.buy, "coal", 7)
            t.shop.close()
            has("coal", 7)

            at("thorkel", 2408, 3805)
            local before = count("coins")
            say("bringOreToGjuki", "fris_r_chancellor")
            convo("thorkel.ore", {})
            t.check("ore.coins", count("coins") >= before + 10000 - 0, "coins " .. before .. " -> " .. count("coins"))
            t.check("ore.consumed", count("coal") == 0, "coal left " .. count("coal"))
            stage(50)
        end

        -- ------------------------------------------------ leg 2: the jester outfit, Neitiznot, Slug
        if START <= 2 and LAST >= 2 then
            if START == 2 then setstage(50) end
            at("chest", 2407, 3801)
            t.exec("getJesterOutfit.open", t.player.click_loc, "fris_chest_closed", 1)
            t.ticks(2)
            t.exec("getJesterOutfit.search", t.player.click_loc, "fris_chest_open", 1)
            convo("chest", { "Take the jester's hat.", "Take the jester's top.", "Take the jester's tights.", "Take the jester's boots.", "Leave the chest." })
            has("frisd_jester_hat", 1); has("frisd_jester_top", 1); has("frisd_jester_legs", 1); has("frisd_jester_boots", 1)

            at("izso-dock", 2420, 3783)
            say("returnToRellekka", "fris_r_ferryman_izso")
            convo("mord.back", { "Can you ferry me to Rellekka?" })
            t.ticks(3)
            tile_near("rellekka", 2644, 3709, 4)
            at("maria", 2644, 3711)
            say("travelToNeitiznot", "fris_r_ferry_rellikka")
            convo("maria.ferry", { "Can you ferry me to Neitiznot?" })
            t.ticks(3)
            tile_near("neitiznot", 2312, 3783, 6)
        end

        -- ------------------------------------------------ leg 3: Slug, the first performance
        if START <= 3 and LAST >= 3 then
            if START == 3 then
                setstage(50)
                give("frisd_jester_hat"); give("frisd_jester_top"); give("frisd_jester_legs"); give("frisd_jester_boots")
                at("slug", 2336, 3809)
            else
                at("slug", 2336, 3809)
            end
            -- not in the outfit: the password works but "I am ready" is refused
            say("talkToSlug.undressed", "fris_spymaster")
            convo("slug.undressed", { "Free stuff please.", "I am ready." })
            stage(50)
            wear_jester()
            -- a weapon in the hand is refused too
            t.exec("equip-scimitar", t.player.equip, "rune_scimitar"); t.ticks(1)
            say("talkToSlug.armed", "fris_spymaster")
            convo("slug.armed", { "Free stuff please.", "I am ready." })
            stage(50)
            t.exec("unequip-scimitar", t.player.unequip, "rune_scimitar"); t.ticks(1)
            say("talkToSlug", "fris_spymaster")
            convo("slug.ready", { "Free stuff please.", "I am ready." })
            stage(55)
        end

        -- ------------------------------------------------ leg 4: perform for Mawnis (fail once, then succeed)
        if START <= 4 and LAST >= 4 then
            if START == 4 then
                setstage(55)
                give("frisd_jester_hat"); give("frisd_jester_top"); give("frisd_jester_legs"); give("frisd_jester_boots")
                wear_jester()
            end
            at("mawnis", 2341, 3799)
            -- hands not empty: refused before the fade
            t.exec("equip-scimitar2", t.player.equip, "rune_scimitar"); t.ticks(1)
            say("goSpyOnMawnis.armed", "fris_r_burgher")
            convo("mawnis.armed", {})
            stage(55)
            t.exec("unequip-scimitar2", t.player.unequip, "rune_scimitar"); t.ticks(1)
            -- first act: press a wrong button on the 2nd instruction
            say("goSpyOnMawnis.fail", "fris_r_burgher")
            convo("mawnis.act1", {})
            perform("act1", 2)
            t.ticks(6)
            convo("mawnis.act1.end", {})
            stage(55)
            -- second try: every instruction followed
            say("goSpyOnMawnis", "fris_r_burgher")
            convo("mawnis.act2", {})
            perform("performForMawnis")
            t.ticks(6)
            convo("mawnis.act2.end", {})
            stage(60)
        end

        -- ------------------------------------------------ leg 5: report to Slug (wrong answers first)
        if START <= 5 and LAST >= 5 then
            if START == 5 then setstage(60) end
            at("slug2", 2336, 3809)
            local b = count("coins")
            say("tellSlugReport1.wrong", "fris_spymaster")
            convo("slug.wrong", { "Yes I have.", "They are ready now.", "Sixteen militia have been trained.", "There are three bridges to repair." })
            stage(60)
            t.check("slug.wrong.nopay", count("coins") == b, "coins " .. b .. " -> " .. count("coins"))
            say("tellSlugReport1", "fris_spymaster")
            convo("slug.report1", { "Yes I have.", "They will be ready in two days.", "Seventeen militia have been trained.", "There are two bridges to repair." })
            t.check("slug.paid", count("coins") == b + 2500, "coins " .. b .. " -> " .. count("coins"))
            stage(90)
        end

        -- ------------------------------------------------ leg 6: Mawnis's request; yak hair and hide; spin the rope
        if START <= 6 and LAST >= 6 then
            if START == 6 then setstage(90) end
            strip_jester()
            at("mawnis2", 2341, 3799)
            say("talkToMawnis", "fris_r_burgher")
            convo("mawnis.quest_intro", {})
            stage(100)
            -- gather: kill yaks for hair and hide
            t.exec("equip-scimitar3", t.player.equip, "rune_scimitar"); t.ticks(1)
            at("yaks", 2322, 3793)
            for i = 1, 9 do
                t.exec("yak" .. i .. ".attack", t.player.attack, "yak", 2, 60)
                t.exec("yak" .. i .. ".dead", t.npc.await_dead_engaged, 120, 3, { eat = { item = "lobster", below = 40 } })
                t.ticks(2)
                local hb = count("yak_hair")
                t.exec("yak" .. i .. ".take_hair", t.player.click_obj, "yak_hair", 3)
                t.ticks(1)
                t.exec("yak" .. i .. ".take_hide", t.player.click_obj, "yak_hide", 3)
                t.ticks(1)
            end
            has("yak_hair", 9); has("yak_hide", 8)
            -- spin the hair into rope on the Neitiznot wheel
            at("wheel", 2352, 3796)
            spin_all_hair()
            has("rope", 9)
        end

        -- ------------------------------------------------ leg 7: arctic pines, the stump, the rope and the logs shown to Mawnis
        if START <= 7 and LAST >= 7 then
            if START == 7 then
                setstage(100)
                give("rope", 9)
            end
            -- show the rope
            at("mawnis3", 2341, 3799)
            local b = count("coins")
            say("talkToMawnisWithRope", "fris_r_burgher")
            convo("mawnis.rope", {})
            t.check("rope.kept", count("rope") >= 9, "rope " .. count("rope"))
            t.check("rope.paid", count("coins") == b + 1000, "coins " .. b .. " -> " .. count("coins"))
            stage(110)
            -- fell eight arctic pines (Woodcutting 54) and split them on the stump (Woodcutting 56 and an axe)
            chop_to(8)
            at("stump", 2343, 3808)
            local target = t.player.by_symbol("loc", "iznot_shield_stump")
            t.exec("stump.use_log", t.player.use_on, "arctic_pine_log", target)
            convo("stump.menu", { "Split logs" })
            t.inv.await("arctic_pine_split", 8, 200)
            has("arctic_pine_split", 8)
            -- show the split logs
            at("mawnis3b", 2341, 3799)
            local b2 = count("coins")
            say("talkToMawnisWithLogs", "fris_r_burgher")
            convo("mawnis.logs", {})
            t.check("logs.kept", count("arctic_pine_split") >= 8, "split logs " .. count("arctic_pine_split"))
            t.check("logs.paid", count("coins") == b2 + 1500, "coins " .. b2 .. " -> " .. count("coins"))
            stage(140)
        end

        -- ------------------------------------------------ leg 8: the two bridges (requirement messages, then the repairs)
        if START <= 8 and LAST >= 8 then
            if START == 8 then
                setstage(140)
                give("rope", 8); give("arctic_pine_split", 8)
            end
            -- every guide step is "right-click Repair"; first the wiki's refusals
            t.cheat("::setlevel construction 10", true); t.ticks(2)
            at("bridge3", 2314, 3838)
            t.exec("repairBridge1.lowlevel", t.player.click_loc, "frisb_bridge_3_s", 2)
            t.ticks(2)
            t.check("repair.lowlevel.msg", select(1, t.msg.expect("Construction level of 20")) == "ok", "refusal line")
            t.cheat("::setlevel construction 45", true); t.ticks(2)
            -- cross before the repair: refused
            t.exec("bridge3.walk_broken", t.player.click_loc, "frisb_bridge_3_s", 1)
            t.ticks(2)
            t.check("bridge3.broken.msg", select(1, t.msg.expect("The bridge is broken")) == "ok", "broken line")
            t.exec("repairBridge1", t.player.click_loc, "frisb_bridge_3_s", 2)
            t.var.await("varb3313_fris_m_b3", 1, 40)
            t.ticks(10)
            var("varb3313_fris_m_b3", 1)
            local _, tl = t.world.tile()
            t.check("repairBridge1.crossed", tl.z >= 3848, "tile after the repair " .. tl.x .. "," .. tl.z)
            has("rope", 4); has("arctic_pine_split", 4)
            -- the repaired bridge is crossed both ways
            t.exec("bridge3.back", t.player.click_loc, "frisb_bridge_3_n", 1)
            t.ticks(8)
            local _, tl2 = t.world.tile()
            t.check("bridge3.crossed_back", tl2.z <= 3839, "tile after crossing back " .. tl2.x .. "," .. tl2.z)
            t.exec("bridge3.again", t.player.click_loc, "frisb_bridge_3_s", 2)
            t.ticks(2)
            t.check("repair.already.msg", select(1, t.msg.expect("I have already repaired this bridge")) == "ok", "already line")

            at("bridge4", 2355, 3838)
            stage(140)
            t.exec("repairBridge2", t.player.click_loc, "frisb_bridge_4_s", 2)
            t.var.await("varb3314_fris_m_b4", 1, 40)
            t.ticks(10)
            var("varb3314_fris_m_b4", 1)
            stage(150)
            t.check("repair.consumed", count("rope") == 0 and count("arctic_pine_split") == 0, "rope " .. count("rope") .. " split " .. count("arctic_pine_split"))
            -- the north-east bridge is not the player's to repair
            at("bridge5", 2378, 3838)
            t.exec("bridge5.walk", t.player.click_loc, "frisb_bridge_5_s", 1)
            t.ticks(2)
            t.check("bridge5.broken.msg", select(1, t.msg.expect("The bridge is broken")) == "ok", "runite bridge refuses")
        end

        -- ------------------------------------------------ leg 9: report the bridges to Mawnis (the raid plan)
        if START <= 9 and LAST >= 9 then
            if START == 9 then
                setstage(150); setv("varb3313_fris_m_b3", 1); setv("varb3314_fris_m_b4", 1)
            end
            at("mawnis4", 2341, 3799)
            local b = count("coins")
            say("talkToMawnisAfterRepair", "fris_r_burgher")
            convo("mawnis.report_bridges", {})
            t.check("bridges.paid", count("coins") == b + 1500, "coins " .. b .. " -> " .. count("coins"))
            stage(160)
        end

        -- ------------------------------------------------ leg 10: Jatizso again: the king makes the player tax collector
        if START <= 10 and LAST >= 10 then
            if START == 10 then setstage(160) end
            at("iznot-dock", 2311, 3782)
            say("leaveNeitiznotToReport", "fris_r_ferry_iznot")
            convo("maria.back", { "Can you ferry me to Rellekka?" })
            t.ticks(3)
            at("maria2", 2644, 3711)
            at("mord2", 2644, 3708)
            say("travelToJatizsoToReport", "fris_r_ferryman_rellekka")
            convo("mord.again", { "Can you ferry me to Jatizso?" })
            t.ticks(3)
            tile_near("jatizso2", 2421, 3783, 6)
            at("king2", 2407, 3803)
            say("talkToGjukiToReport", "fris_r_king")
            convo("gjuki.tax_speech", {})
            stage(200)
            has("frisd_taxbag_empty", 1)
        end

        -- ------------------------------------------------ leg 11: window tax (the player counts the windows and types the amount)
        if START <= 11 and LAST >= 11 then
            if START == 11 then
                setstage(200); give("frisd_taxbag_empty", 1)
            end
            -- Keepa Kettilon: too low, too high, right
            at("keepa", 2417, 3815)
            say("collectFromKeepa.low", "frisd_cook")
            convo("keepa.low", {}, { 4000 })
            var("varb3325_frisd_cook_taxcollected", 0)
            say("collectFromKeepa.high", "frisd_cook")
            convo("keepa.high", {}, { 6000 })
            var("varb3325_frisd_cook_taxcollected", 0)
            say("collectFromKeepa", "frisd_cook")
            convo("keepa.pay", { "But rules are rules. Pay up!" }, { 5000 })
            var("varb3325_frisd_cook_taxcollected", 1)
            has("frisd_taxbag_light", 1)
            -- Flosi is in the same building: no tax from him this round
            at("flosi2", 2418, 3812)
            say("flosi.not_again", "frisd_fishmerchant")
            convo("flosi.not_again", {})
            var("varb3322_frisd_fishmonger_taxcollected", 0)
            -- Vanligga: the player pays her tax (a favour that opens her shop later)
            at("vanligga", 2405, 3812)
            local b = count("coins")
            say("collectFromVanligga", "frisd_izso_landlady")
            convo("vanligga.pay", { "I suppose I could pay the tax for you." }, { 5000 })
            var("varb3324_frisd_pub_taxcollected", 1)
            var("varb3326_frisd_pub_favours", 1)
            t.check("vanligga.paid_by_player", count("coins") == b - 5000, "coins " .. b .. " -> " .. count("coins"))
            has("frisd_taxbag_normal", 1)
            -- Skuli Myrka 6000
            at("skuli", 2395, 3803)
            say("collectFromSkuli", "frisd_weaponmerchant")
            convo("skuli.pay", { "But rules are rules. Pay up!" }, { 6000 })
            var("varb3320_frisd_weaponmerchant_taxcollected", 1)
            has("frisd_taxbag_hefty", 1)
            -- Hring Hring 8000 (Raum, in the same building, owes nothing now)
            at("hring2", 2397, 3797)
            say("collectFromHring", "frisd_oremerchant")
            convo("hring.pay", { "But rules are rules. Pay up!" }, { 8000 })
            var("varb3321_frisd_oremerchant_taxcollected", 1)
            has("frisd_taxbag_bulging", 1)
            at("raum", 2395, 3797)
            say("raum.not_again", "frisd_armourmerchant")
            convo("raum.not_again", {})
            var("varb3323_frisd_armourmerchant_taxcollected", 0)
            -- report to the king: the beard tax
            at("king3", 2407, 3803)
            say("talkToGjukiAfterCollection1", "fris_r_king")
            convo("gjuki.window_done", {})
            stage(210)
            var("varb3321_frisd_oremerchant_taxcollected", 0)
        end

        -- ------------------------------------------------ leg 12: beard tax (1000 each; the bag ends at 29000)
        if START <= 12 and LAST >= 12 then
            if START == 12 then
                setstage(210); give("frisd_taxbag_bulging", 1)
                for _, v in ipairs({ "varb3320_frisd_weaponmerchant_taxcollected", "varb3321_frisd_oremerchant_taxcollected", "varb3322_frisd_fishmonger_taxcollected", "varb3323_frisd_armourmerchant_taxcollected", "varb3324_frisd_pub_taxcollected", "varb3325_frisd_cook_taxcollected" }) do setv(v, 0) end
            end
            at("raum2", 2395, 3797)
            say("collectFromRaum", "frisd_armourmerchant")
            convo("raum.beard", { "But rules are rules. Pay up!" })
            var("varb3323_frisd_armourmerchant_taxcollected", 1)
            at("hring3", 2397, 3797)
            say("collectFromHringAgain", "frisd_oremerchant")
            convo("hring.beard", { "But rules are rules. Pay up!" })
            var("varb3321_frisd_oremerchant_taxcollected", 1)
            at("skuli2", 2395, 3803)
            say("collectFromSkuliAgain", "frisd_weaponmerchant")
            convo("skuli.beard", { "But rules are rules. Pay up!" })
            var("varb3320_frisd_weaponmerchant_taxcollected", 1)
            at("keepa2", 2417, 3815)
            say("collectFromKeepaAgain", "frisd_cook")
            convo("keepa.beard", { "But rules are rules. Pay up!" })
            var("varb3325_frisd_cook_taxcollected", 1)
            -- Vanligga owes no beard tax
            at("vanligga2", 2405, 3812)
            say("vanligga.beard", "frisd_izso_landlady")
            convo("vanligga.beard", {})
            at("flosi3", 2418, 3812)
            say("collectFromFlosi", "frisd_fishmerchant")
            convo("flosi.beard", { "But rules are rules. Pay up!" })
            var("varb3322_frisd_fishmonger_taxcollected", 1)
            has("frisd_taxbag_bulging", 1)
            at("king4", 2407, 3803)
            say("talkToGjukiAfterCollection2", "fris_r_king")
            convo("gjuki.beard_done", {})
            stage(230)
            t.check("bag.handed_over", count("frisd_taxbag_bulging") == 0, "bag left " .. count("frisd_taxbag_bulging"))
        end

        -- ------------------------------------------------ leg 13: the second performance, Slug's debrief, the decree
        if START <= 13 and LAST >= 13 then
            if START == 13 then
                setstage(230)
                give("frisd_jester_hat"); give("frisd_jester_top"); give("frisd_jester_legs"); give("frisd_jester_boots")
            end
            at("izso-dock2", 2420, 3783)
            say("returnToRellekkaToSpyAgain", "fris_r_ferryman_izso")
            convo("mord.back2", { "Can you ferry me to Rellekka?" })
            t.ticks(3)
            at("maria3", 2644, 3711)
            say("travelToNeitiznotToSpyAgain", "fris_r_ferry_rellikka")
            convo("maria.ferry2", { "Can you ferry me to Neitiznot?" })
            t.ticks(3)
            wear_jester()
            at("slug3", 2336, 3809)
            say("talkToSlugToSpyAgain", "fris_spymaster")
            convo("slug.second", {})
            stage(235)
            at("mawnis5", 2341, 3799)
            say("goSpyOnMawnisAgain", "fris_r_burgher")
            convo("mawnis.act3", {})
            perform("performForMawnisAgain")
            t.ticks(6)
            convo("mawnis.act3.end", {})
            stage(240)
            at("slug4", 2336, 3809)
            local b = count("coins")
            say("reportBackToSlugAgain", "fris_spymaster")
            convo("slug.report2", { "Yes, I am.", "They are in a secluded bay, near Etceteria.", "They will be given some potions.", "I have been helping Neitiznot." })
            t.check("slug.paid2", count("coins") == b + 2500, "coins " .. b .. " -> " .. count("coins"))
            stage(260)
            strip_jester()
            -- back to the king: the rant and the royal decree
            at("izso-ferry3", 2311, 3782)
            say("returnToRellekkaFromNeitiznotAfterSpy2", "fris_r_ferry_iznot")
            convo("maria.back3", { "Can you ferry me to Rellekka?" })
            t.ticks(3)
            at("mord3", 2644, 3708)
            say("travelToJatizsoAfterSpy2", "fris_r_ferryman_rellekka")
            convo("mord.again3", { "Can you ferry me to Jatizso?" })
            t.ticks(3)
            at("king5", 2407, 3803)
            say("talkToGjukiAfterSpy2", "fris_r_king")
            convo("gjuki.decree", {})
            stage(270)
            has("frisd_reciept", 1)
        end

        -- ------------------------------------------------ leg 14: the decree, the yak-hide armour, the shield, the oaths
        if START <= 14 and LAST >= 14 then
            if START == 14 then
                setstage(270); give("frisd_reciept", 1)
            end
            at("izso-dock3", 2420, 3783)
            say("returnToRellekkaWithDecree", "fris_r_ferryman_izso")
            convo("mord.back4", { "Can you ferry me to Rellekka?" })
            t.ticks(3)
            at("maria4", 2644, 3711)
            say("travelToNeitiznotWithDecree", "fris_r_ferry_rellikka")
            convo("maria.ferry4", { "Can you ferry me to Neitiznot?" })
            t.ticks(3)
            at("mawnis6", 2341, 3799)
            say("talkToMawnisWithDecree", "fris_r_burgher")
            convo("mawnis.decree", {})
            stage(280)
            t.check("decree.taken", count("frisd_reciept") == 0, "decree left " .. count("frisd_reciept"))
            -- Thakkrad cures three hides (5 gp each), then needle and thread make the armour
            if count("yak_hide") < 3 then give("yak_hide", 3) end
            local c0 = count("coins")
            say("curehides", "fris_r_engineer")
            convo("thakkrad.cure", { "Cure my yak-hide, please.", "Cure all my hides." })
            local cured = count("yak_hide_cured")
            t.check("hides.cured", cured >= 3 and count("yak_hide") == 0, "cured " .. cured .. ", raw " .. count("yak_hide"))
            t.check("hides.fee", count("coins") <= c0 - 5 * cured, "coins " .. c0 .. " -> " .. count("coins"))
            t.exec("craft.body", t.player.use_item_on_item, "needle", "yak_hide_cured")
            convo("craft.body", { "Yak-hide body (2 hides)" })
            t.inv.await("yak_hide_armour_body", 1, 20)
            t.exec("craft.legs", t.player.use_item_on_item, "needle", "yak_hide_cured")
            convo("craft.legs", { "Yak-hide legs (1 hide)" })
            t.inv.await("yak_hide_armour_greaves", 1, 20)
            has("yak_hide_armour_body", 1); has("yak_hide_armour_greaves", 1)
            -- Mawnis: the armour is done, now the shield
            say("getYakArmour", "fris_r_burgher")
            convo("mawnis.armour", {})
            stage(290)
            -- the shield: two arctic pine logs, a bronze nail, a hammer and a rope, made on the stump
            if count("rope") < 1 then give("rope", 1) end
            chop_to(2)
            at("stump2", 2343, 3808)
            local stump = t.player.by_symbol("loc", "iznot_shield_stump")
            t.exec("makeShield", t.player.use_on, "arctic_pine_log", stump)
            convo("stump.shield", { "Neitiznot shield" })
            t.inv.await("fremmenik_round_shield", 1, 40)
            has("fremmenik_round_shield", 1)
            at("mawnis7", 2341, 3799)
            say("swearOaths", "fris_r_burgher")
            convo("mawnis.oaths", {})
            stage(300)
        end

        -- ------------------------------------------------ leg 15: the cave, ten trolls, Bork's supplies
        if START <= 15 and LAST >= 15 then
            if START == 15 then
                setstage(300)
                give("yak_hide_armour_body"); give("yak_hide_armour_greaves"); give("fremmenik_round_shield")
                give("lobster", 10)
            end
            t.exec("wear-body", t.player.equip, "yak_hide_armour_body"); t.ticks(1)
            t.exec("wear-legs", t.player.equip, "yak_hide_armour_greaves"); t.ticks(1)
            t.exec("wear-shield", t.player.equip, "fremmenik_round_shield"); t.ticks(1)
            t.exec("wear-weapon", t.player.equip, "rune_scimitar"); t.ticks(1)
            -- the western cave is refused with the guard's body
            at("western-cave", 2316, 3892)
            t.exec("westcave", t.player.click_loc, "fris_troll_trapdoor_final", 1)
            t.ticks(2)
            t.check("westcave.msg", select(1, t.msg.expect("body of one of Jatizso's guards")) == "ok", "western cave refuses")
            -- the eastern cave: first entry
            at("trapdoor", 2400, 3889)
            t.exec("enterCave", t.player.click_loc, "fris_troll_trapdoor_r2", 1)
            convo("cave.entry", {})
            t.ticks(2)
            stage(310)
            var("varb3312_fris_task", 10)
            local _, tc = t.world.tile()
            t.check("cave.arrived", tc.z > 10000, "tile " .. tc.x .. "," .. tc.z)
            -- Bork: food once, strength once, prayer once; a second request is refused
            at("bork", 2395, 10289, 1)
            t.ticks(3)
            t.exec("bork.talk", t.player.talk_to, "frisb_n_phy", 1)
            convo("bork.food", { "Give me food, Bork!" })
            has("tuna", 8)
            t.exec("bork.talk2", t.player.talk_to, "frisb_n_phy", 1)
            convo("bork.strength", { "I need Strength potions!" })
            has("strength4", 2)
            t.exec("bork.talk3", t.player.talk_to, "frisb_n_phy", 1)
            convo("bork.prayer", { "I need Prayer potions!" })
            has("3doseprayerrestore", 2)
            local f0 = count("tuna")
            t.exec("bork.talk4", t.player.talk_to, "frisb_n_phy", 1)
            convo("bork.food_again", { "Give me food, Bork!" })
            t.check("bork.once", count("tuna") == f0, "tuna " .. f0 .. " -> " .. count("tuna"))
            -- the bridge stays shut until ten trolls are dead
            at("bridge6", 2385, 10265, 1)
            t.exec("bridge6.shut", t.player.click_loc, "frisb_bridge_6_n", 1)
            t.ticks(2)
            t.check("bridge6.msg", select(1, t.msg.expect("more trolls to kill")) == "ok", "bridge refuses before ten kills")
            -- ten frenzied ice trolls (any kind): fought for real, one at a time next to each
            local kinds = { "fris_baby_troll_pc", "fris_trollf_pc", "fris_trollm_pc" }
            local spots = { { 2405, 10258 }, { 2413, 10256 } }
            for i = 1, 26 do
                local _, left0 = t.var.server("varb3312_fris_task")
                if left0 == 0 then break end
                local sp = spots[((i - 1) % #spots) + 1]
                heal(88)
                at("troll" .. i, sp[1], sp[2], 1)
                t.ticks(3)
                local fought = false
                for _, kind in ipairs(kinds) do
                    local nr, row = t.npc.nearest(kind, 8)
                    if nr == "ok" then
                        local r, d = t.player.attack(kind, 2, 120)
                        if r == "ok" then
                            local dr, dd = t.npc.await_dead_engaged(200, 3, { eat = { item = "tuna", below = 50 } })
                            local _, left = t.var.server("varb3312_fris_task")
                            t.check("troll" .. i .. "." .. kind, dr == "ok" and left < left0, "attack ok, dead " .. tostring(dr) .. ", kills left " .. tostring(left0) .. " -> " .. tostring(left))
                            fought = true
                            break
                        end
                    end
                end
                if not fought then t.note("no troll within reach at spot " .. i); t.ticks(30) end
            end
            var("varb3312_fris_task", 0)
        end

        -- ------------------------------------------------ leg 16: the Ice Troll King, the head, the reward
        if START <= 16 and LAST >= 16 then
            if START == 16 then
                setstage(310); setv("varb3312_fris_task", 0)
                give("yak_hide_armour_body"); give("yak_hide_armour_greaves"); give("fremmenik_round_shield")
                give("lobster", 20)
                t.exec("wear-body", t.player.equip, "yak_hide_armour_body"); t.ticks(1)
                t.exec("wear-legs", t.player.equip, "yak_hide_armour_greaves"); t.ticks(1)
                t.exec("wear-shield", t.player.equip, "fremmenik_round_shield"); t.ticks(1)
                t.exec("wear-weapon", t.player.equip, "rune_scimitar"); t.ticks(1)
                t.cheat("::fremennikisleskingdoor", true); t.ticks(3)
            end
            at("bridge6b", 2385, 10265, 1)
            t.exec("enterKingRoom", t.player.click_loc, "frisb_bridge_6_n", 1)
            t.ticks(8)
            local _, tk = t.world.tile()
            t.check("king.chamber", tk.z < 10262, "tile " .. tk.x .. "," .. tk.z)
            t.exec("killKing.attack", t.player.attack, "fris_troll_king_true", 2, 120)
            t.exec("killKing.dead", t.npc.await_dead_engaged, 600, 6, { eat = { item = "lobster", below = 55 } })
            stage(320)
            t.exec("decapitateKing", t.player.click_loc, "fris_troll_king_dead_head", 1)
            t.inv.await("frisr_trollkinghead", 1, 20)
            has("frisr_trollkinghead", 1)
            stage(325)
        end

        -- ------------------------------------------------ leg 17: the head to Mawnis, the helm, the two choices
        if START <= 17 and LAST >= 17 then
            if START == 17 then
                setstage(325); give("frisr_trollkinghead", 1)
            end
            at("mawnis8", 2341, 3799)
            local _, xp0 = t.skill.snapshot()
            say("finishQuest", "fris_r_burgher")
            convo("mawnis.finish", { "Attack", "Strength" })
            has("fris_kingly_helm", 1)
            t.check("head.taken", count("frisr_trollkinghead") == 0, "head left " .. count("frisr_trollkinghead"))
            t.quest.expect_complete()
            t.expect("reward.construction", t.skill.expect_gain("construction", 5000, xp0))
            t.expect("reward.crafting", t.skill.expect_gain("crafting", 5000, xp0))
            t.expect("reward.woodcutting", t.skill.expect_gain("woodcutting", 10000, xp0))
            t.expect("reward.attack", t.skill.expect_gain("attack", 10000, xp0))
            t.expect("reward.strength", t.skill.expect_gain("strength", 10000, xp0))
        end
        t.finish(0)
    end,
}

end)()

if type(QUEST) == "table" and QUEST.legs ~= nil then
    local legs_quest = QUEST
    QUEST = { setup = legs_quest.setup, run = function(t)
        return t.core_legs_drive(legs_quest, { from = LEG_FROM, only = LEG_ONLY, tile = LEG_TILE })
    end }
end
if type(QUEST) ~= "table" or type(QUEST.run) ~= "function" then
    error("quest file did not return { run = function(t) ... end }"
        .. " or { legs = { { name =, run = function(t) ... end }, ... } }")
end
local quest_setup = QUEST.setup
-- A setup that is not a list of cheat lines is a setup nobody reads:
-- refuse it rather than run the quest against an unstated world.
if quest_setup ~= nil and type(quest_setup) ~= "table" then
    error("quest file's setup is a " .. type(quest_setup)
        .. ", not a table of cheat lines")
end
-- A checkpoint run resumes a player who already went through setup
-- (and legs 1..K-1): the setup list is NOT run again.
if LEG_FROM and LEG_FROM > 1 then
    quest_setup = nil
end
-- --script mode: no setup list, nothing to wrap.
if quest_setup == nil or next(quest_setup) == nil then
    return QUEST
end
local quest_run = QUEST.run
QUEST.run = function(t)
    -- WAIT FOR THE LOGIN GRANT before the first setup cheat.
    --
    -- The backpack a fixture starts with is not in the fixture: the
    -- containers are adopted EMPTY (torirs_server_world.c, "what goes
    -- in them the first time a character connects is content's") and
    -- content's [login,_] -> [proc,newplayer_inv] fills them on a
    -- later tick than the one this script starts on.  Measured
    -- 2026-09-19 (build/quest_gate/closer_setup2 row 1,
    -- closer_setup3): `::clearinv` issued on the first frame answers
    -- "Cleared 0 item(s).", the fourteen tutorial slots land behind
    -- it, and a `::give` before the grant is overwritten by it -- a
    -- setup list that answered `ok` three times and left the world it
    -- promised in none of them.  A fixed `t.ticks(n)` does not fix it
    -- (the grant landed on tick 1 in one run and after three cheats in
    -- the next); the arrival itself is the signal, so wait for it.
    --
    -- Bounded, and proceeding either way: a fixture whose character
    -- really does hold nothing pays the budget and runs its setup
    -- anyway, rather than failing a quest over an empty backpack.
    t.await({ level = function()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return true
            end
        end
        return false
    end, note = "setup: the login grant" }, 10)
    t.settle()
    -- A CHEAT'S REPLY OUTRUNS ITS EFFECT by exactly one server tick.
    --
    -- t.cheat waits for the reply line (core.lua: QD.cheat ->
    -- msg.await), and the server SAYS `Gave 3 x Egg (1944).` from
    -- inside the ladder branch itself, while the backpack the same
    -- branch just wrote reaches the client in the container
    -- listener's UPDATE_INV at the END of that tick
    -- (torirs_server_world.c, the ::give branch: `the backpack's
    -- listener sends an UPDATE_INV without this branch knowing a
    -- packet exists`).  So the setup loop used to hand run() a client
    -- that had heard about the items and not yet received them, and
    -- every quest whose first rows read t.inv.count saw an empty
    -- backpack from a setup that had answered `ok` three times.
    -- Measured 2026-09-21 (build/quest_gate/lag_probe): row `lag.t0`
    -- FAIL `egg: absent`, row `lag.t1` -- one t.ticks(1) later --
    -- PASS `3`.  Two seam fixers reported it as `::give from setup
    -- lands nothing` (docs/QUEST_AUTHORING.md trap 23).
    --
    -- A ::give is therefore not done when it answers: it is done when
    -- the CLIENT can count the items, which is also the only check
    -- that catches the ladder's own silent misses -- `::give
    -- nosuchitemname` and an ambiguous name both `say()` their
    -- complaint and return RAN, i.e. `ok`, having given nothing
    -- (same file, `No item named '%s'.` / `Which %s? %s`).  Each one
    -- is now a FAIL row named after the cheat, exactly like a cheat
    -- that answered no_row.
    local function setup_give(text)
        local name, count = string.match(text, "^%s*:*give%s+([%w_]+)%s*(%d*)")
        if not name then
            return nil
        end
        local wanted = tonumber(count)
        if not wanted or wanted < 1 then
            wanted = 1
        end
        return name, wanted
    end
    -- Name-free fingerprint of the backpack: every slot's count, plus
    -- one per occupied slot so an item ARRIVING in an empty slot
    -- moves it too.  What the fallback below watches when a ::give
    -- names something this client cannot count.
    local function setup_backpack_mark()
        local mark = 0
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                mark = mark + cell.count + 1
            end
        end
        return mark
    end
    local function setup_backpack_empty()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return false
            end
        end
        return true
    end
    -- `::setlevel <stat> <level>` -> stat, level; nil for any other line.
    -- A line that STARTS as a setlevel (the engine's own strncmp prefix)
    -- but does not parse is ("", nil): the engine answers ok to it
    -- and sets nothing.
    local function setup_setlevel(text)
        if not string.match(text, "^%s*:*setlevel") then
            return nil
        end
        local stat, level = string.match(text, "^%s*:*setlevel%s+(%a[%w_]*)%s+(%d+)%s*$")
        if not stat then
            return "", nil
        end
        return stat, tonumber(level)
    end
    -- `::wield <item>` -> item; nil for any other line.  The cheat
    -- answers once the synthesized Wield click is SENT (seam pass 29:
    -- it used to take only an obj id, print its Usage line for a name
    -- and answer ok -- arthur fought Mordred unarmed behind a green
    -- setup), and content may still refuse the wield (a level, a
    -- quest), so the line is done only when the WORN container holds
    -- the item (QD.ui._worn_count, ui.lua).
    local function setup_wield(text)
        return string.match(text, "^%s*:*wield%s+([%w_]+)%s*$")
    end
    local function setup_last_lines(n)
        local lines_result, rows = t.msg.last(n)
        if lines_result ~= "ok" or type(rows) ~= "table" then
            return "(no chat lines)"
        end
        local texts = {}
        for i = 1, #rows do
            texts[#texts + 1] = "'" .. tostring(rows[i].text) .. "'"
        end
        return table.concat(texts, " / ")
    end
    local function setup_failed(cheat, why)
        t.step("setup." .. cheat, "FAIL",
            why .. " -- the world this quest assumes was never stated")
        t.finish(1)
    end
    if type(quest_setup) == "table" then
        for _, cheat in ipairs(quest_setup) do
            -- Counted BEFORE the cheat: a setup list that gives the
            -- same item twice, or gives one the login grant already
            -- put there, is waiting for an INCREASE, not for a total.
            local give_name, give_count = setup_give(cheat)
            local before = nil
            local before_mark = nil
            if give_name then
                local count_result, count_total = t.inv.count(give_name)
                if count_result == "ok" then
                    before = count_total
                else
                    -- A name this client cannot resolve to an obj: the
                    -- server's own cheat_obj_from_name is fuzzy and may
                    -- still have matched one -- but `::give
                    -- nosuchitemname` reaches the SAME `ok` (it say()s
                    -- `No item named` and returns RAN), so the whole
                    -- backpack is watched for any movement instead of
                    -- taking the cheat at its word.
                    before_mark = setup_backpack_mark()
                end
            end
            local wield_name = setup_wield(cheat)
            local worn_before = nil
            if wield_name then
                local worn_result, worn_count = t.ui._worn_count(wield_name)
                if worn_result ~= "ok" then
                    setup_failed(cheat, "cannot read the worn container for "
                        .. wield_name .. " (" .. tostring(worn_result) .. " "
                        .. tostring(worn_count) .. "), so a wield could never be"
                        .. " proved")
                    return
                end
                worn_before = worn_count
            elseif string.match(cheat, "^%s*:*wield") then
                setup_failed(cheat, "not `::wield <item_name>`: a line the"
                    .. " read-back cannot name is a wield nobody can prove")
                return
            end
            local level_stat, level_wanted = setup_setlevel(cheat)
            if level_stat == "" then
                setup_failed(cheat, "not `::setlevel <stat name> <level>`: the"
                    .. " engine answers ok to it and sets nothing, and a numeric"
                    .. " stat id cannot be read back to prove it landed")
                return
            end
            local setup_result, setup_detail = t.cheat(cheat)
            if setup_result ~= "ok" then
                setup_failed(cheat, "setup cheat answered "
                    .. tostring(setup_result)
                    .. " (" .. tostring(setup_detail) .. "); last lines: "
                    .. setup_last_lines(2))
                return
            end
            if before ~= nil then
                local landed = t.inv.await(give_name, before + give_count, 10)
                if landed ~= "ok" then
                    local after_result, after_total = t.inv.count(give_name)
                    -- Short of the count asked for is the BACKPACK's
                    -- limit speaking (`Gave 21 x Egg (1944), 7 did not
                    -- fit.`), not a setup that did not happen; nothing
                    -- arriving at all is.
                    if after_result ~= "ok" or after_total <= before then
                        setup_failed(cheat, "the cheat answered ok and no "
                            .. give_name
                            .. " reached the backpack within 10 ticks (held "
                            .. tostring(before) .. " before, "
                            .. tostring(after_total) .. " after)")
                        return
                    end
                end
            elseif before_mark ~= nil then
                local moved = t.await({ level = function()
                    return setup_backpack_mark() ~= before_mark
                end, note = "setup: ::give reaching the backpack" }, 10)
                if moved ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the backpack"
                        .. " did not change within 10 ticks (" .. give_name
                        .. " is not an obj this client can count, so every"
                        .. " slot was watched instead)")
                    return
                end
            elseif worn_before ~= nil then
                local worn_last = worn_before
                local worn_landed = t.await({ level = function()
                    local read_result, reading = t.ui._worn_count(wield_name)
                    if read_result == "ok" then
                        worn_last = reading
                    end
                    return read_result == "ok" and reading > worn_before
                end, note = "setup: ::wield reaching the worn container" }, 10)
                if worn_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. wield_name
                        .. " is not worn 10 ticks later (worn " .. tostring(worn_before)
                        .. " before, " .. tostring(worn_last) .. " after); last lines: "
                        .. setup_last_lines(3))
                    return
                end
            elseif level_stat ~= nil then
                -- ok is not a level: wait for the client's reading.
                local level_last = "unread"
                local level_landed = t.await({ level = function()
                    local read_result, reading = t.skill.read(level_stat)
                    if read_result ~= "ok" then
                        level_last = tostring(read_result) .. " " .. tostring(reading)
                        return false
                    end
                    level_last = "stated=" .. tostring(reading.stated)
                        .. " base_level=" .. tostring(reading.base_level)
                    return reading.stated and reading.base_level == level_wanted
                end, note = "setup: ::setlevel reaching the client" }, 10)
                if level_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. level_stat
                        .. " never read base_level " .. tostring(level_wanted)
                        .. " within 10 ticks (last reading: " .. level_last .. ")")
                    return
                end
            elseif string.match(cheat, "^%s*:*clearinv") then
                -- The same race, and the one cheat every generated
                -- setup list opens with: an unfinished ::clearinv also
                -- makes the NEXT give's before-count wrong.
                local cleared = t.await({ level = setup_backpack_empty,
                    note = "setup: ::clearinv reaching the client" }, 10)
                if cleared ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the"
                        .. " backpack still holds items 10 ticks later")
                    return
                end
            end
        end
        -- Every OTHER cheat (::setvar, a quest's own reset
        -- debugproc) has the same one-tick reply/effect gap with no
        -- single reading to wait on, so the loop ends on the tick
        -- boundary its last reply outran.  run()'s first row reads a
        -- client that has seen the setup, which is what `setup` means.
        t.ticks(1)
        t.settle()
    end
    return quest_run(t)
end
return QUEST
