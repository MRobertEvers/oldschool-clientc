local LEG_FROM = nil
local LEG_ONLY = false
local LEG_TILE = nil
local QUEST = (function()
-- The Fremennik Isles parity driver (scratch; vm-b1). Every guide step in TheFremennikIsles.java is a
-- click, a talk, a use, a shop buy or a fight. START picks the first leg, LAST the final one: a run of
-- one leg stages the earlier ones with ::setvar/::give (the full run is START=1, LAST=99).
local START = 3
local LAST = 4

return {
    id = "thefremennikisles_parity",
    fixture = "fresh_lumbridge.ini",
    setup = {
        "::clearinv",
        "::setlevel mining 2",
        "::setlevel agility 45",
        "::setlevel construction 45",
        "::setlevel woodcutting 70",
        "::setlevel crafting 70",
        "::setlevel hitpoints 99",
        "::setlevel attack 90",
        "::setlevel strength 90",
        "::setlevel defence 80",
        "::setlevel prayer 60",
        "::fremennikisles",
        "::give coins 120000",
        "::give knife 1",
        "::give needle 1",
        "::give thread 6",
        "::give hammer 1",
        "::give nails_bronze 2",
        "::give rune_axe 1",
        "::give rune_scimitar 1",
    },

    run = function(t)
        t.quest.bind({
            varp = "varb3311_fris_quest",
            constants = { not_started = 0, complete = 340 },
            display = "The Fremennik Isles",
            points = 1,
        })
        t.ticks(3)

        local function say(name, npc, op)
            return t.exec(name, t.player.talk_to, npc, op or 1)
        end
        -- walk a conversation through every page; pick `choices` rows in order when options appear;
        -- `counts` answers count prompts in order
        local function convo(name, choices, counts)
            local i, c = 0, 0
            for guard = 1, 80 do
                local r, k = t.chat.drain({ stop_at = "options" })
                if k == "options" then
                    i = i + 1
                    local ch = choices and choices[i]
                    if ch == nil then
                        t.check(name .. ".unexpected_options", false, "no choice scripted for options page " .. i .. ": " .. tostring(select(2, t.chat.options())))
                        return
                    end
                    t.exec(name .. ".choose" .. i, t.chat.choose, ch)
                elseif k == "count" then
                    c = c + 1
                    local n = counts and counts[c]
                    if n == nil then
                        t.check(name .. ".unexpected_count", false, "no count scripted for prompt " .. c)
                        return
                    end
                    t.exec(name .. ".count" .. c, t.chat.count, n)
                else
                    t.check(name .. ".done", r, "drain " .. tostring(r) .. " kind=" .. tostring(k))
                    return
                end
            end
        end
        local function var(name, want)
            local r, v = t.var.server(name)
            t.check("var." .. name .. "=" .. tostring(want), v == want, name .. " server=" .. tostring(v))
        end
        local function stage(want) var("varb3311_fris_quest", want) end
        local function count(item) local r, c = t.inv.count(item); return c or 0 end
        local function has(item, n)
            local c = count(item)
            t.check("inv." .. item .. ">=" .. n, c >= n, item .. " count=" .. tostring(c))
        end
        local function setv(name, val)
            t.cheat("::setvar " .. name .. " " .. tostring(val), true)
            t.ticks(2)
        end
        local function setstage(n) setv("varb3311_fris_quest", n) end
        local function give(item, n) t.cheat("::give " .. item .. " " .. tostring(n or 1), true); t.ticks(1) end
        local function at(name, x, z, l) return t.exec("goto-" .. name, t.player.goto_tile, x, z, l or 0) end
        local function tile_near(name, x, z, r)
            local _, tl = t.world.tile()
            local ok = tl ~= nil and math.abs(tl.x - x) <= r and math.abs(tl.z - z) <= r
            t.check(name, ok, "tile " .. tostring(tl and tl.x) .. "," .. tostring(tl and tl.z) .. " want near " .. x .. "," .. z)
        end


        local function wear_jester()
            for _, it in ipairs({ "frisd_jester_hat", "frisd_jester_top", "frisd_jester_legs", "frisd_jester_boots" }) do
                t.exec("wear-" .. it, t.player.equip, it)
                t.ticks(1)
            end
        end
        local function strip_jester()
            for _, it in ipairs({ "frisd_jester_hat", "frisd_jester_top", "frisd_jester_legs", "frisd_jester_boots" }) do
                t.exec("remove-" .. it, t.player.unequip, it)
                t.ticks(1)
            end
        end
        local BUTTONS = { "frisd_talkbutton", "frisd_dancebutton", "frisd_jugglebutton", "frisd_skipbutton", "frisd_piebutton", "frisd_jigbutton", "frisd_bowbutton" }
        -- play the whole act: read the instruction Mawnis shouted (the server's want var) and press that button;
        -- `wrong` = press the wrong one on instruction number `wrong` to fail the act on purpose
        local function perform(name, wrong)
            t.ticks(2)
            local _, w0 = t.ui.widget("frisd_jestertask:frisd_dancebutton")
            t.check(name .. ".panel_open", w0 ~= nil, "frisd_jestertask panel mounted: " .. tostring(w0))
            local _, mm = t.var.varbit("varb6719_minimap_state")
            t.check(name .. ".minimap_blank", mm == 2, "minimap_state=" .. tostring(mm))
            local done, n = false, 0
            for tick = 1, 260 do
                local _, step = t.var.server("varp7214_fris_jester_step")
                if step == 0 and n > 0 then done = true; break end
                local _, want = t.var.server("varp7215_fris_jester_want")
                if want ~= nil and want > 0 then
                    n = n + 1
                    local btn = BUTTONS[want]
                    if wrong and n == wrong then btn = BUTTONS[(want % 7) + 1] end
                    local _, w = t.ui.widget("frisd_jestertask:" .. btn)
                    t.exec(name .. ".press" .. n .. "." .. btn, t.ui.invoke, w, 1)
                    t.ticks(1)
                else
                    t.ticks(1)
                end
            end
            t.check(name .. ".act_over", done, "instructions pressed: " .. n)
            return n
        end

        -- ------------------------------------------------ leg 1: Mord, the king, the cat, the ore
        if START <= 1 and LAST >= 1 then
            at("mord", 2644, 3708)
            say("talkToMord", "fris_r_ferryman_rellekka")
            convo("mord.start", { "Yes.", "Can you ferry me to Jatizso?" })
            stage(5)
            t.ticks(3)
            tile_near("travelToJatizso", 2421, 3783, 6)

            at("king", 2407, 3801)
            say("talkToGjuki", "fris_r_king")
            convo("gjuki.intro", {})
            stage(10)

            -- raw tuna: buy it from Flosi Dalksson (the wiki's other source is the south pier)
            at("flosi", 2418, 3812)
            t.exec("flosi.shop", t.shop.open, "frisd_fishmerchant", 3, "frisd_fishmonger")
            t.exec("flosi.buy_tuna", t.shop.buy, "raw_tuna", 1)
            t.shop.close()
            has("raw_tuna", 1)

            at("cat", 2407, 3801)
            local cat = t.player.by_symbol("npc", "fris_r_kingscat")
            t.exec("feedHrafn", t.player.use_on, "raw_tuna", cat)
            t.ticks(2)
            convo("hrafn", {})
            stage(20)
            say("talkToGjuki-ore", "fris_r_king")
            convo("gjuki.ore_speech", {})
            stage(30)

            -- Mining level 2: seven coal, bought from Hring Hring (the wiki: coal can be bought from him)
            at("hring", 2398, 3797)
            t.exec("hring.shop", t.shop.open, "frisd_oremerchant", 3, "frisd_oreshop")
            t.exec("hring.buy_coal", t.shop.buy, "coal", 7)
            t.shop.close()
            has("coal", 7)

            at("thorkel", 2408, 3805)
            local before = count("coins")
            say("bringOreToGjuki", "fris_r_chancellor")
            convo("thorkel.ore", {})
            t.check("ore.coins", count("coins") >= before + 10000 - 0, "coins " .. before .. " -> " .. count("coins"))
            t.check("ore.consumed", count("coal") == 0, "coal left " .. count("coal"))
            stage(50)
        end

        -- ------------------------------------------------ leg 2: the jester outfit, Neitiznot, Slug
        if START <= 2 and LAST >= 2 then
            if START == 2 then setstage(50) end
            at("chest", 2407, 3801)
            t.exec("getJesterOutfit.open", t.player.click_loc, "fris_chest_closed", 1)
            t.ticks(2)
            t.exec("getJesterOutfit.search", t.player.click_loc, "fris_chest_open", 1)
            convo("chest", { "Take the jester's hat.", "Take the jester's top.", "Take the jester's tights.", "Take the jester's boots.", "Leave the chest." })
            has("frisd_jester_hat", 1); has("frisd_jester_top", 1); has("frisd_jester_legs", 1); has("frisd_jester_boots", 1)

            at("izso-dock", 2420, 3783)
            say("returnToRellekka", "fris_r_ferryman_izso")
            convo("mord.back", { "Can you ferry me to Rellekka?" })
            t.ticks(3)
            tile_near("rellekka", 2644, 3709, 4)
            at("maria", 2644, 3711)
            say("travelToNeitiznot", "fris_r_ferry_rellikka")
            convo("maria.ferry", { "Can you ferry me to Neitiznot?" })
            t.ticks(3)
            tile_near("neitiznot", 2312, 3783, 6)
        end

        -- ------------------------------------------------ leg 3: Slug, the first performance
        if START <= 3 and LAST >= 3 then
            if START == 3 then
                setstage(50)
                give("frisd_jester_hat"); give("frisd_jester_top"); give("frisd_jester_legs"); give("frisd_jester_boots")
                at("slug", 2336, 3809)
            else
                at("slug", 2336, 3809)
            end
            -- not in the outfit: the password works but "I am ready" is refused
            say("talkToSlug.undressed", "fris_spymaster")
            convo("slug.undressed", { "Free stuff please.", "I am ready." })
            stage(50)
            wear_jester()
            -- a weapon in the hand is refused too
            t.exec("equip-scimitar", t.player.equip, "rune_scimitar"); t.ticks(1)
            say("talkToSlug.armed", "fris_spymaster")
            convo("slug.armed", { "Free stuff please.", "I am ready." })
            stage(50)
            t.exec("unequip-scimitar", t.player.unequip, "rune_scimitar"); t.ticks(1)
            say("talkToSlug", "fris_spymaster")
            convo("slug.ready", { "Free stuff please.", "I am ready." })
            stage(55)
        end

        -- ------------------------------------------------ leg 4: perform for Mawnis (fail once, then succeed)
        if START <= 4 and LAST >= 4 then
            if START == 4 then
                setstage(55)
                give("frisd_jester_hat"); give("frisd_jester_top"); give("frisd_jester_legs"); give("frisd_jester_boots")
                wear_jester()
            end
            at("mawnis", 2335, 3797)
            -- hands not empty: refused before the fade
            t.exec("equip-scimitar2", t.player.equip, "rune_scimitar"); t.ticks(1)
            say("goSpyOnMawnis.armed", "fris_r_burgher")
            convo("mawnis.armed", {})
            stage(55)
            t.exec("unequip-scimitar2", t.player.unequip, "rune_scimitar"); t.ticks(1)
            -- first act: press a wrong button on the 2nd instruction
            say("goSpyOnMawnis.fail", "fris_r_burgher")
            convo("mawnis.act1", {})
            perform("act1", 2)
            t.ticks(6)
            convo("mawnis.act1.end", {})
            stage(55)
            -- second try: every instruction followed
            say("goSpyOnMawnis", "fris_r_burgher")
            convo("mawnis.act2", {})
            perform("performForMawnis")
            t.ticks(6)
            convo("mawnis.act2.end", {})
            stage(60)
        end
        t.finish(0)
    end,
}

end)()

if type(QUEST) == "table" and QUEST.legs ~= nil then
    local legs_quest = QUEST
    QUEST = { setup = legs_quest.setup, run = function(t)
        return t.core_legs_drive(legs_quest, { from = LEG_FROM, only = LEG_ONLY, tile = LEG_TILE })
    end }
end
if type(QUEST) ~= "table" or type(QUEST.run) ~= "function" then
    error("quest file did not return { run = function(t) ... end }"
        .. " or { legs = { { name =, run = function(t) ... end }, ... } }")
end
local quest_setup = QUEST.setup
-- A setup that is not a list of cheat lines is a setup nobody reads:
-- refuse it rather than run the quest against an unstated world.
if quest_setup ~= nil and type(quest_setup) ~= "table" then
    error("quest file's setup is a " .. type(quest_setup)
        .. ", not a table of cheat lines")
end
-- A checkpoint run resumes a player who already went through setup
-- (and legs 1..K-1): the setup list is NOT run again.
if LEG_FROM and LEG_FROM > 1 then
    quest_setup = nil
end
-- --script mode: no setup list, nothing to wrap.
if quest_setup == nil or next(quest_setup) == nil then
    return QUEST
end
local quest_run = QUEST.run
QUEST.run = function(t)
    -- WAIT FOR THE LOGIN GRANT before the first setup cheat.
    --
    -- The backpack a fixture starts with is not in the fixture: the
    -- containers are adopted EMPTY (torirs_server_world.c, "what goes
    -- in them the first time a character connects is content's") and
    -- content's [login,_] -> [proc,newplayer_inv] fills them on a
    -- later tick than the one this script starts on.  Measured
    -- 2026-09-19 (build/quest_gate/closer_setup2 row 1,
    -- closer_setup3): `::clearinv` issued on the first frame answers
    -- "Cleared 0 item(s).", the fourteen tutorial slots land behind
    -- it, and a `::give` before the grant is overwritten by it -- a
    -- setup list that answered `ok` three times and left the world it
    -- promised in none of them.  A fixed `t.ticks(n)` does not fix it
    -- (the grant landed on tick 1 in one run and after three cheats in
    -- the next); the arrival itself is the signal, so wait for it.
    --
    -- Bounded, and proceeding either way: a fixture whose character
    -- really does hold nothing pays the budget and runs its setup
    -- anyway, rather than failing a quest over an empty backpack.
    t.await({ level = function()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return true
            end
        end
        return false
    end, note = "setup: the login grant" }, 10)
    t.settle()
    -- A CHEAT'S REPLY OUTRUNS ITS EFFECT by exactly one server tick.
    --
    -- t.cheat waits for the reply line (core.lua: QD.cheat ->
    -- msg.await), and the server SAYS `Gave 3 x Egg (1944).` from
    -- inside the ladder branch itself, while the backpack the same
    -- branch just wrote reaches the client in the container
    -- listener's UPDATE_INV at the END of that tick
    -- (torirs_server_world.c, the ::give branch: `the backpack's
    -- listener sends an UPDATE_INV without this branch knowing a
    -- packet exists`).  So the setup loop used to hand run() a client
    -- that had heard about the items and not yet received them, and
    -- every quest whose first rows read t.inv.count saw an empty
    -- backpack from a setup that had answered `ok` three times.
    -- Measured 2026-09-21 (build/quest_gate/lag_probe): row `lag.t0`
    -- FAIL `egg: absent`, row `lag.t1` -- one t.ticks(1) later --
    -- PASS `3`.  Two seam fixers reported it as `::give from setup
    -- lands nothing` (docs/QUEST_AUTHORING.md trap 23).
    --
    -- A ::give is therefore not done when it answers: it is done when
    -- the CLIENT can count the items, which is also the only check
    -- that catches the ladder's own silent misses -- `::give
    -- nosuchitemname` and an ambiguous name both `say()` their
    -- complaint and return RAN, i.e. `ok`, having given nothing
    -- (same file, `No item named '%s'.` / `Which %s? %s`).  Each one
    -- is now a FAIL row named after the cheat, exactly like a cheat
    -- that answered no_row.
    local function setup_give(text)
        local name, count = string.match(text, "^%s*:*give%s+([%w_]+)%s*(%d*)")
        if not name then
            return nil
        end
        local wanted = tonumber(count)
        if not wanted or wanted < 1 then
            wanted = 1
        end
        return name, wanted
    end
    -- Name-free fingerprint of the backpack: every slot's count, plus
    -- one per occupied slot so an item ARRIVING in an empty slot
    -- moves it too.  What the fallback below watches when a ::give
    -- names something this client cannot count.
    local function setup_backpack_mark()
        local mark = 0
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                mark = mark + cell.count + 1
            end
        end
        return mark
    end
    local function setup_backpack_empty()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return false
            end
        end
        return true
    end
    -- `::setlevel <stat> <level>` -> stat, level; nil for any other line.
    -- A line that STARTS as a setlevel (the engine's own strncmp prefix)
    -- but does not parse is ("", nil): the engine answers ok to it
    -- and sets nothing.
    local function setup_setlevel(text)
        if not string.match(text, "^%s*:*setlevel") then
            return nil
        end
        local stat, level = string.match(text, "^%s*:*setlevel%s+(%a[%w_]*)%s+(%d+)%s*$")
        if not stat then
            return "", nil
        end
        return stat, tonumber(level)
    end
    -- `::wield <item>` -> item; nil for any other line.  The cheat
    -- answers once the synthesized Wield click is SENT (seam pass 29:
    -- it used to take only an obj id, print its Usage line for a name
    -- and answer ok -- arthur fought Mordred unarmed behind a green
    -- setup), and content may still refuse the wield (a level, a
    -- quest), so the line is done only when the WORN container holds
    -- the item (QD.ui._worn_count, ui.lua).
    local function setup_wield(text)
        return string.match(text, "^%s*:*wield%s+([%w_]+)%s*$")
    end
    local function setup_last_lines(n)
        local lines_result, rows = t.msg.last(n)
        if lines_result ~= "ok" or type(rows) ~= "table" then
            return "(no chat lines)"
        end
        local texts = {}
        for i = 1, #rows do
            texts[#texts + 1] = "'" .. tostring(rows[i].text) .. "'"
        end
        return table.concat(texts, " / ")
    end
    local function setup_failed(cheat, why)
        t.step("setup." .. cheat, "FAIL",
            why .. " -- the world this quest assumes was never stated")
        t.finish(1)
    end
    if type(quest_setup) == "table" then
        for _, cheat in ipairs(quest_setup) do
            -- Counted BEFORE the cheat: a setup list that gives the
            -- same item twice, or gives one the login grant already
            -- put there, is waiting for an INCREASE, not for a total.
            local give_name, give_count = setup_give(cheat)
            local before = nil
            local before_mark = nil
            if give_name then
                local count_result, count_total = t.inv.count(give_name)
                if count_result == "ok" then
                    before = count_total
                else
                    -- A name this client cannot resolve to an obj: the
                    -- server's own cheat_obj_from_name is fuzzy and may
                    -- still have matched one -- but `::give
                    -- nosuchitemname` reaches the SAME `ok` (it say()s
                    -- `No item named` and returns RAN), so the whole
                    -- backpack is watched for any movement instead of
                    -- taking the cheat at its word.
                    before_mark = setup_backpack_mark()
                end
            end
            local wield_name = setup_wield(cheat)
            local worn_before = nil
            if wield_name then
                local worn_result, worn_count = t.ui._worn_count(wield_name)
                if worn_result ~= "ok" then
                    setup_failed(cheat, "cannot read the worn container for "
                        .. wield_name .. " (" .. tostring(worn_result) .. " "
                        .. tostring(worn_count) .. "), so a wield could never be"
                        .. " proved")
                    return
                end
                worn_before = worn_count
            elseif string.match(cheat, "^%s*:*wield") then
                setup_failed(cheat, "not `::wield <item_name>`: a line the"
                    .. " read-back cannot name is a wield nobody can prove")
                return
            end
            local level_stat, level_wanted = setup_setlevel(cheat)
            if level_stat == "" then
                setup_failed(cheat, "not `::setlevel <stat name> <level>`: the"
                    .. " engine answers ok to it and sets nothing, and a numeric"
                    .. " stat id cannot be read back to prove it landed")
                return
            end
            local setup_result, setup_detail = t.cheat(cheat)
            if setup_result ~= "ok" then
                setup_failed(cheat, "setup cheat answered "
                    .. tostring(setup_result)
                    .. " (" .. tostring(setup_detail) .. "); last lines: "
                    .. setup_last_lines(2))
                return
            end
            if before ~= nil then
                local landed = t.inv.await(give_name, before + give_count, 10)
                if landed ~= "ok" then
                    local after_result, after_total = t.inv.count(give_name)
                    -- Short of the count asked for is the BACKPACK's
                    -- limit speaking (`Gave 21 x Egg (1944), 7 did not
                    -- fit.`), not a setup that did not happen; nothing
                    -- arriving at all is.
                    if after_result ~= "ok" or after_total <= before then
                        setup_failed(cheat, "the cheat answered ok and no "
                            .. give_name
                            .. " reached the backpack within 10 ticks (held "
                            .. tostring(before) .. " before, "
                            .. tostring(after_total) .. " after)")
                        return
                    end
                end
            elseif before_mark ~= nil then
                local moved = t.await({ level = function()
                    return setup_backpack_mark() ~= before_mark
                end, note = "setup: ::give reaching the backpack" }, 10)
                if moved ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the backpack"
                        .. " did not change within 10 ticks (" .. give_name
                        .. " is not an obj this client can count, so every"
                        .. " slot was watched instead)")
                    return
                end
            elseif worn_before ~= nil then
                local worn_last = worn_before
                local worn_landed = t.await({ level = function()
                    local read_result, reading = t.ui._worn_count(wield_name)
                    if read_result == "ok" then
                        worn_last = reading
                    end
                    return read_result == "ok" and reading > worn_before
                end, note = "setup: ::wield reaching the worn container" }, 10)
                if worn_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. wield_name
                        .. " is not worn 10 ticks later (worn " .. tostring(worn_before)
                        .. " before, " .. tostring(worn_last) .. " after); last lines: "
                        .. setup_last_lines(3))
                    return
                end
            elseif level_stat ~= nil then
                -- ok is not a level: wait for the client's reading.
                local level_last = "unread"
                local level_landed = t.await({ level = function()
                    local read_result, reading = t.skill.read(level_stat)
                    if read_result ~= "ok" then
                        level_last = tostring(read_result) .. " " .. tostring(reading)
                        return false
                    end
                    level_last = "stated=" .. tostring(reading.stated)
                        .. " base_level=" .. tostring(reading.base_level)
                    return reading.stated and reading.base_level == level_wanted
                end, note = "setup: ::setlevel reaching the client" }, 10)
                if level_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. level_stat
                        .. " never read base_level " .. tostring(level_wanted)
                        .. " within 10 ticks (last reading: " .. level_last .. ")")
                    return
                end
            elseif string.match(cheat, "^%s*:*clearinv") then
                -- The same race, and the one cheat every generated
                -- setup list opens with: an unfinished ::clearinv also
                -- makes the NEXT give's before-count wrong.
                local cleared = t.await({ level = setup_backpack_empty,
                    note = "setup: ::clearinv reaching the client" }, 10)
                if cleared ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the"
                        .. " backpack still holds items 10 ticks later")
                    return
                end
            end
        end
        -- Every OTHER cheat (::setvar, a quest's own reset
        -- debugproc) has the same one-tick reply/effect gap with no
        -- single reading to wait on, so the loop ends on the tick
        -- boundary its last reply outran.  run()'s first row reads a
        -- client that has seen the setup, which is what `setup` means.
        t.ticks(1)
        t.settle()
    end
    return quest_run(t)
end
return QUEST
