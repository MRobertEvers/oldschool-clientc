local LEG_FROM = nil
local LEG_ONLY = false
local LEG_TILE = nil
local QUEST = (function()
return {
    id = "priestperil",
    fixture = "fresh_lumbridge.ini",
        setup = {
        "::clearinv",
        "::setlevel attack 99",
        "::setlevel strength 99",
        "::setlevel defence 99",
        "::setlevel hitpoints 99",
        "::give rune_scimitar 1",
        "::give shark 12",
        "::give bucket_empty 1",
    },

    run = function(t)
        local r, d = t.quest.bind({
            varp = "varp302_priestperil",
            constants = {
                not_started = 0, started = 1, agree_to_kill_dog = 2, killed_dog = 3,
                return_to_drezel = 4, find_drezel_key = 5, unlocked_drezel = 6,
                poured_blessed_water = 7, meet_in_mausoleum = 8,
                begin_bring_essence = 10, end_bring_essence = 60, complete = 60,
                access_holy_barrier = 61,
            },
            row = "quest_priestinperil",
            display = "Priest in Peril",
            points = 1,
        })
        t.step("quest.bind", r == "ok" and "PASS" or "FAIL", d)
        local function cheat(command)
            local cheat_result, cheat_detail = t.cheat(command)
            t.step("cheat " .. command, cheat_result == "ok" and "PASS" or "FAIL",
                command .. " -> " .. tostring(cheat_detail or cheat_result))
        end
        t.exec("equip.weapon", t.player.equip, "rune_scimitar")

        -- LEG 1: King Roald (LC text, king_roald.rs2)
        t.exec("tele-varrock", t.player.teleport, "varrock")
        t.exec("goto-roald", t.player.goto_tile, 3222, 3473, 0)
        t.exec("talkToRoald", t.player.talk_to, "king_roald", 1)
        t.exec("roald-1", t.chat.play, {
            "player:Greetings, your majesty.",
            "npc:Well hello there. What do you want?",
            "player:I'm looking for a quest!",
            "npc:A quest you say?",
            "npc:Are you aware of the temple east of here.",
            "player:No, I don't think I know it...",
            "npc:Hmm, how strange that you don't.",
            "npc:Be a sport and go make sure",
            "choose:No, that sounds boring.",
            "player:No. That sounds boring.",
            "npc:Yes, I dare say it does.",
        })
        t.exec("expect_stage-not-started", t.quest.expect_stage, "not_started")
        t.exec("talkRoald2", t.player.talk_to, "king_roald", 1)
        t.exec("roald-2", t.chat.play, {
            "player:Greetings, your majesty.",
            "npc:Well hello there. What do you want?",
            "player:I'm looking for a quest!",
            "npc:A quest you say?",
            "npc:Are you aware of the temple east of here.",
            "player:No, I don't think I know it...",
            "npc:Hmm, how strange that you don't.",
            "npc:Be a sport and go make sure",
            "choose:Sure.",
            "player:Sure. I don't have anything better to do right now.",
            "npc:Many thanks adventurer!",
        })
        t.exec("expect_stage-started", t.quest.expect_stage, "started")
        t.exec("talkRoald3", t.player.talk_to, "king_roald", 1)
        t.exec("roald-3", t.chat.play, {
            "player:Greetings, your majesty.",
            "npc:Well hello there. What do you want?",
            "npc:You have news of Drezel for me?",
            "player:Where am I supposed to go again?",
            "npc:The temple east of here where Drezel lives.",
            "npc:Don't worry, you can't miss it.",
        })

        -- LEG 2: temple door knock
        t.exec("tele-temple", t.player.teleport, "0_53_54_16_30")
        t.exec("goto-templedoor", t.player.goto_tile, 3407, 3488, 0)
        t.exec("goToTemple", t.player.click_loc, "priestperiltempledoorr", 1)
        t.exec("knock1-open", t.chat.play, {
            "mesbox:You knock at the door",
            "player:Ummmm.....",
            "choose:Roald sent me to check on Drezel.",
            "player:Roald sent me to check on Drezel.",
            "mesbox:Psst",
            "player:Well, as I say, the King sent me",
            "mesbox:And, uh, what would you do",
            "player:I'm not sure.",
            "mesbox:Ah, good, well",
            "choose:Nope.",
            "player:Nope. Something about all this is very suspicious",
            "mesbox:Get lost then!",
        })
        t.exec("expect_stage-still-started", t.quest.expect_stage, "started")
        t.exec("knock2", t.player.click_loc, "priestperiltempledoorr", 1)
        t.exec("knock2-open", t.chat.play, {
            "mesbox:You knock at the door",
            "player:Ummmm.....",
            "choose:Roald sent me to check on Drezel.",
            "player:Roald sent me to check on Drezel.",
            "mesbox:Psst",
            "player:Well, as I say, the King sent me",
            "mesbox:And, uh, what would you do",
            "player:I'm not sure.",
            "mesbox:Ah, good, well",
            "choose:Sure.",
            "player:Sure. I'm a helpful person!",
            "mesbox:HAHAHAHA! Really?",
            "mesbox:It's been really bugging me!",
            "player:Okey-dokey, one dead dog coming up.",
        })
        t.exec("expect_stage-agree", t.quest.expect_stage, "agree_to_kill_dog")

        -- LEG 3: the Temple Guardian dog (instanced, killed for real)
        t.exec("goto-dogtrapdoor", t.player.goto_tile, 3405, 3506, 0)
        t.exec("dogtrapdoor-open", t.player.click_loc, "trapdoor", 1, { at = { 3405, 3507, 0 } })
        t.ticks(3)
        t.exec("goDownToDog", t.player.click_loc, "trapdoor_open", 1, { at = { 3405, 3507, 0 } })
        t.ticks(3)
        t.exec("killTheDog", t.player.attack, "priestperilguarddog", 2, 30)
        t.exec("attackDog.dead", t.npc.await_dead_engaged, 300, 40, { eat = { item = "shark", below = 50 } })
        t.ticks(3)
        t.exec("expect_stage-killed_dog", t.quest.expect_stage, "killed_dog")
        t.exec("dogLadderUp", t.player.click_loc, "ladder_from_cellar", 1, { at = { 3405, 9907, 0 } })
        t.exec("tele-roald2", t.player.teleport, "varrock")
        t.exec("goto-roald2", t.player.goto_tile, 3222, 3473, 0)
        t.exec("returnToKingRoald", t.player.talk_to, "king_roald", 1)
        t.exec("roald-4", t.chat.play, {
            "player:Greetings, your majesty.",
            "npc:Well hello there. What do you want?",
            "npc:You have news of Drezel for me?",
            "player:Yeah, I spoke to the guys at the temple",
            "npc:YOU DID WHAT???",
            "npc:Are you mentally deficient???",
            "player:Did I make a mistake?",
            "npc:YES YOU DID!!!!!",
            "player:B-but Drezel TOLD me to...!",
            "npc:No, you absolute cretin!",
            "npc:You get back there",
            "player:Y-yes your highness.",
        })
        t.exec("expect_stage-return_to_drezel", t.quest.expect_stage, "return_to_drezel")

        -- LEG 4: the gold key from a level-30 Monk of Zamorak (real fight)
        t.exec("tele-temple2", t.player.teleport, "0_53_54_16_30")
        t.exec("goto-templedoor2", t.player.goto_tile, 3407, 3488, 0)
        t.exec("returnToTemple", t.player.click_loc, "priestperiltempledoorr", 1)
        t.ticks(3)
        t.exec("killMonk", t.player.attack, "priestperilevilmonk3", 2, 40)
        t.exec("attackMonk.dead", t.npc.await_dead_engaged, 400, 40, { eat = { item = "shark", below = 50 } })
        t.ticks(3)
        t.exec("goldKeyDropped", t.player.click_obj, "pipkey_gold", 3)
        t.exec("goldKeyHeld", t.inv.await, "pipkey_gold", 1)

        -- LEG 5: upstairs, Drezel behind the cell gate (talk-through)
        t.exec("goto-spiralstairs", t.player.goto_tile, 3417, 3493, 0)
        t.exec("stairsUp", t.player.click_loc, "paterdomus_spiralstairs", 1)
        t.exec("goto-ladder1", t.player.goto_tile, 3410, 3486, 1)
        t.exec("ladderUp", t.player.click_loc, "ladder", 1, { at = { 3410, 3485, 1 } })
        t.exec("goto-cellgate", t.player.goto_tile, 3416, 3489, 2)
        t.exec("talkToDrezel", t.player.click_loc, "pip_prisondoor", 1)
        t.exec("talkThrough-dialog", t.chat.play, {
            "player:Hello.",
            "npc:Oh! You do not appear to be one of those Zamorakians",
            "player:My name's",
            "npc:That is right! Oh, praise be to Saradomin!",
            "npc:me up here",
            "player:How is a river a good defence then?",
            "npc:Well, it is a long tale",
            "choose:You're right, we don't.",
            "player:You're right, we don't.",
            "npc:Well, let's just say",
        })
        t.exec("expect_stage-still-return", t.quest.expect_stage, "return_to_drezel")
        t.exec("talkThrough2", t.player.click_loc, "pip_prisondoor", 1)
        t.exec("talkThrough2-dialog", t.chat.play, {
            "player:Hello.",
            "npc:Oh! You do not appear to be one of those Zamorakians",
            "player:My name's",
            "npc:That is right! Oh, praise be to Saradomin!",
            "npc:me up here",
            "player:How is a river a good defence then?",
            "npc:Well, it is a long tale",
            "choose:Tell me anyway.",
        })
        t.exec("talkThrough2-tale", t.chat.drain, { stop_at = "options" })
        t.exec("talkThrough2-yes", t.chat.choose, "Yes.")
        t.exec("talkThrough2-tail", t.chat.drain, {})
        t.exec("expect_stage-find_drezel_key", t.quest.expect_stage, "find_drezel_key")

        -- LEG 6: back down through the temple, into the underground, the first gate
        t.exec("goto-laddertop", t.player.goto_tile, 3410, 3486, 2)
        t.exec("ladderDown", t.player.click_loc, "laddertop", 1)
        t.exec("stairsDown", t.player.click_loc, "spiralstairstop", 1)
        t.exec("goto-doorinside", t.player.goto_tile, 3409, 3488, 0)
        t.exec("leaveTemple", t.player.click_loc, "priestperiltempledoorr", 1)
        t.exec("goto-dogtrapdoor2", t.player.goto_tile, 3405, 3506, 0)
        local open_r = t.world.loc_near("trapdoor_open", 6)
        if open_r ~= "ok" then
            t.exec("dogtrapdoor2-open", t.player.click_loc, "trapdoor", 1, { at = { 3405, 3507, 0 } })
            t.ticks(3)
        end
        t.exec("enterUnderground", t.player.click_loc, "trapdoor_open", 1, { at = { 3405, 3507, 0 } })
        t.ticks(2)
        t.exec("goto-gate1", t.player.goto_tile, 3405, 9896, 0)
        t.exec("gate1-open", t.player.click_loc, "pip_underground_door1", 1)
        t.exec("gate1-msg", t.msg.expect, "The golden key unlocks the gate")
        t.ticks(3)
        t.exec("gate1-through", t.player.goto_tile, 3405, 9893, 0)

        -- LEG 7: the monuments -- study to find the key monument, swap the golden key
        t.exec("goto-monument1", t.player.goto_tile, 3417, 9892, 0)
        t.exec("study1", t.player.click_loc, "priestperil_grave_base1", 1)
        t.exec("study1-open", t.ui.await_open, "priestperil_gravemonument")
        local seed_r, mausoleum_bits = t.var.server("varp6733_priestperil_mausoleum")
        t.step("monument.seed-initialised", seed_r == "ok" and mausoleum_bits > 0 and "PASS" or "FAIL",
            "priestperil_mausoleum = " .. tostring(mausoleum_bits))
        local seed = math.floor(mausoleum_bits / 4194304) % 128
        local key_grave = 0
        for g = 1, 7 do
            if (seed + g * 17) % 7 + 1 == 3 then key_grave = g end
        end
        t.note("seed " .. seed .. " -> the key monument is grave " .. key_grave)
        t.key("escape")
        t.ticks(2)
        t.exec("goto-keygrave", t.player.goto_tile, 3417, 9892, 0)
        local key_target = t.player.by_symbol("loc", "priestperil_grave_base" .. key_grave)
        t.exec("useKeyForKey", t.player.use_on, "pipkey_gold", key_target)
        t.exec("swapKey-iron", t.inv.await, "pipkey_iron", 1, 10)

        -- LEG 8: the well -- fill the bucket with murky water
        local well = t.player.by_symbol("loc", "priestperil_well")
        t.exec("fillBucket", t.player.use_on, "bucket_empty", well)
        t.exec("fillBucket-murky", t.inv.await, "bucket_murkywater", 1, 10)

        -- back up: gate, ladder, temple, stairs, ladder to the cell floor
        t.exec("goto-gate1-back", t.player.goto_tile, 3405, 9897, 0)
        t.exec("gate1-back-through", t.player.goto_tile, 3405, 9906, 0)
        t.exec("cellarLadderUp", t.player.click_loc, "ladder_from_cellar", 1, { at = { 3405, 9907, 0 } })
        t.ticks(2)
        t.exec("goto-templedoor-back", t.player.goto_tile, 3407, 3488, 0)
        t.exec("enterTemple-back", t.player.click_loc, "priestperiltempledoorr", 1)
        t.exec("goto-spiralstairs-back", t.player.goto_tile, 3417, 3493, 0)
        t.exec("stairsUp-back", t.player.click_loc, "paterdomus_spiralstairs", 1)
        t.exec("goto-ladder1-back", t.player.goto_tile, 3410, 3486, 1)
        t.exec("goUpWithWaterToSecondFloor", t.player.click_loc, "ladder", 1, { at = { 3410, 3485, 1 } })
        t.exec("goto-cellgate-back", t.player.goto_tile, 3416, 3489, 2)

        -- LEG 9: the iron key on the cell gate (stage 6), Drezel blesses the water
        local cell_door = t.player.by_symbol("loc", "pip_prisondoor")
        t.exec("openDoor", t.player.use_on, "pipkey_iron", cell_door)
        t.exec("unlockCell-dialog", t.chat.play, { "npc:Oh! Thank you! You have found the key!" })
        t.exec("expect_stage-unlocked_drezel", t.quest.expect_stage, "unlocked_drezel")

        -- LEG 10: Drezel blesses the murky water (use the bucket on him), then talk
        local drezel_cell = t.player.by_symbol("npc", "priestperiltrappedmonk")
        t.exec("blessWater", t.player.use_on, "bucket_murkywater", drezel_cell)
        t.exec("blessWater-dialog", t.chat.play, {
            "player:I have some water from the Salve. It seems to have been desecrated though.",
            "npc:Yes, good thinking adventurer! Give it to me, I will bless it!",
        })
        t.exec("blessWater-blessed", t.inv.await, "bucket_blessedwater", 1, 10)
        t.exec("talkFreed", t.player.talk_to, "priestperiltrappedmonk", 1)
        t.exec("talkFreed-dialog", t.chat.play, {
            "player:The key fitted the lock! You're free to leave now!",
            "npc:Well excellent work adventurer!",
            "player:I have some blessed water from the Salve in this bucket.",
            "npc:Yes! Great idea!",
        })

        -- LEG 11: pour it on the vampire's coffin (stage 7), tell Drezel (stage 8)
        t.exec("enterCell", t.player.click_loc, "pip_prisondoor", 1)
        t.ticks(3)
        local coffin = t.player.by_symbol("loc", "priestperil_coffin_noanim")
        t.exec("useBlessedWater", t.player.use_on, "bucket_blessedwater", coffin)
        t.exec("expect_stage-poured_blessed_water", t.quest.expect_stage, "poured_blessed_water")
        t.exec("bucket-returned", t.inv.await, "bucket_empty", 1, 10)
        t.exec("leaveCell", t.player.click_loc, "pip_prisondoor", 1)
        t.ticks(3)
        t.exec("talkToDrezelAfterFreeing", t.player.talk_to, "priestperiltrappedmonk", 1)
        t.exec("talkPoured-dialog", t.chat.play, {
            "player:I poured the blessed water over the vampires coffin.",
            "npc:Excellent work adventurer! I am free at last!",
            "npc:Look for me down there.",
        })
        t.exec("expect_stage-meet_in_mausoleum", t.quest.expect_stage, "meet_in_mausoleum")

        -- LEG 12: out of the temple, the east trapdoor, Drezel at the monument (stage 10)
        t.exec("goto-laddertop-2", t.player.goto_tile, 3410, 3486, 2)
        t.exec("ladderDown-2", t.player.click_loc, "laddertop", 1)
        t.exec("goto-stairstop-2", t.player.goto_tile, 3417, 3493, 1)
        t.exec("stairsDown-2", t.player.click_loc, "spiralstairstop", 1)
        t.exec("goto-doorinside-2", t.player.goto_tile, 3409, 3488, 0)
        t.exec("leaveTemple-2", t.player.click_loc, "priestperiltempledoorr", 1)
        t.exec("goto-easttrapdoor", t.player.goto_tile, 3422, 3484, 0)
        t.exec("easttrapdoor-open", t.player.click_loc, "pipeastsidetrapdoor", 1, { at = { 3422, 3485, 0 } })
        t.ticks(3)
        t.exec("easttrapdoor-descend", t.player.click_loc, "pipeastsidetrapdoor_open", 1, { at = { 3422, 3485, 0 } })
        t.ticks(2)
        t.exec("talkToDrezelUnderground", t.player.talk_to, "priestperiltrappedmonk2", 1)
        t.exec("meetDrezel-dialog", t.chat.play, {
            "npc:Ah,",
            "player:Why, what's happened?",
            "npc:From what I can tell",
            "npc:and have used some kind",
            "npc:it will spread along",
            "player:What can we do",
            "npc:Well, as you can see",
            "npc:here focussing",
            "npc:find some kind of way",
            "player:Couldn't you bless",
            "npc:No, that would not work",
            "npc:I have only one idea",
            "player:What's that?",
            "npc:I have heard rumours",
            "npc:Should you be able",
            "player:Kind of like a filter",
            "npc:Well I have no knowledge",
        })
        t.exec("expect_stage-begin_bring_essence", t.quest.expect_stage, "begin_bring_essence")

        -- LEG 13: the holy barrier while the Salve is still polluted
        t.exec("barrierBlocked", t.player.click_loc, "pip_underground_wall_side_withportal", 1)
        t.exec("barrierBlocked-dialog", t.chat.play, {
            "npc:STOP!",
            "player:Can't I go through here?",
            "npc:No, you cannot!",
        })

        -- LEG 14: the essence -- noted essence is refused, then three hand-ins
        cheat("::give cert_blankrune 5")
        t.ticks(2)
        local drezel_m = t.player.by_symbol("npc", "priestperiltrappedmonk2")
        t.exec("certRefused", t.player.use_on, "cert_blankrune", drezel_m)
        t.exec("certRefused-dialog", t.chat.play, {
            "player:I brought you some Rune Essence.",
            "npc:You have brought me notes",
        })
        t.exec("expect_stage-still-10", t.quest.expect_stage, "begin_bring_essence")
        cheat("::clearinv")
        cheat("::give blankrune 10")
        cheat("::give blankrune_high 8")
        t.ticks(2)
        t.exec("handIn1", t.player.use_on, "blankrune", drezel_m)
        t.ticks(2)
        t.exec("expect_stage-28", t.var.expect, "varp302_priestperil", 28)
        t.exec("moreQuestion", t.player.talk_to, "priestperiltrappedmonk2", 1)
        t.exec("moreQuestion-dialog", t.chat.play, {
            "player:How many more essences do I need to bring you?",
            "npc:I need 32 more",
        })
        cheat("::give blankrune 9")
        cheat("::give blankrune_high 9")
        t.ticks(2)
        t.exec("handIn2", t.player.use_on, "blankrune_high", drezel_m)
        t.ticks(2)
        t.exec("expect_stage-46", t.var.expect, "varp302_priestperil", 46)
        local snapshot_result, xp_before = t.skill.snapshot()
        t.check("reward.snapshot", snapshot_result, "prayer xp snapshot before the hand-in -> " .. tostring(snapshot_result))
        cheat("::give blankrune 14")
        t.ticks(2)
        t.exec("bringDrezelEssence", t.player.use_on, "blankrune", drezel_m)
        t.exec("handIn3-dialog", t.chat.play, {
            "npc:Excellent! That should do it!",
            "npc:Please take this dagger",
            "npc:it has the power to prevent werewolves",
        })
        t.quest.expect_complete()
        local gain_result, gain_detail = t.skill.expect_gain("prayer", 1406, xp_before)
        t.check("reward.prayer_xp", gain_result, "prayer gain 1406 xp -> " .. tostring(gain_detail))
        local dagger_result, dagger_detail = t.inv.expect_has("dagger_wolfbane", 1)
        t.check("reward.dagger", dagger_result, "wolfbane dagger in backpack -> " .. tostring(dagger_detail))

        -- LEG 15: the barrier at 60 says to speak to Drezel first; his advice grants passage (61)
        t.exec("barrierAdvice", t.player.click_loc, "pip_underground_wall_side_withportal", 1)
        t.exec("barrierAdvice-dialog", t.chat.play, {
            "npc:STOP!",
            "player:Can't I go through here?",
            "npc:Yes, now the Salve is restored you may, but speak to me first",
        })
        t.exec("talkAdvice", t.player.talk_to, "priestperiltrappedmonk2", 1)
        t.exec("talkAdvice-dialog", t.chat.play, {
            "player:So can I pass through that barrier now?",
            "npc:Ah, ",
            "npc:Morytania is an evil land",
            "npc:You should take some basic precautions",
            "npc:In many ways Werewolves",
            "npc:and it is a holy relic",
            "npc:wolf form is incredibly powerful",
            "player:Okay, I will keep it equipped",
        })
        t.exec("expect_stage-access_holy_barrier", t.quest.expect_stage, "access_holy_barrier")

        -- the free-space guard (invented): a full backpack cannot reclaim the dagger; an empty one can
        cheat("::clearinv")
        t.exec("reclaimDagger", t.player.talk_to, "priestperiltrappedmonk2", 1)
        t.exec("reclaimDagger-dialog", t.chat.play, {
            "player:I've lost my wolfbane dagger.",
            "npc:Yes, I know! Luckily for you it washed up",
            "npc:It's a family heirloom after all!",
            "player:Thanks for that!",
        })
        t.exec("reclaimDagger-held", t.inv.await, "dagger_wolfbane", 1, 10)

        -- LEG 16: through the barrier
        t.exec("barrierPass", t.player.click_loc, "pip_underground_wall_side_withportal", 1)
        t.exec("barrierPass-msg", t.msg.expect, "You pass through the holy barrier")
        t.finish(0)
    end,
}

end)()

if type(QUEST) == "table" and QUEST.legs ~= nil then
    local legs_quest = QUEST
    QUEST = { setup = legs_quest.setup, run = function(t)
        return t.core_legs_drive(legs_quest, { from = LEG_FROM, only = LEG_ONLY, tile = LEG_TILE })
    end }
end
if type(QUEST) ~= "table" or type(QUEST.run) ~= "function" then
    error("quest file did not return { run = function(t) ... end }"
        .. " or { legs = { { name =, run = function(t) ... end }, ... } }")
end
local quest_setup = QUEST.setup
-- A setup that is not a list of cheat lines is a setup nobody reads:
-- refuse it rather than run the quest against an unstated world.
if quest_setup ~= nil and type(quest_setup) ~= "table" then
    error("quest file's setup is a " .. type(quest_setup)
        .. ", not a table of cheat lines")
end
-- A checkpoint run resumes a player who already went through setup
-- (and legs 1..K-1): the setup list is NOT run again.
if LEG_FROM and LEG_FROM > 1 then
    quest_setup = nil
end
local quest_run = QUEST.run
QUEST.run = function(t)
    -- WAIT FOR THE LOGIN GRANT before the first setup cheat.
    --
    -- The backpack a fixture starts with is not in the fixture: the
    -- containers are adopted EMPTY (torirs_server_world.c, "what goes
    -- in them the first time a character connects is content's") and
    -- content's [login,_] -> [proc,newplayer_inv] fills them on a
    -- later tick than the one this script starts on.  Measured
    -- 2026-09-19 (build/quest_gate/closer_setup2 row 1,
    -- closer_setup3): `::clearinv` issued on the first frame answers
    -- "Cleared 0 item(s).", the fourteen tutorial slots land behind
    -- it, and a `::give` before the grant is overwritten by it -- a
    -- setup list that answered `ok` three times and left the world it
    -- promised in none of them.  A fixed `t.ticks(n)` does not fix it
    -- (the grant landed on tick 1 in one run and after three cheats in
    -- the next); the arrival itself is the signal, so wait for it.
    --
    -- Bounded, and proceeding either way: a fixture whose character
    -- really does hold nothing pays the budget and runs its setup
    -- anyway, rather than failing a quest over an empty backpack.
    t.await({ level = function()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return true
            end
        end
        return false
    end, note = "setup: the login grant" }, 10)
    t.settle()
    -- A CHEAT'S REPLY OUTRUNS ITS EFFECT by exactly one server tick.
    --
    -- t.cheat waits for the reply line (core.lua: QD.cheat ->
    -- msg.await), and the server SAYS `Gave 3 x Egg (1944).` from
    -- inside the ladder branch itself, while the backpack the same
    -- branch just wrote reaches the client in the container
    -- listener's UPDATE_INV at the END of that tick
    -- (torirs_server_world.c, the ::give branch: `the backpack's
    -- listener sends an UPDATE_INV without this branch knowing a
    -- packet exists`).  So the setup loop used to hand run() a client
    -- that had heard about the items and not yet received them, and
    -- every quest whose first rows read t.inv.count saw an empty
    -- backpack from a setup that had answered `ok` three times.
    -- Measured 2026-09-21 (build/quest_gate/lag_probe): row `lag.t0`
    -- FAIL `egg: absent`, row `lag.t1` -- one t.ticks(1) later --
    -- PASS `3`.  Two seam fixers reported it as `::give from setup
    -- lands nothing` (docs/QUEST_AUTHORING.md trap 23).
    --
    -- A ::give is therefore not done when it answers: it is done when
    -- the CLIENT can count the items, which is also the only check
    -- that catches the ladder's own silent misses -- `::give
    -- nosuchitemname` and an ambiguous name both `say()` their
    -- complaint and return RAN, i.e. `ok`, having given nothing
    -- (same file, `No item named '%s'.` / `Which %s? %s`).  Each one
    -- is now a FAIL row named after the cheat, exactly like a cheat
    -- that answered no_row.
    local function setup_give(text)
        local name, count = string.match(text, "^%s*:*give%s+([%w_]+)%s*(%d*)")
        if not name then
            return nil
        end
        local wanted = tonumber(count)
        if not wanted or wanted < 1 then
            wanted = 1
        end
        return name, wanted
    end
    -- Name-free fingerprint of the backpack: every slot's count, plus
    -- one per occupied slot so an item ARRIVING in an empty slot
    -- moves it too.  What the fallback below watches when a ::give
    -- names something this client cannot count.
    local function setup_backpack_mark()
        local mark = 0
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                mark = mark + cell.count + 1
            end
        end
        return mark
    end
    local function setup_backpack_empty()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return false
            end
        end
        return true
    end
    -- `::setlevel <stat> <level>` -> stat, level; nil for any other line.
    -- A line that STARTS as a setlevel (the engine's own strncmp prefix)
    -- but does not parse is ("", nil): the engine answers ok to it
    -- and sets nothing.
    local function setup_setlevel(text)
        if not string.match(text, "^%s*:*setlevel") then
            return nil
        end
        local stat, level = string.match(text, "^%s*:*setlevel%s+(%a[%w_]*)%s+(%d+)%s*$")
        if not stat then
            return "", nil
        end
        return stat, tonumber(level)
    end
    -- `::wield <item>` -> item; nil for any other line.  The cheat
    -- answers once the synthesized Wield click is SENT (seam pass 29:
    -- it used to take only an obj id, print its Usage line for a name
    -- and answer ok -- arthur fought Mordred unarmed behind a green
    -- setup), and content may still refuse the wield (a level, a
    -- quest), so the line is done only when the WORN container holds
    -- the item (QD.ui._worn_count, ui.lua).
    local function setup_wield(text)
        return string.match(text, "^%s*:*wield%s+([%w_]+)%s*$")
    end
    local function setup_last_lines(n)
        local lines_result, rows = t.msg.last(n)
        if lines_result ~= "ok" or type(rows) ~= "table" then
            return "(no chat lines)"
        end
        local texts = {}
        for i = 1, #rows do
            texts[#texts + 1] = "'" .. tostring(rows[i].text) .. "'"
        end
        return table.concat(texts, " / ")
    end
    local function setup_failed(cheat, why)
        t.step("setup." .. cheat, "FAIL",
            why .. " -- the world this quest assumes was never stated")
        t.finish(1)
    end
    if type(quest_setup) == "table" then
        for _, cheat in ipairs(quest_setup) do
            -- Counted BEFORE the cheat: a setup list that gives the
            -- same item twice, or gives one the login grant already
            -- put there, is waiting for an INCREASE, not for a total.
            local give_name, give_count = setup_give(cheat)
            local before = nil
            local before_mark = nil
            if give_name then
                local count_result, count_total = t.inv.count(give_name)
                if count_result == "ok" then
                    before = count_total
                else
                    -- A name this client cannot resolve to an obj: the
                    -- server's own cheat_obj_from_name is fuzzy and may
                    -- still have matched one -- but `::give
                    -- nosuchitemname` reaches the SAME `ok` (it say()s
                    -- `No item named` and returns RAN), so the whole
                    -- backpack is watched for any movement instead of
                    -- taking the cheat at its word.
                    before_mark = setup_backpack_mark()
                end
            end
            local wield_name = setup_wield(cheat)
            local worn_before = nil
            if wield_name then
                local worn_result, worn_count = t.ui._worn_count(wield_name)
                if worn_result ~= "ok" then
                    setup_failed(cheat, "cannot read the worn container for "
                        .. wield_name .. " (" .. tostring(worn_result) .. " "
                        .. tostring(worn_count) .. "), so a wield could never be"
                        .. " proved")
                    return
                end
                worn_before = worn_count
            elseif string.match(cheat, "^%s*:*wield") then
                setup_failed(cheat, "not `::wield <item_name>`: a line the"
                    .. " read-back cannot name is a wield nobody can prove")
                return
            end
            local level_stat, level_wanted = setup_setlevel(cheat)
            if level_stat == "" then
                setup_failed(cheat, "not `::setlevel <stat name> <level>`: the"
                    .. " engine answers ok to it and sets nothing, and a numeric"
                    .. " stat id cannot be read back to prove it landed")
                return
            end
            local setup_result, setup_detail = t.cheat(cheat)
            if setup_result ~= "ok" then
                setup_failed(cheat, "setup cheat answered "
                    .. tostring(setup_result)
                    .. " (" .. tostring(setup_detail) .. "); last lines: "
                    .. setup_last_lines(2))
                return
            end
            if before ~= nil then
                local landed = t.inv.await(give_name, before + give_count, 10)
                if landed ~= "ok" then
                    local after_result, after_total = t.inv.count(give_name)
                    -- Short of the count asked for is the BACKPACK's
                    -- limit speaking (`Gave 21 x Egg (1944), 7 did not
                    -- fit.`), not a setup that did not happen; nothing
                    -- arriving at all is.
                    if after_result ~= "ok" or after_total <= before then
                        setup_failed(cheat, "the cheat answered ok and no "
                            .. give_name
                            .. " reached the backpack within 10 ticks (held "
                            .. tostring(before) .. " before, "
                            .. tostring(after_total) .. " after)")
                        return
                    end
                end
            elseif before_mark ~= nil then
                local moved = t.await({ level = function()
                    return setup_backpack_mark() ~= before_mark
                end, note = "setup: ::give reaching the backpack" }, 10)
                if moved ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the backpack"
                        .. " did not change within 10 ticks (" .. give_name
                        .. " is not an obj this client can count, so every"
                        .. " slot was watched instead)")
                    return
                end
            elseif worn_before ~= nil then
                local worn_last = worn_before
                local worn_landed = t.await({ level = function()
                    local read_result, reading = t.ui._worn_count(wield_name)
                    if read_result == "ok" then
                        worn_last = reading
                    end
                    return read_result == "ok" and reading > worn_before
                end, note = "setup: ::wield reaching the worn container" }, 10)
                if worn_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. wield_name
                        .. " is not worn 10 ticks later (worn " .. tostring(worn_before)
                        .. " before, " .. tostring(worn_last) .. " after); last lines: "
                        .. setup_last_lines(3))
                    return
                end
            elseif level_stat ~= nil then
                -- ok is not a level: wait for the client's reading.
                local level_last = "unread"
                local level_landed = t.await({ level = function()
                    local read_result, reading = t.skill.read(level_stat)
                    if read_result ~= "ok" then
                        level_last = tostring(read_result) .. " " .. tostring(reading)
                        return false
                    end
                    level_last = "stated=" .. tostring(reading.stated)
                        .. " base_level=" .. tostring(reading.base_level)
                    return reading.stated and reading.base_level == level_wanted
                end, note = "setup: ::setlevel reaching the client" }, 10)
                if level_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. level_stat
                        .. " never read base_level " .. tostring(level_wanted)
                        .. " within 10 ticks (last reading: " .. level_last .. ")")
                    return
                end
            elseif string.match(cheat, "^%s*:*clearinv") then
                -- The same race, and the one cheat every generated
                -- setup list opens with: an unfinished ::clearinv also
                -- makes the NEXT give's before-count wrong.
                local cleared = t.await({ level = setup_backpack_empty,
                    note = "setup: ::clearinv reaching the client" }, 10)
                if cleared ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the"
                        .. " backpack still holds items 10 ticks later")
                    return
                end
            end
        end
        -- Every OTHER cheat (::setvar, a quest's own reset
        -- debugproc) has the same one-tick reply/effect gap with no
        -- single reading to wait on, so the loop ends on the tick
        -- boundary its last reply outran.  run()'s first row reads a
        -- client that has seen the setup, which is what `setup` means.
        t.ticks(1)
        t.settle()
    end
    return quest_run(t)
end
return QUEST
