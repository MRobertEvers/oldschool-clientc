local LEG_FROM = nil
local LEG_ONLY = false
local LEG_TILE = nil
local QUEST = (function()
-- Royal Trouble parity driver (scratch; vm-parity1). Drives the whole quest through the real client:
-- every guide step in RoyalTrouble.java's ladder is a click, a talk, a use or a fight.
-- START picks the leg to begin at (a run of one leg stages the earlier ones with ::setvar/::give,
-- the full run is START=1).
local START = 1

return {
    id = "royaltrouble_parity",
    fixture = "fresh_lumbridge.ini",
    setup = {
        "::clearinv",
        "::setlevel agility 45",
        "::setlevel slayer 45",
        "::setlevel hitpoints 70",
        "::setlevel attack 70",
        "::setlevel strength 70",
        "::setlevel defence 60",
        "::royaltrouble",
        "::give coal 5",
        "::give rune_scimitar 1",
        "::give lobster 12",
        "::give 3doseantipoison 2",
    },

    run = function(t)
        t.quest.bind({
            varp = "varb2140_royal_quest",
            constants = { not_started = 0, chose_partner = 10, investigating = 20, complete = 30 },
            display = "Royal Trouble",
            points = 1,
        })
        t.ticks(3)

        local function say(name, npc, op)
            return t.exec(name, t.player.talk_to, npc, op or 1)
        end
        -- walk a conversation through every page; pick `choices` rows in order when options appear
        local function convo(name, choices)
            local i = 0
            for guard = 1, 60 do
                local r, k = t.chat.drain({ stop_at = "options" })
                if k == "options" then
                    i = i + 1
                    local c = choices and choices[i]
                    if c == nil then
                        t.check(name .. ".unexpected_options", false, "no choice scripted for options page " .. i)
                        return
                    end
                    t.exec(name .. ".choose" .. i, t.chat.choose, c)
                else
                    t.check(name .. ".done", r, "drain " .. tostring(r) .. " kind=" .. tostring(k))
                    return
                end
            end
        end
        local function var(name, want)
            local r, v = t.var.server(name)
            t.check("var." .. name .. "=" .. tostring(want), v == want, name .. " server=" .. tostring(v))
        end
        local function has(item, n)
            local r, c = t.inv.count(item)
            t.check("inv." .. item .. ">=" .. n, c ~= nil and c >= n, item .. " count=" .. tostring(c))
        end
        local function setv(name, val)
            t.cheat("::setvar " .. name .. " " .. tostring(val), true)
            t.ticks(2)
        end
        local function use_on_loc(name, item, loc)
            local target = t.player.by_symbol("loc", loc)
            return t.exec(name, t.player.use_on, item, target)
        end

        -- ---------------------------------------------------------------- leg 1: Miscellania
        if START <= 1 then
            t.exec("goto-ghrim", t.player.goto_tile, 2500, 3857, 1)
            say("talkToGhrim", "misc_advisor_ghrim")
            convo("ghrim.start", { "Has anything been happening in the kingdom recently?", "Yes." })
            t.expect("quest.stage.chose_partner", t.quest.expect_stage("chose_partner"))

            t.exec("goto-brand", t.player.goto_tile, 2502, 3853, 1)
            say("talkToPartner", "misc_prince_brand")
            convo("partner", {})
            t.expect("quest.stage.investigating", t.quest.expect_stage("investigating"))

            t.exec("goto-vargas", t.player.goto_tile, 2501, 3861, 1)
            say("talkToVargas", "misc_king_vargas")
            convo("vargas.task", { "Right away, your Majesty." })
            var("varb2141_royal_misc", 10)

            t.exec("goto-gunnhild", t.player.goto_tile, 2527, 3856, 0)
            say("talkToGunnhild", "misc_gardener")
            convo("gunnhild", {})
            var("varb2143_royal_misc_villagers_aboutthefts", 1)
        end

        -- ---------------------------------------------------------------- leg 2: Etceteria
        if START <= 2 then
            if START == 2 then
                setv("varb2140_royal_quest", 20)
                setv("varb2141_royal_misc", 10)
                setv("varb2143_royal_misc_villagers_aboutthefts", 1)
            end
            t.exec("goto-sigrid", t.player.goto_tile, 2612, 3876, 1)
            say("talkToSigrid", "misc_queen_sigrid")
            convo("sigrid.first", { "Of course, it's my duty." })
            var("varb2142_royal_etc", 10)

            t.exec("goto-matilda", t.player.goto_tile, 2604, 3871, 0)
            say("talkToMatilda", "misc_etc_woman_2")
            convo("matilda", {})
            var("varb2144_royal_etc_villagers_aboutthefts", 1)

            t.exec("goto-sigrid2", t.player.goto_tile, 2612, 3876, 1)
            say("talkToSigridAfterMatilda", "misc_queen_sigrid")
            convo("sigrid.report", { "I suppose so..." })
            var("varb2142_royal_etc", 20)
        end

        -- ---------------------------------------------------------------- leg 3: the scroll
        if START <= 3 then
            if START == 3 then
                setv("varb2140_royal_quest", 20)
                setv("varb2141_royal_misc", 10)
                setv("varb2143_royal_misc_villagers_aboutthefts", 1)
                setv("varb2142_royal_etc", 20)
                setv("varb2144_royal_etc_villagers_aboutthefts", 1)
            end
            t.exec("goto-vargas2", t.player.goto_tile, 2501, 3861, 1)
            say("talkToVargasAfterSigrid", "misc_king_vargas")
            convo("vargas.report", {})
            var("varb2141_royal_misc", 20)

            t.exec("goto-ghrim2", t.player.goto_tile, 2500, 3857, 1)
            say("talkToGhrim2", "misc_advisor_ghrim")
            convo("ghrim.sailor", { "King Vargas asked me to talk to you." })
            var("varb2141_royal_misc", 30)

            t.exec("goto-sailor", t.player.goto_tile, 2580, 3847, 0)
            say("talkToSailor", "misc_sailor")
            convo("sailor", { "I'm looking for a sailor..." })
            var("varb2141_royal_misc", 40)

            t.exec("goto-vargas3", t.player.goto_tile, 2501, 3861, 1)
            say("talkToVargasAfterSailor", "misc_king_vargas")
            convo("vargas.scroll", {})
            var("varb2141_royal_misc", 50)
            has("royal_official_scroll", 1)
        end

        -- ---------------------------------------------------------------- leg 4: the dungeon, Donal, the crevice
        if START <= 4 then
            if START == 4 then
                setv("varb2140_royal_quest", 20)
                setv("varb2141_royal_misc", 50)
                t.cheat("::give royal_official_scroll 1", true)
            end
            t.exec("goto-ladder", t.player.goto_tile, 2509, 3848, 0)
            t.exec("goDownLadderToDungeon", t.player.click_loc, "royal_ladder_down", 1)
            convo("ladder.guard", {})
            var("varb2141_royal_misc", 60)
            t.check("scroll.spent", (select(2, t.inv.count("royal_official_scroll")) or 0) == 0, "scroll left the pack")

            t.exec("goto-donal", t.player.goto_tile, 2528, 10258, 0)
            say("talkToDonal", "royal_dwarf_drunk")
            convo("donal", { "Of course. Dealing with monsters is what I do best!" })
            var("varb2141_royal_misc", 80)
            t.inv.await("royal_mining_prop", 1, 8)
            has("royal_mining_prop", 1)

            t.exec("goto-pickaxe-rock", t.player.goto_tile, 2507, 10279, 0)
            t.exec("takePickaxe", t.player.click_loc, "royal_mining_stone_pickaxe", 1)
            t.inv.await("bronze_pickaxe", 1, 6)
            has("bronze_pickaxe", 1)

            t.exec("goto-crevice", t.player.goto_tile, 2505, 10280, 0)
            t.exec("crevice.unpropped", t.player.click_loc, "royal_cavewall_crack", 1)
            convo("crevice.unpropped", {})
            var("varb2145_royal_misc_usedminingprop", 0)
            use_on_loc("usePropOnCrevice", "royal_mining_prop", "royal_cavewall_crack")
            t.ticks(4)
            var("varb2145_royal_misc_usedminingprop", 1)
            t.exec("enterCrevice", t.player.click_loc, "royal_cavewall_crack", 1)
            t.ticks(4)
            local _, wt = t.world.tile()
            t.check("crevice.landed", wt.x == 2505 and wt.z >= 10283, "player tile after the crevice: " .. tostring(wt.x) .. "," .. tostring(wt.z))
        end

        -- ---------------------------------------------------------------- leg 5: repair the lift
        if START <= 5 then
            if START == 5 then
                setv("varb2140_royal_quest", 20)
                setv("varb2141_royal_misc", 80)
                setv("varb2145_royal_misc_usedminingprop", 1)
                t.exec("goto-liftroom", t.player.goto_tile, 2505, 10283, 0)
            end
            local function crate(name, loc, item, n)
                t.exec(name, t.player.click_loc, loc, 1)
                t.inv.await(item, n, 8)
            end
            crate("takePulley", "royal_crate_planks+pulleys", "royal_plank_pulley", 1)
            use_on_loc("usePulleyOnScaffold", "royal_plank_pulley", "royal_side_scaffold_multiloc")
            t.ticks(3)
            var("varb2146_royal_liftstage", 1)
            crate("takePulley2", "royal_crate_planks+pulleys", "royal_plank_pulley", 1)
            crate("takeBeam", "royal_crate_planks", "royal_beam", 1)
            t.exec("useBeamOnPulley", t.player.use_item_on_item, "royal_beam", "royal_plank_pulley")
            has("royal_plank_pulley_long", 1)
            crate("takeBeam2", "royal_crate_planks", "royal_beam", 1)
            t.exec("useBeamOnLongPulley", t.player.use_item_on_item, "royal_beam", "royal_plank_pulley_long")
            has("royal_plank_pulley_longer", 1)
            use_on_loc("useLongerPulleyOnScaffold", "royal_plank_pulley_longer", "royal_side_scaffold_multiloc")
            t.ticks(3)
            var("varb2146_royal_liftstage", 2)
            crate("takePulley3", "royal_crate_planks+pulleys", "royal_plank_pulley", 1)
            use_on_loc("usePulleyOnScaffold2", "royal_plank_pulley", "royal_side_scaffold_multiloc")
            t.ticks(3)
            var("varb2146_royal_liftstage", 3)
            crate("takeRope", "royal_crate_rope", "rope", 1)
            use_on_loc("useRopeOnScaffold", "rope", "royal_side_scaffold_multiloc")
            t.ticks(3)
            var("varb2146_royal_liftstage", 4)
            crate("takeBeam3", "royal_crate_planks", "royal_beam", 1)
            use_on_loc("useBeamOnPlatform", "royal_beam", "royal_lift_platform_multiloc")
            t.ticks(3)
            var("varb2146_royal_liftstage", 5)
            t.exec("pickUpEngine", t.player.click_obj, "royal_coal_engine", 3)
            t.inv.await("royal_coal_engine", 1, 8)
            has("royal_coal_engine", 1)
            t.exec("pickUpManual", t.player.click_obj, "royal_lift_manual", 3)
            t.inv.await("royal_lift_manual", 1, 8)
            t.exec("readManual", t.player.inv_op, "royal_lift_manual", 1)
            t.chat.drain({ stop_at = "none" })
            t.exec("putCoalIntoEngine", t.player.use_item_on_item, "coal", "royal_coal_engine")
            t.exec("putCoalIntoEngine2", t.player.use_item_on_item, "coal", "royal_coal_engine")
            var("varb2156_royal_coalinengine", 2)
            use_on_loc("useEngineOnPlatform", "royal_coal_engine", "royal_engine_platform_multiloc")
            t.ticks(3)
            var("varb2146_royal_liftstage", 6)
            use_on_loc("putCoalIntoEnginePlaced", "coal", "royal_engine_platform_multiloc")
            t.ticks(2)
            use_on_loc("putCoalIntoEnginePlaced2", "coal", "royal_engine_platform_multiloc")
            t.ticks(2)
            use_on_loc("putCoalIntoEnginePlaced3", "coal", "royal_engine_platform_multiloc")
            t.ticks(3)
            var("varb2156_royal_coalinengine", 5)
            var("varb2146_royal_liftstage", 7)
            crate("takeRope2", "royal_crate_rope", "rope", 1)
            t.exec("useLift", t.player.click_loc, "royal_lift_platform_multiloc", 1)
            t.ticks(6)
            var("varb2146_royal_liftstage", 9)
        end

        -- ---------------------------------------------------------------- leg 6: the burnt diary
        local function hp()
            local r, v = t.skill.read("hitpoints")
            return tonumber(v and (v.current or v.level or v)) or -1
        end
        local function eat_if_low(limit)
            if hp() < limit then
                t.exec("eat", t.player.inv_op, "lobster", 1)
                t.ticks(3)
            end
        end
        if START <= 6 then
            if START == 6 then
                setv("varb2140_royal_quest", 20)
                setv("varb2141_royal_misc", 80)
                setv("varb2146_royal_liftstage", 9)
                t.cheat("::give rope 1", true)
                t.exec("goto-plankroom", t.player.goto_tile, 2509, 10288, 1)
            end
            t.exec("takePlank", t.player.click_obj, "woodplank", 3)
            t.inv.await("woodplank", 1, 8)
            t.exec("enterTunnelFromPlankRoom", t.player.click_loc, "royal_small_cave", 1)
            t.ticks(6)
            local _, tile = t.world.tile()
            t.check("tunnel.landed", tile.z ~= nil and tile.z > 10200 and tile.level == 0, "tile " .. tostring(tile.x) .. "," .. tostring(tile.z) .. "," .. tostring(tile.level))
            use_on_loc("attachRope", "rope", "royal_ropeswing_multiloc")
            t.ticks(3)
            var("varb2147_royal_misc_ropeloc", 1)
            t.exec("swingOverRope", t.player.click_loc, "royal_ropeswing_multiloc", 1)
            t.ticks(8)
            t.exec("searchFire1", t.player.click_loc, "royal_fire_remains1", 1)
            t.inv.await("royal_diary1", 1, 8)
            var("varb2148_royal_misc_numberofchapters", 1)
        end

        -- ---------------------------------------------------------------- leg 7: rocks, fires, vents, falling rocks
        if START <= 7 then
            if START == 7 then
                setv("varb2140_royal_quest", 20)
                setv("varb2141_royal_misc", 80)
                setv("varb2146_royal_liftstage", 9)
                setv("varb2148_royal_misc_numberofchapters", 1)
                t.cheat("::give royal_diary1 1", true)
                t.cheat("::give woodplank 1", true)
                t.exec("goto-rocks", t.player.goto_tile, 2550, 10288, 0)
            end
            -- stepping on a slippery rock without the plank: 8 damage and the line
            t.exec("rocks.lookat", t.player.click_loc, "royal_invisible_puddletrap", 1)
            local before = hp()
            t.player.walk_to(2548, 10288, 6)
            t.ticks(5)
            t.check("rocks.hurt", hp() < before, "hitpoints " .. tostring(before) .. " -> " .. tostring(hp()))
            t.check("rocks.msg", select(1, t.msg.expect("You slip and fall on the wet rocks.")) == "ok", "slip line in the ring")
            t.player.walk_to(2550, 10288, 6)
            eat_if_low(40)
            use_on_loc("plankRock1", "woodplank", "royal_invisible_puddletrap")
            t.ticks(6)
            use_on_loc("plankRock2", "woodplank", "royal_invisible_puddletrap")
            t.ticks(6)
            use_on_loc("plankRock3", "woodplank", "royal_invisible_puddletrap")
            t.ticks(6)
            use_on_loc("plankRock4", "woodplank", "royal_invisible_puddletrap")
            t.ticks(6)
            has("woodplank", 1)
            local _, rt = t.world.tile()
            t.check("rocks.crossed", rt.x <= 2538, "tile after the four rocks " .. tostring(rt.x) .. "," .. tostring(rt.z))
            t.exec("searchFire2", t.player.click_loc, "royal_fire_remains2", 1)
            t.inv.await("royal_diary2", 1, 8)
            t.exec("searchFire3", t.player.click_loc, "royal_fire_remains3", 1)
            t.inv.await("royal_diary3", 1, 8)
            var("varb2148_royal_misc_numberofchapters", 3)
            -- a steam vent underfoot
            eat_if_low(50)
            local vb = hp()
            t.player.walk_to(2550, 10268, 12)
            t.ticks(6)
            local _, vt = t.world.tile()
            t.check("vent.hurt", hp() < vb, "hitpoints " .. tostring(vb) .. " -> " .. tostring(hp()) .. " standing on " .. tostring(vt.x) .. "," .. tostring(vt.z))
            t.check("vent.msg", select(1, t.msg.expect("steam vent")) == "ok", "steam line in the ring")
            eat_if_low(50)
            t.exec("searchFire4", t.player.click_loc, "royal_fire_remains4", 1)
            t.inv.await("royal_diary4", 1, 8)
            -- the rocks above the path before the fifth fire
            local rb = hp()
            t.player.walk_to(2563, 10253, 14)
            t.ticks(6)
            t.check("fall.hurt", hp() < rb, "hitpoints " .. tostring(rb) .. " -> " .. tostring(hp()))
            t.check("fall.msg", select(1, t.msg.expect("Rocks tumble")) == "ok", "rockfall line in the ring")
            eat_if_low(50)
            t.exec("searchFire5", t.player.click_loc, "royal_fire_remains5", 1)
            t.inv.await("royal_diary5", 1, 8)
            var("varb2148_royal_misc_numberofchapters", 5)
            -- re-searching gives nothing more
            t.exec("searchFire5.again", t.player.click_loc, "royal_fire_remains5", 1)
            t.check("fire.nothing_more", select(1, t.msg.expect("You don't find any more diary pages")) == "ok", "line seen")
        end

        -- ---------------------------------------------------------------- leg 8: Armod and the snake
        if START <= 8 then
            if START == 8 then
                setv("varb2140_royal_quest", 20)
                setv("varb2141_royal_misc", 80)
                setv("varb2146_royal_liftstage", 9)
                setv("varb2148_royal_misc_numberofchapters", 5)
                setv("varb2143_royal_misc_villagers_aboutthefts", 1)
                setv("varb2144_royal_etc_villagers_aboutthefts", 1)
                setv("varb2142_royal_etc", 20)
                t.cheat("::give royal_diary5 1", true)
                t.exec("goto-fire5", t.player.goto_tile, 2573, 10247, 0)
            end
            -- all five pages found but not read: the crevice refuses
            t.exec("crevice.unread", t.player.click_loc, "royal_cavewall_crack_fremenniks_in", 1)
            convo("crevice.unread", {})
            t.exec("readDiary", t.player.inv_op, "royal_diary5", 1)
            t.chat.drain({ stop_at = "none" })
            var("varb2153_royal_misc_diarychapter5read", 1)
            t.exec("enterSnakesRoom", t.player.click_loc, "royal_cavewall_crack_fremenniks_in", 1)
            t.ticks(6)
            t.exec("goto-armod", t.player.goto_tile, 2575, 10276, 0)
            t.ticks(2)
            say("talkToArmod", "royal_fremennik_teen3")
            convo("armod", {})
            var("varb2141_royal_misc", 110)
            t.exec("equip", t.player.equip, "rune_scimitar")
            t.exec("goto-bosscrack", t.player.goto_tile, 2617, 10270, 0)
            t.exec("enterBossRoom", t.player.click_loc, "royal_cavewall_crack_seasnake_in", 1)
            t.ticks(6)
            t.exec("killBoss", t.player.attack, "royal_sea_snake_mother_smaller", 2, 40)
            t.exec("killBoss.dead", t.npc.await_dead_engaged, 600, 6, { eat = { item = "lobster", below = 35 } })
            var("varb2141_royal_misc", 120)
            t.exec("pickUpBox", t.player.click_obj, "royal_box", 3)
            t.inv.await("royal_box", 1, 10)
            has("royal_box", 1)
            t.exec("leaveBossRoom", t.player.click_loc, "royal_cavewall_crack_seasnake_out", 1)
            t.ticks(6)
            t.exec("goUpRope", t.player.click_loc, "royal_light_exit_with_rope", 1)
            convo("rope.guard", {})
            local _, st = t.world.tile()
            t.check("surface.landed", st.z ~= nil and st.z < 4000, "tile " .. tostring(st.x) .. "," .. tostring(st.z))
        end

        -- ---------------------------------------------------------------- leg 9: Sigrid, the letter, Vargas
        if START <= 9 then
            if START == 9 then
                setv("varb2140_royal_quest", 20)
                setv("varb2141_royal_misc", 120)
                setv("varb2142_royal_etc", 20)
                setv("varb2143_royal_misc_villagers_aboutthefts", 1)
                setv("varb2144_royal_etc_villagers_aboutthefts", 1)
                t.cheat("::give royal_box 1", true)
                t.exec("goto-hole", t.player.goto_tile, 2619, 3863, 0)
            end
            -- the box lost and recovered from the guard by the hole
            t.exec("box.drop", t.player.drop, "royal_box")
            t.ticks(2)
            say("guard.lostbox", "royal_etc_guard")
            convo("guard.lostbox", {})
            t.inv.await("royal_box", 1, 8)
            has("royal_box", 1)
            t.exec("goto-sigrid3", t.player.goto_tile, 2612, 3876, 1)
            local _, snap = t.skill.snapshot()
            say("talkToSigridToFinish", "misc_queen_sigrid")
            convo("sigrid.reward", {})
            var("varb2142_royal_etc", 40)
            t.inv.await("royal_letter", 1, 8)
            has("royal_letter", 1)
            t.inv.await("royal_box_afterquest", 1, 8)
            has("royal_box_afterquest", 1)
            local _, coins = t.inv.count("coins")
            t.check("sigrid.coins", coins ~= nil and coins >= 20000, "coins in pack " .. tostring(coins))
            t.exec("goto-vargas4", t.player.goto_tile, 2501, 3861, 1)
            say("talkToVargasToFinish", "misc_king_vargas")
            convo("vargas.finish", {})
            t.ticks(4)
            t.exec("xp.agility", t.skill.expect_gain, "agility", 5000, snap)
            t.exec("xp.slayer", t.skill.expect_gain, "slayer", 5000, snap)
            t.exec("xp.hitpoints", t.skill.expect_gain, "hitpoints", 5000, snap)
            t.quest.expect_complete()
        end
        t.finish(0)
    end,
}

end)()

if type(QUEST) == "table" and QUEST.legs ~= nil then
    local legs_quest = QUEST
    QUEST = { setup = legs_quest.setup, run = function(t)
        return t.core_legs_drive(legs_quest, { from = LEG_FROM, only = LEG_ONLY, tile = LEG_TILE })
    end }
end
if type(QUEST) ~= "table" or type(QUEST.run) ~= "function" then
    error("quest file did not return { run = function(t) ... end }"
        .. " or { legs = { { name =, run = function(t) ... end }, ... } }")
end
local quest_setup = QUEST.setup
-- A setup that is not a list of cheat lines is a setup nobody reads:
-- refuse it rather than run the quest against an unstated world.
if quest_setup ~= nil and type(quest_setup) ~= "table" then
    error("quest file's setup is a " .. type(quest_setup)
        .. ", not a table of cheat lines")
end
-- A checkpoint run resumes a player who already went through setup
-- (and legs 1..K-1): the setup list is NOT run again.
if LEG_FROM and LEG_FROM > 1 then
    quest_setup = nil
end
-- --script mode: no setup list, nothing to wrap.
if quest_setup == nil or next(quest_setup) == nil then
    return QUEST
end
local quest_run = QUEST.run
QUEST.run = function(t)
    -- WAIT FOR THE LOGIN GRANT before the first setup cheat.
    --
    -- The backpack a fixture starts with is not in the fixture: the
    -- containers are adopted EMPTY (torirs_server_world.c, "what goes
    -- in them the first time a character connects is content's") and
    -- content's [login,_] -> [proc,newplayer_inv] fills them on a
    -- later tick than the one this script starts on.  Measured
    -- 2026-09-19 (build/quest_gate/closer_setup2 row 1,
    -- closer_setup3): `::clearinv` issued on the first frame answers
    -- "Cleared 0 item(s).", the fourteen tutorial slots land behind
    -- it, and a `::give` before the grant is overwritten by it -- a
    -- setup list that answered `ok` three times and left the world it
    -- promised in none of them.  A fixed `t.ticks(n)` does not fix it
    -- (the grant landed on tick 1 in one run and after three cheats in
    -- the next); the arrival itself is the signal, so wait for it.
    --
    -- Bounded, and proceeding either way: a fixture whose character
    -- really does hold nothing pays the budget and runs its setup
    -- anyway, rather than failing a quest over an empty backpack.
    t.await({ level = function()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return true
            end
        end
        return false
    end, note = "setup: the login grant" }, 10)
    t.settle()
    -- A CHEAT'S REPLY OUTRUNS ITS EFFECT by exactly one server tick.
    --
    -- t.cheat waits for the reply line (core.lua: QD.cheat ->
    -- msg.await), and the server SAYS `Gave 3 x Egg (1944).` from
    -- inside the ladder branch itself, while the backpack the same
    -- branch just wrote reaches the client in the container
    -- listener's UPDATE_INV at the END of that tick
    -- (torirs_server_world.c, the ::give branch: `the backpack's
    -- listener sends an UPDATE_INV without this branch knowing a
    -- packet exists`).  So the setup loop used to hand run() a client
    -- that had heard about the items and not yet received them, and
    -- every quest whose first rows read t.inv.count saw an empty
    -- backpack from a setup that had answered `ok` three times.
    -- Measured 2026-09-21 (build/quest_gate/lag_probe): row `lag.t0`
    -- FAIL `egg: absent`, row `lag.t1` -- one t.ticks(1) later --
    -- PASS `3`.  Two seam fixers reported it as `::give from setup
    -- lands nothing` (docs/QUEST_AUTHORING.md trap 23).
    --
    -- A ::give is therefore not done when it answers: it is done when
    -- the CLIENT can count the items, which is also the only check
    -- that catches the ladder's own silent misses -- `::give
    -- nosuchitemname` and an ambiguous name both `say()` their
    -- complaint and return RAN, i.e. `ok`, having given nothing
    -- (same file, `No item named '%s'.` / `Which %s? %s`).  Each one
    -- is now a FAIL row named after the cheat, exactly like a cheat
    -- that answered no_row.
    local function setup_give(text)
        local name, count = string.match(text, "^%s*:*give%s+([%w_]+)%s*(%d*)")
        if not name then
            return nil
        end
        local wanted = tonumber(count)
        if not wanted or wanted < 1 then
            wanted = 1
        end
        return name, wanted
    end
    -- Name-free fingerprint of the backpack: every slot's count, plus
    -- one per occupied slot so an item ARRIVING in an empty slot
    -- moves it too.  What the fallback below watches when a ::give
    -- names something this client cannot count.
    local function setup_backpack_mark()
        local mark = 0
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                mark = mark + cell.count + 1
            end
        end
        return mark
    end
    local function setup_backpack_empty()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return false
            end
        end
        return true
    end
    -- `::setlevel <stat> <level>` -> stat, level; nil for any other line.
    -- A line that STARTS as a setlevel (the engine's own strncmp prefix)
    -- but does not parse is ("", nil): the engine answers ok to it
    -- and sets nothing.
    local function setup_setlevel(text)
        if not string.match(text, "^%s*:*setlevel") then
            return nil
        end
        local stat, level = string.match(text, "^%s*:*setlevel%s+(%a[%w_]*)%s+(%d+)%s*$")
        if not stat then
            return "", nil
        end
        return stat, tonumber(level)
    end
    -- `::wield <item>` -> item; nil for any other line.  The cheat
    -- answers once the synthesized Wield click is SENT (seam pass 29:
    -- it used to take only an obj id, print its Usage line for a name
    -- and answer ok -- arthur fought Mordred unarmed behind a green
    -- setup), and content may still refuse the wield (a level, a
    -- quest), so the line is done only when the WORN container holds
    -- the item (QD.ui._worn_count, ui.lua).
    local function setup_wield(text)
        return string.match(text, "^%s*:*wield%s+([%w_]+)%s*$")
    end
    local function setup_last_lines(n)
        local lines_result, rows = t.msg.last(n)
        if lines_result ~= "ok" or type(rows) ~= "table" then
            return "(no chat lines)"
        end
        local texts = {}
        for i = 1, #rows do
            texts[#texts + 1] = "'" .. tostring(rows[i].text) .. "'"
        end
        return table.concat(texts, " / ")
    end
    local function setup_failed(cheat, why)
        t.step("setup." .. cheat, "FAIL",
            why .. " -- the world this quest assumes was never stated")
        t.finish(1)
    end
    if type(quest_setup) == "table" then
        for _, cheat in ipairs(quest_setup) do
            -- Counted BEFORE the cheat: a setup list that gives the
            -- same item twice, or gives one the login grant already
            -- put there, is waiting for an INCREASE, not for a total.
            local give_name, give_count = setup_give(cheat)
            local before = nil
            local before_mark = nil
            if give_name then
                local count_result, count_total = t.inv.count(give_name)
                if count_result == "ok" then
                    before = count_total
                else
                    -- A name this client cannot resolve to an obj: the
                    -- server's own cheat_obj_from_name is fuzzy and may
                    -- still have matched one -- but `::give
                    -- nosuchitemname` reaches the SAME `ok` (it say()s
                    -- `No item named` and returns RAN), so the whole
                    -- backpack is watched for any movement instead of
                    -- taking the cheat at its word.
                    before_mark = setup_backpack_mark()
                end
            end
            local wield_name = setup_wield(cheat)
            local worn_before = nil
            if wield_name then
                local worn_result, worn_count = t.ui._worn_count(wield_name)
                if worn_result ~= "ok" then
                    setup_failed(cheat, "cannot read the worn container for "
                        .. wield_name .. " (" .. tostring(worn_result) .. " "
                        .. tostring(worn_count) .. "), so a wield could never be"
                        .. " proved")
                    return
                end
                worn_before = worn_count
            elseif string.match(cheat, "^%s*:*wield") then
                setup_failed(cheat, "not `::wield <item_name>`: a line the"
                    .. " read-back cannot name is a wield nobody can prove")
                return
            end
            local level_stat, level_wanted = setup_setlevel(cheat)
            if level_stat == "" then
                setup_failed(cheat, "not `::setlevel <stat name> <level>`: the"
                    .. " engine answers ok to it and sets nothing, and a numeric"
                    .. " stat id cannot be read back to prove it landed")
                return
            end
            local setup_result, setup_detail = t.cheat(cheat)
            if setup_result ~= "ok" then
                setup_failed(cheat, "setup cheat answered "
                    .. tostring(setup_result)
                    .. " (" .. tostring(setup_detail) .. "); last lines: "
                    .. setup_last_lines(2))
                return
            end
            if before ~= nil then
                local landed = t.inv.await(give_name, before + give_count, 10)
                if landed ~= "ok" then
                    local after_result, after_total = t.inv.count(give_name)
                    -- Short of the count asked for is the BACKPACK's
                    -- limit speaking (`Gave 21 x Egg (1944), 7 did not
                    -- fit.`), not a setup that did not happen; nothing
                    -- arriving at all is.
                    if after_result ~= "ok" or after_total <= before then
                        setup_failed(cheat, "the cheat answered ok and no "
                            .. give_name
                            .. " reached the backpack within 10 ticks (held "
                            .. tostring(before) .. " before, "
                            .. tostring(after_total) .. " after)")
                        return
                    end
                end
            elseif before_mark ~= nil then
                local moved = t.await({ level = function()
                    return setup_backpack_mark() ~= before_mark
                end, note = "setup: ::give reaching the backpack" }, 10)
                if moved ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the backpack"
                        .. " did not change within 10 ticks (" .. give_name
                        .. " is not an obj this client can count, so every"
                        .. " slot was watched instead)")
                    return
                end
            elseif worn_before ~= nil then
                local worn_last = worn_before
                local worn_landed = t.await({ level = function()
                    local read_result, reading = t.ui._worn_count(wield_name)
                    if read_result == "ok" then
                        worn_last = reading
                    end
                    return read_result == "ok" and reading > worn_before
                end, note = "setup: ::wield reaching the worn container" }, 10)
                if worn_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. wield_name
                        .. " is not worn 10 ticks later (worn " .. tostring(worn_before)
                        .. " before, " .. tostring(worn_last) .. " after); last lines: "
                        .. setup_last_lines(3))
                    return
                end
            elseif level_stat ~= nil then
                -- ok is not a level: wait for the client's reading.
                local level_last = "unread"
                local level_landed = t.await({ level = function()
                    local read_result, reading = t.skill.read(level_stat)
                    if read_result ~= "ok" then
                        level_last = tostring(read_result) .. " " .. tostring(reading)
                        return false
                    end
                    level_last = "stated=" .. tostring(reading.stated)
                        .. " base_level=" .. tostring(reading.base_level)
                    return reading.stated and reading.base_level == level_wanted
                end, note = "setup: ::setlevel reaching the client" }, 10)
                if level_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. level_stat
                        .. " never read base_level " .. tostring(level_wanted)
                        .. " within 10 ticks (last reading: " .. level_last .. ")")
                    return
                end
            elseif string.match(cheat, "^%s*:*clearinv") then
                -- The same race, and the one cheat every generated
                -- setup list opens with: an unfinished ::clearinv also
                -- makes the NEXT give's before-count wrong.
                local cleared = t.await({ level = setup_backpack_empty,
                    note = "setup: ::clearinv reaching the client" }, 10)
                if cleared ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the"
                        .. " backpack still holds items 10 ticks later")
                    return
                end
            end
        end
        -- Every OTHER cheat (::setvar, a quest's own reset
        -- debugproc) has the same one-tick reply/effect gap with no
        -- single reading to wait on, so the loop ends on the tick
        -- boundary its last reply outran.  run()'s first row reads a
        -- client that has seen the setup, which is what `setup` means.
        t.ticks(1)
        t.settle()
    end
    return quest_run(t)
end
return QUEST
