local LEG_FROM = nil
local LEG_ONLY = false
local LEG_TILE = nil
local QUEST = (function()
-- Cook's Assistant, end to end through the real client -- docs/
-- QUEST_SUITE_KIT.md phase 3, worker 3d; ingredient gathering re-driven for
-- real 2026-09-23 (helper_coverage.py flagged the debugproc-gathered
-- version as a CHEAT on every "Getting the X" panel).
--
-- HOW THIS FILE WAS MADE, precisely. `tools/quest_gate/new_quest.py
-- cooksassistant` emits a skeleton from the Quest Helper guide; that
-- skeleton was READ and then discarded for this one quest, and the D2-era
-- hand file was modernised onto the phase-2 verb kit instead (quest.bind,
-- t.exec, inv.await, skill.snapshot, quest.expect_complete). Checked against
-- content rather than guessed:
--
--   * Giving all three ingredients (`::give egg/pot_flour/bucket_milk`)
--     BEFORE ever talking to the Cook -- which the generator used to do in
--     `setup` -- is wrong for this quest. quest_cook.rs2's accept branch
--     ([label,cooks_assistant_whats_wrong] case 1) checks `inv_total` for
--     all three and jumps straight to `cooks_assistant_completion` in the
--     SAME Talk-to when they are already held -- so that setup collapses
--     the whole test into one dialogue and destroys the exact re-talk this
--     file exists to exercise (QUEST_SUITE_KIT phase 2d: player.talk_to's
--     re-talk fix, proved by this file staying green with no local
--     `talk_to_and_settle` shim). So the three ingredients are gathered
--     AFTER accepting (below, by real clicks: bought, picked, milled and
--     milked -- see the "gather the ingredients" section), and the hand-in
--     is driven through a real SECOND player.talk_to click, exactly the
--     shape `quest_cook_test_ingredients.rs2`'s own banner describes --
--     just without reaching for its debugproc, which hands over the three
--     FINISHED items and skips every step Quest Helper's guide lists for
--     getting them (a CHEAT, CLAUDE.md/trap 16: it remains a legitimate BMP
--     screenshot-rig adapter, just not evidence a playthrough happened).
--   * Hans has no Quest Helper guide at all, so the "regenerated from the
--     scaffold" half of the phase-3 proof holds for neither quest. What IS
--     proved here is the other half: no local helper functions, the phase-2
--     verbs doing the work, and a re-talk that mounts a genuinely different
--     page.
--
-- `::cook` (quest_cook.rs2's own reset/cheat adapter) resets %cookquest to
-- 0, clears the three ingredients and teleports the player beside the cook:
-- the fixture only has to be A character, not one already standing in the
-- kitchen. It writes no completion state -- it resets.
--
-- WHICH ROWS SHOOT. t.exec and t.check shoot the row they write; plain
-- t.expect/t.step rows do not, and gate.py's minimum-shape rule is per row
-- (tools/quest_gate/gate.py `shooting_row_names`), so an action that changes
-- the screen goes through t.exec and a pure read stays a plain expect.
-- That is the pattern to copy: photograph the clicks, not the readings.

return {
    id = "cooks_assistant",
    fixture = "fresh_lumbridge.ini",
    setup = { "::cook" },

    -- A relay file (docs/quest_authoring/relay.md "Checkpoints"): the harness
    -- binds this table with t.quest.bind before the first leg that runs --
    -- after setup, before anything else touches %qp, so
    -- quest.expect_complete's points row has a true "before" reading, and a
    -- leg resumed from a checkpoint (run.py --from-leg K) is bound the same.
    bind = {
        varp = "varp29_cookquest",
        constants = { not_started = 0, started = 1, complete = 2 },
        row = "quest_cooksassistant",
        display = "Cook's Assistant",
        points = 1,
    },

    legs = {
        {
            name = "start",
            run = function(t)
                -- Leg 1: talk to the Cook, accept (stage not_started -> started).
                -- ::cook's own varp write and teleport are server-side; give the
                -- client a couple of ticks to see them before reading anything
                -- (the same class of race hans.lua's own constants read settles
                -- for -- a cheat's effect is not visible client-side the instant
                -- the cheat call returns).
                t.ticks(3)
                t.expect("cooksassistant.reset", t.quest.expect_stage("not_started"))

                -- ------------------------------------------------------- greet
                t.exec("cooksassistant.greet", t.player.talk_to, "cook")
                t.expect("cooksassistant.expect_head", t.chat.expect_head("cook"))

                -- ---------------------------------------------- "What's wrong?"
                -- chat.drain's own return is the stop_at kind it reached, which is
                -- an "ok" result either way -- t.expect grades PASS on "ok", and
                -- the stop_at page itself is not shot by drain (it returns before
                -- shooting the page it stops on), so the named shot after is a
                -- genuinely new capture, never a re-shoot of a page drain already
                -- photographed.
                local drain1_result, drain1_detail = t.chat.drain({ stop_at = "options" })
                t.expect("cooksassistant.drain_to_opener", drain1_result, drain1_detail)
                t.shot("cook-menu")

                t.exec("cooksassistant.choose_whats_wrong", t.chat.choose, "What's wrong?")

                -- ------------------------------------------- offer to help / accept
                local drain2_result, drain2_detail = t.chat.drain({ stop_at = "options" })
                t.expect("cooksassistant.drain_to_offer", drain2_result, drain2_detail)
                t.shot("cook-offer-menu")

                t.exec("cooksassistant.choose_help", t.chat.choose, "Yes, I'll help you.")

                -- Accepting just plays case 1's own two lines ("Yes, I'll help
                -- you." / "Oh thank you, thank you. I need milk, an egg and
                -- flour...") and closes -- [label,cooks_assistant_whats_wrong]'s
                -- case 1 has no trailing `@cooks_assistant_inprogress;` jump, so
                -- RuneScript's labels do NOT fall through into one another. The
                -- "I'm afraid I don't have any yet" / "I'll get right on it."
                -- reminder only exists on a LATER, separate talk while cookquest is
                -- already 1.
                local drain3_result, drain3_detail = t.chat.drain({ stop_at = "none" })
                t.expect("cooksassistant.drain_close", drain3_result, drain3_detail)
                t.shot("cook-dialogue-closed")

                t.expect("cooksassistant.started", t.quest.expect_stage("started"))
            end,
        },
        {
            name = "gather",
            run = function(t)
                -- Leg 2: the four Quest Helper gathering panels (store, egg, flour,
                -- milk). Starts and ends out of any dialogue: a quiet checkpoint.
                -- ------------------------------------------- gather the ingredients
                -- Driven for real. `::cookbmp_test_give_ingredients`
                -- (quest_cook_test_ingredients.rs2) hands over the three FINISHED
                -- items directly -- it is a screenshot-rig adapter (the file's own
                -- banner: built so a headless BMP capture never has to teleport or
                -- auto-talk), not a route this quest's own deliverable can be
                -- skipped through (CLAUDE.md/trap 16: an item the quest makes you
                -- gather is driven by clicks, never `::give`d or cheated). Every leg
                -- below is one of Quest Helper's own panels -- "Starting off",
                -- "Getting the Egg", "Getting the Flour", "Getting the Milk" -- each
                -- driven by the real click its .rs2 trigger names. Every tile below
                -- is a real placement: `generalshopkeeper1`'s and `fat_cow`'s own
                -- `*.spawn`/map rows, `fai_varrock_wheat_corner`/`hopper1`/
                -- `hopperlevers1`/`millbase`'s own `m49_51.jl2` placements (grepped
                -- against the ids the Quest Helper WorldPoints name) -- and they all
                -- agree with `quest_cook.rs2`'s own `cookbmp_cow`/`_egg`/`_hopper`/
                -- `_levers`/`_mill` BMP-rig teleport targets, which decode to the
                -- same coordinates.

                -- ---- getBucket / getPot: buy from the Lumbridge General Store ----
                t.exec("cooksassistant.goto_store", t.player.goto_tile, 3209, 3247, 0) -- generalshopkeeper1's *.spawn row (m50_50.spawn)
                t.exec("cooksassistant.shop_open", t.shop.open, "generalshopkeeper1", 3, "generalshop1")
                t.exec("cooksassistant.buy_bucket", t.shop.buy, "bucket_empty", 1)
                t.exec("cooksassistant.buy_pot", t.shop.buy, "pot_empty", 1)
                -- shop.close takes no argument (trap 12's hollow-by-arity list, not
                -- the hollow-detail one) -- t.exec would grade it bad verb/target.
                local shop_close_result, shop_close_detail = t.shop.close()
                t.check("cooksassistant.shop_close", shop_close_result == "ok",
                    "shop.close -> " .. tostring(shop_close_result) .. " " .. tostring(shop_close_detail))

                -- ------------------------- getEgg: pick one off the ground -------------------------
                t.exec("cooksassistant.goto_egg", t.player.goto_tile, 3172, 3301, 0) -- an egg's own OBJ spawn row (m49_51.spawn)
                t.ticks(2) -- gap: a press right after a goto_tile teleport can read `covered`
                -- click_obj answers ok with a nil detail (section 8's hollow list) --
                -- call it directly and write the count read back ourselves.
                local egg_click_result, egg_click_detail = t.player.click_obj("egg")
                local egg_have_read, egg_have_count = t.inv.count("egg")
                t.check("cooksassistant.take_egg", egg_click_result == "ok" and egg_have_count >= 1,
                    "click_obj(egg) -> " .. tostring(egg_click_result) .. " " .. tostring(egg_click_detail)
                        .. " egg=" .. tostring(egg_have_count) .. "(" .. tostring(egg_have_read) .. ")")

                -- ------- getWheat / fillHopper / operateControls / collectFlour -------
                -- goto_tile carries every ladder climb itself (QUEST_AUTHORING.md
                -- section 2's floors-and-ladders bullet): no click_loc on
                -- QIP_COOK_LADDER/_MIDDLE/_TOP, the level argument below is the
                -- whole of climbLadderOne/TwoUp/Three/TwoDown.
                t.exec("cooksassistant.goto_wheat", t.player.goto_tile, 3161, 3292, 0) -- fai_varrock_wheat_corner's own tile (m49_51.jl2 local 25,28)
                t.exec("cooksassistant.pick_wheat", t.player.click_loc, "fai_varrock_wheat_corner", 2) -- op2=Pick
                t.exec("cooksassistant.have_grain", t.inv.await, "grain", 1, 10)

                t.exec("cooksassistant.goto_hopper", t.player.goto_tile, 3166, 3307, 2) -- hopper1's own tile, mill top floor
                t.exec("cooksassistant.fill_hopper", t.player.click_loc, "hopper1", 1) -- op1=Fill, spends inv grain
                -- inv.await(name, 0, ticks) never actually waits (total >= 0 is
                -- always true -- section 8) -- poll the consumption with a real
                -- level predicate instead, the same idiom the hand-in section below
                -- uses for the ingredients the commit consumes.
                local hopper_settle_result, hopper_settle_detail = t.await({
                    level = function()
                        local r, v = t.inv.count("grain")
                        return r == "ok" and v == 0
                    end,
                    note = "cooksassistant.hopper_settle",
                }, 10)
                local grain_after_read, grain_after = t.inv.count("grain")
                t.step("cooksassistant.grain_consumed",
                    (hopper_settle_result == "ok" and grain_after == 0) and "PASS" or "FAIL",
                    "grain consumed by the hopper fill within 10 tick(s) (" .. tostring(hopper_settle_result)
                        .. ") " .. tostring(hopper_settle_detail)
                        .. " grain=" .. tostring(grain_after) .. "(" .. tostring(grain_after_read) .. ")")

                t.exec("cooksassistant.operate_levers", t.player.click_loc, "hopperlevers1", 1) -- op1=Operate, grinds the hopper's grain

                t.exec("cooksassistant.goto_millbase", t.player.goto_tile, 3166, 3306, 0) -- millbase's own tile, mill ground floor
                t.ticks(2) -- gap: a press right after a goto_tile teleport can read `covered`
                -- The multiloc WRAPPER symbol, not either child (trap 20): the
                -- server resolves op1 on it to whichever child this player's own
                -- %mill_showflour currently selects, so pressing the wrapper is
                -- correct whether or not the client's own render of it has caught
                -- up with the levers row above.
                t.exec("cooksassistant.collect_flour", t.player.click_loc, "millbase", 1) -- op1=Empty (millbase_flour's own label), spends inv pot_empty
                t.exec("cooksassistant.have_flour", t.inv.await, "pot_flour", 1, 10)

                -- -------------------------- milkCow: milk the dairy cow --------------------------
                t.exec("cooksassistant.goto_cow", t.player.goto_tile, 3172, 3317, 0) -- fat_cow's own tile (m49_51.jl2 local 36,53)
                t.exec("cooksassistant.milk_cow", t.player.click_loc, "fat_cow", 1) -- op1=Milk, spends inv bucket_empty
                t.exec("cooksassistant.have_milk", t.inv.await, "bucket_milk", 1, 10)

                -- The three deliverables, read back together as the hand-in gate --
                -- what the old cheat-based "has_ingredients" row used to assert,
                -- now true because each was actually gathered above.
                local egg_read, egg_count = t.inv.count("egg")
                local milk_read, milk_count = t.inv.count("bucket_milk")
                local flour_read, flour_count = t.inv.count("pot_flour")
                t.check("cooksassistant.has_ingredients",
                    egg_count == 1 and milk_count == 1 and flour_count == 1,
                    "egg=" .. tostring(egg_count) .. "(" .. tostring(egg_read) .. ")"
                        .. " bucket_milk=" .. tostring(milk_count) .. "(" .. tostring(milk_read) .. ")"
                        .. " pot_flour=" .. tostring(flour_count) .. "(" .. tostring(flour_read) .. ")")
            end,
        },
        {
            name = "handin",
            run = function(t)
                -- Leg 3: back to the kitchen, the hand-in, the reward scroll.
                -- ----------------------------------------------------- hand in
                -- The gathering above (store, egg field, wheat field, mill, cow
                -- field) walked the player clear across Lumbridge, so -- unlike the
                -- old debugproc-gathered version, which never moved the player away
                -- from the cook at all -- a real goto back to the kitchen is needed
                -- before the second talk_to (^cook_coord = 0_50_50_6_14 decodes to
                -- 3206,3214,0, the same tile Quest Helper's own finishQuest
                -- WorldPoint names).
                t.exec("cooksassistant.goto_handin", t.player.goto_tile, 3206, 3214, 0)

                -- The second, separate player.talk_to click this file exists to
                -- exercise (see the banner) -- the same npc, but the chat page now
                -- mounts a DIFFERENT kind/text than the greet above
                -- ("~chatnpc_anim ... How are you getting on ...", not "What am I
                -- to do?"), which is exactly the case `_settle_after_click`'s fix
                -- treats as a fresh mount rather than the stale greet page.
                t.exec("cooksassistant.handin_talk", t.player.talk_to, "cook")

                -- Drain the "how's it going" / thank-you exchange, and stop right
                -- at the completion mesbox rather than past it, so the exact
                -- completion message can be read off the live page instead of
                -- guessed at. `shots` stays at drain's own default (true) --
                -- turning it off here removed the frame-pump drain's per-page shot
                -- costs, and without that pump the very first continue_ inside
                -- drain raced UITree_SetPausePending's clear from the handin_talk
                -- click immediately before it (measured: "chat.continue_: a resume
                -- is already outstanding" on drain's first iteration, gone once
                -- shots reverted to the default true).
                local drain5_result, drain5_detail = t.chat.drain({ stop_at = "mesbox" })
                t.expect("cooksassistant.handin_drain", drain5_result, drain5_detail)

                -- The completion mesbox itself, read and photographed in one row --
                -- t.exec's own shot replaces the hand-taken one that used to
                -- sit here, which was a second capture of the page drain had just
                -- stopped on (measured in review: 0.034% of bytes apart, all of it
                -- a per-tick counter).
                local COMPLETION_MESSAGE = "You give some milk, an egg and some flour to the cook."
                t.exec("cooksassistant.complete_message", t.chat.expect_text, COMPLETION_MESSAGE)

                -- Read cooking xp now, one call before the commit that awards it --
                -- state.lua's own skill.expect_gain banner names this exact row as
                -- the caller it was written to replace.
                local xp_snapshot_result, xp_snapshot = t.skill.snapshot()
                t.step("cooksassistant.xp_before_read", xp_snapshot_result == "ok" and "PASS" or "FAIL",
                    "skill.snapshot before hand-in -> " .. tostring(xp_snapshot_result))

                -- Dismissing the mesbox is what runs the one atomic transaction
                -- (quest_cook.rs2's ~cooks_assistant_commit): state, xp and qp all
                -- move here, then the reward scroll opens. NOT through t.exec:
                -- continue_ takes no target (its own banner: "call it directly and
                -- record it with t.check/t.step instead") and its own success
                -- answer is (ok, nil), which the hollow rule would grade FAIL.
                local continue_result, continue_detail = t.chat.continue_()
                t.expect("cooksassistant.commit_continue", continue_result,
                    continue_detail or "chat.continue_ dismissed the completion mesbox")

                -- The commit's own varp/inventory updates reach the client-visible
                -- copies (and var.server's own read) some ticks after the click
                -- that triggered them -- an honest bounded await rather than a
                -- guessed sleep, so a genuine stuck commit reads as a named FAIL
                -- here rather than surfacing as an unrelated-looking failure in
                -- quest.expect_complete below.
                local commit_settle_result, commit_settle_detail = t.await({
                    level = function()
                        local r, v = t.var.server("varp29_cookquest")
                        return r == "ok" and v == 2
                    end,
                    note = "cooksassistant.commit_settle",
                }, 20)
                t.step("cooksassistant.commit_settle",
                    commit_settle_result == "ok" and "PASS" or "FAIL",
                    "server cookquest -> 2 within 20 ticks (" .. tostring(commit_settle_result)
                        .. ") " .. tostring(commit_settle_detail))

                -- Measured live (D2 pass): cookquest's own settle above can already
                -- read 2 (server, then client) while the backpack still shows all
                -- three ingredients -- the varp and the inventory container reach
                -- the client on separate channels and do not land the same frame.
                -- A client-visibility race, not a second commit, so it gets the
                -- same honest bounded await rather than a second guessed sleep.
                -- This row IS the "the quest ate the ingredients" assertion (the
                -- three separate expect_absent rows it replaces each wrote an empty
                -- detail); the counts it names are read back after the await.
                local gone_result, gone_detail = t.await({
                    level = function()
                        local er, ec = t.inv.count("egg")
                        local mr, mc = t.inv.count("bucket_milk")
                        local fr, fc = t.inv.count("pot_flour")
                        return er == "ok" and ec == 0 and mr == "ok" and mc == 0
                            and fr == "ok" and fc == 0
                    end,
                    note = "cooksassistant.ingredients_settle",
                }, 20)
                local egg_after_read, egg_after = t.inv.count("egg")
                local milk_after_read, milk_after = t.inv.count("bucket_milk")
                local flour_after_read, flour_after = t.inv.count("pot_flour")
                t.step("cooksassistant.ingredients_consumed",
                    (gone_result == "ok" and egg_after == 0 and milk_after == 0 and flour_after == 0)
                        and "PASS" or "FAIL",
                    "all three consumed within 20 ticks (" .. tostring(gone_result)
                        .. ") " .. tostring(gone_detail)
                        .. " egg=" .. tostring(egg_after) .. "(" .. tostring(egg_after_read) .. ")"
                        .. " bucket_milk=" .. tostring(milk_after) .. "(" .. tostring(milk_after_read) .. ")"
                        .. " pot_flour=" .. tostring(flour_after) .. "(" .. tostring(flour_after_read) .. ")")

                -- ---------------------------------------------- the reward scroll
                -- What the scroll ITSELF advertises, read off the component before
                -- anything closes it -- scroll.reward_xp (phase 2b) exists for this
                -- row and this is its only live caller. The number it answers is
                -- then what the stat gain below is checked against, so the two
                -- halves cross-check each other; nothing here is pinned to a
                -- literal reward amount.
                local reward_result, reward_xp = t.scroll.reward_xp("cooking")
                t.check("cooksassistant.scroll_reward_xp",
                    reward_result == "ok" and type(reward_xp) == "number",
                    "scroll.reward_xp(cooking) -> " .. tostring(reward_result)
                        .. " " .. tostring(reward_xp) .. " Cooking XP")

                -- The stat moved by exactly what the scroll just said it would.
                -- skill.expect_gain accepts either unit (whole xp, or the server's
                -- xp*10 tenths) and names which one it matched. `or -1` only guards
                -- the arithmetic inside it when the row above already failed -- a
                -- scroll that carried no Cooking line makes this row fail too,
                -- which is the honest answer, not a skipped check.
                t.expect("cooksassistant.cooking_xp_up",
                    t.skill.expect_gain("cooking", reward_xp or -1, xp_snapshot))

                -- ------------------------------------------------- the committed state
                -- Four rows (varp_complete, scroll_title, points, journal), all
                -- graded by quest.expect_complete itself. It also CLOSES the reward
                -- scroll on its way to the journal (quest.lua's own banner), which
                -- is what the next row checks.
                t.quest.expect_complete()

                -- quest.expect_complete's scroll.close answer only reaches a detail
                -- string, never a verdict (quest.lua grades the JOURNAL close, not
                -- this one), so a reward scroll that refused to close would report
                -- PASS everywhere. This row is that missing grade: after
                -- expect_complete the scroll must be gone, and scroll.title says so
                -- with `not_visible`. It is also the only capture of the screen
                -- after every modal this quest opened has been dismissed.
                local closed_result = t.scroll.title()
                t.check("cooksassistant.scroll_closed", closed_result == "not_visible",
                    "scroll.title after quest.expect_complete -> " .. tostring(closed_result)
                        .. " (expected not_visible -- expect_complete closes the reward scroll)")

                t.finish(0)
            end,
        },
    },
}

end)()

if type(QUEST) == "table" and QUEST.legs ~= nil then
    local legs_quest = QUEST
    QUEST = { setup = legs_quest.setup, run = function(t)
        return t.core_legs_drive(legs_quest, { from = LEG_FROM, only = LEG_ONLY, tile = LEG_TILE })
    end }
end
if type(QUEST) ~= "table" or type(QUEST.run) ~= "function" then
    error("quest file did not return { run = function(t) ... end }"
        .. " or { legs = { { name =, run = function(t) ... end }, ... } }")
end
local quest_setup = QUEST.setup
-- A setup that is not a list of cheat lines is a setup nobody reads:
-- refuse it rather than run the quest against an unstated world.
if quest_setup ~= nil and type(quest_setup) ~= "table" then
    error("quest file's setup is a " .. type(quest_setup)
        .. ", not a table of cheat lines")
end
-- A checkpoint run resumes a player who already went through setup
-- (and legs 1..K-1): the setup list is NOT run again.
if LEG_FROM and LEG_FROM > 1 then
    quest_setup = nil
end
local quest_run = QUEST.run
QUEST.run = function(t)
    -- WAIT FOR THE LOGIN GRANT before the first setup cheat.
    --
    -- The backpack a fixture starts with is not in the fixture: the
    -- containers are adopted EMPTY (torirs_server_world.c, "what goes
    -- in them the first time a character connects is content's") and
    -- content's [login,_] -> [proc,newplayer_inv] fills them on a
    -- later tick than the one this script starts on.  Measured
    -- 2026-09-19 (build/quest_gate/closer_setup2 row 1,
    -- closer_setup3): `::clearinv` issued on the first frame answers
    -- "Cleared 0 item(s).", the fourteen tutorial slots land behind
    -- it, and a `::give` before the grant is overwritten by it -- a
    -- setup list that answered `ok` three times and left the world it
    -- promised in none of them.  A fixed `t.ticks(n)` does not fix it
    -- (the grant landed on tick 1 in one run and after three cheats in
    -- the next); the arrival itself is the signal, so wait for it.
    --
    -- Bounded, and proceeding either way: a fixture whose character
    -- really does hold nothing pays the budget and runs its setup
    -- anyway, rather than failing a quest over an empty backpack.
    t.await({ level = function()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return true
            end
        end
        return false
    end, note = "setup: the login grant" }, 10)
    t.settle()
    -- A CHEAT'S REPLY OUTRUNS ITS EFFECT by exactly one server tick.
    --
    -- t.cheat waits for the reply line (core.lua: QD.cheat ->
    -- msg.await), and the server SAYS `Gave 3 x Egg (1944).` from
    -- inside the ladder branch itself, while the backpack the same
    -- branch just wrote reaches the client in the container
    -- listener's UPDATE_INV at the END of that tick
    -- (torirs_server_world.c, the ::give branch: `the backpack's
    -- listener sends an UPDATE_INV without this branch knowing a
    -- packet exists`).  So the setup loop used to hand run() a client
    -- that had heard about the items and not yet received them, and
    -- every quest whose first rows read t.inv.count saw an empty
    -- backpack from a setup that had answered `ok` three times.
    -- Measured 2026-09-21 (build/quest_gate/lag_probe): row `lag.t0`
    -- FAIL `egg: absent`, row `lag.t1` -- one t.ticks(1) later --
    -- PASS `3`.  Two seam fixers reported it as `::give from setup
    -- lands nothing` (docs/QUEST_AUTHORING.md trap 23).
    --
    -- A ::give is therefore not done when it answers: it is done when
    -- the CLIENT can count the items, which is also the only check
    -- that catches the ladder's own silent misses -- `::give
    -- nosuchitemname` and an ambiguous name both `say()` their
    -- complaint and return RAN, i.e. `ok`, having given nothing
    -- (same file, `No item named '%s'.` / `Which %s? %s`).  Each one
    -- is now a FAIL row named after the cheat, exactly like a cheat
    -- that answered no_row.
    local function setup_give(text)
        local name, count = string.match(text, "^%s*:*give%s+([%w_]+)%s*(%d*)")
        if not name then
            return nil
        end
        local wanted = tonumber(count)
        if not wanted or wanted < 1 then
            wanted = 1
        end
        return name, wanted
    end
    -- Name-free fingerprint of the backpack: every slot's count, plus
    -- one per occupied slot so an item ARRIVING in an empty slot
    -- moves it too.  What the fallback below watches when a ::give
    -- names something this client cannot count.
    local function setup_backpack_mark()
        local mark = 0
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                mark = mark + cell.count + 1
            end
        end
        return mark
    end
    local function setup_backpack_empty()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return false
            end
        end
        return true
    end
    -- `::setlevel <stat> <level>` -> stat, level; nil for any other line.
    -- A line that STARTS as a setlevel (the engine's own strncmp prefix)
    -- but does not parse is ("", nil): the engine answers ok to it
    -- and sets nothing.
    local function setup_setlevel(text)
        if not string.match(text, "^%s*:*setlevel") then
            return nil
        end
        local stat, level = string.match(text, "^%s*:*setlevel%s+(%a[%w_]*)%s+(%d+)%s*$")
        if not stat then
            return "", nil
        end
        return stat, tonumber(level)
    end
    -- `::wield <item>` -> item; nil for any other line.  The cheat
    -- answers once the synthesized Wield click is SENT (seam pass 29:
    -- it used to take only an obj id, print its Usage line for a name
    -- and answer ok -- arthur fought Mordred unarmed behind a green
    -- setup), and content may still refuse the wield (a level, a
    -- quest), so the line is done only when the WORN container holds
    -- the item (QD.ui._worn_count, ui.lua).
    local function setup_wield(text)
        return string.match(text, "^%s*:*wield%s+([%w_]+)%s*$")
    end
    local function setup_last_lines(n)
        local lines_result, rows = t.msg.last(n)
        if lines_result ~= "ok" or type(rows) ~= "table" then
            return "(no chat lines)"
        end
        local texts = {}
        for i = 1, #rows do
            texts[#texts + 1] = "'" .. tostring(rows[i].text) .. "'"
        end
        return table.concat(texts, " / ")
    end
    local function setup_failed(cheat, why)
        t.step("setup." .. cheat, "FAIL",
            why .. " -- the world this quest assumes was never stated")
        t.finish(1)
    end
    if type(quest_setup) == "table" then
        for _, cheat in ipairs(quest_setup) do
            -- Counted BEFORE the cheat: a setup list that gives the
            -- same item twice, or gives one the login grant already
            -- put there, is waiting for an INCREASE, not for a total.
            local give_name, give_count = setup_give(cheat)
            local before = nil
            local before_mark = nil
            if give_name then
                local count_result, count_total = t.inv.count(give_name)
                if count_result == "ok" then
                    before = count_total
                else
                    -- A name this client cannot resolve to an obj: the
                    -- server's own cheat_obj_from_name is fuzzy and may
                    -- still have matched one -- but `::give
                    -- nosuchitemname` reaches the SAME `ok` (it say()s
                    -- `No item named` and returns RAN), so the whole
                    -- backpack is watched for any movement instead of
                    -- taking the cheat at its word.
                    before_mark = setup_backpack_mark()
                end
            end
            local wield_name = setup_wield(cheat)
            local worn_before = nil
            if wield_name then
                local worn_result, worn_count = t.ui._worn_count(wield_name)
                if worn_result ~= "ok" then
                    setup_failed(cheat, "cannot read the worn container for "
                        .. wield_name .. " (" .. tostring(worn_result) .. " "
                        .. tostring(worn_count) .. "), so a wield could never be"
                        .. " proved")
                    return
                end
                worn_before = worn_count
            elseif string.match(cheat, "^%s*:*wield") then
                setup_failed(cheat, "not `::wield <item_name>`: a line the"
                    .. " read-back cannot name is a wield nobody can prove")
                return
            end
            local level_stat, level_wanted = setup_setlevel(cheat)
            if level_stat == "" then
                setup_failed(cheat, "not `::setlevel <stat name> <level>`: the"
                    .. " engine answers ok to it and sets nothing, and a numeric"
                    .. " stat id cannot be read back to prove it landed")
                return
            end
            local setup_result, setup_detail = t.cheat(cheat)
            if setup_result ~= "ok" then
                setup_failed(cheat, "setup cheat answered "
                    .. tostring(setup_result)
                    .. " (" .. tostring(setup_detail) .. "); last lines: "
                    .. setup_last_lines(2))
                return
            end
            if before ~= nil then
                local landed = t.inv.await(give_name, before + give_count, 10)
                if landed ~= "ok" then
                    local after_result, after_total = t.inv.count(give_name)
                    -- Short of the count asked for is the BACKPACK's
                    -- limit speaking (`Gave 21 x Egg (1944), 7 did not
                    -- fit.`), not a setup that did not happen; nothing
                    -- arriving at all is.
                    if after_result ~= "ok" or after_total <= before then
                        setup_failed(cheat, "the cheat answered ok and no "
                            .. give_name
                            .. " reached the backpack within 10 ticks (held "
                            .. tostring(before) .. " before, "
                            .. tostring(after_total) .. " after)")
                        return
                    end
                end
            elseif before_mark ~= nil then
                local moved = t.await({ level = function()
                    return setup_backpack_mark() ~= before_mark
                end, note = "setup: ::give reaching the backpack" }, 10)
                if moved ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the backpack"
                        .. " did not change within 10 ticks (" .. give_name
                        .. " is not an obj this client can count, so every"
                        .. " slot was watched instead)")
                    return
                end
            elseif worn_before ~= nil then
                local worn_last = worn_before
                local worn_landed = t.await({ level = function()
                    local read_result, reading = t.ui._worn_count(wield_name)
                    if read_result == "ok" then
                        worn_last = reading
                    end
                    return read_result == "ok" and reading > worn_before
                end, note = "setup: ::wield reaching the worn container" }, 10)
                if worn_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. wield_name
                        .. " is not worn 10 ticks later (worn " .. tostring(worn_before)
                        .. " before, " .. tostring(worn_last) .. " after); last lines: "
                        .. setup_last_lines(3))
                    return
                end
            elseif level_stat ~= nil then
                -- ok is not a level: wait for the client's reading.
                local level_last = "unread"
                local level_landed = t.await({ level = function()
                    local read_result, reading = t.skill.read(level_stat)
                    if read_result ~= "ok" then
                        level_last = tostring(read_result) .. " " .. tostring(reading)
                        return false
                    end
                    level_last = "stated=" .. tostring(reading.stated)
                        .. " base_level=" .. tostring(reading.base_level)
                    return reading.stated and reading.base_level == level_wanted
                end, note = "setup: ::setlevel reaching the client" }, 10)
                if level_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. level_stat
                        .. " never read base_level " .. tostring(level_wanted)
                        .. " within 10 ticks (last reading: " .. level_last .. ")")
                    return
                end
            elseif string.match(cheat, "^%s*:*clearinv") then
                -- The same race, and the one cheat every generated
                -- setup list opens with: an unfinished ::clearinv also
                -- makes the NEXT give's before-count wrong.
                local cleared = t.await({ level = setup_backpack_empty,
                    note = "setup: ::clearinv reaching the client" }, 10)
                if cleared ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the"
                        .. " backpack still holds items 10 ticks later")
                    return
                end
            end
        end
        -- Every OTHER cheat (::setvar, a quest's own reset
        -- debugproc) has the same one-tick reply/effect gap with no
        -- single reading to wait on, so the loop ends on the tick
        -- boundary its last reply outran.  run()'s first row reads a
        -- client that has seen the setup, which is what `setup` means.
        t.ticks(1)
        t.settle()
    end
    return quest_run(t)
end
return QUEST
