local LEG_FROM = 2
local LEG_ONLY = false
local LEG_TILE = { 2336, 3810, 0 }
local QUEST = (function()
-- The Fremennik Isles -- relay file. Legs follow docs/quests/ladders/thefremennikisles.legs
-- (route order). Notes: docs/quests/ladders/thefremennikisles.notes.md.
-- Setup stages the quest START only: ::fremennikisles resets the quest vars, completes
-- Fremennik Trials and stands the player at Mord Gunnars (fris_debug.rs2).

local JESTER = { "frisd_jester_hat", "frisd_jester_top", "frisd_jester_legs", "frisd_jester_boots" }
local BUTTONS = { "frisd_talkbutton", "frisd_dancebutton", "frisd_jugglebutton", "frisd_skipbutton",
    "frisd_piebutton", "frisd_jigbutton", "frisd_bowbutton" }

-- Walk a conversation through every page; pick `choices` rows in order when options appear.
local function convo(t, name, choices)
    local i = 0
    for guard = 1, 160 do
        local r, k = t.chat.drain({ stop_at = "options" })
        if k == "options" then
            i = i + 1
            local ch = choices and choices[i]
            if ch == nil then
                t.check(name .. ".unexpected_options", false, "no choice scripted for options page " .. i .. ": " .. tostring(select(2, t.chat.options())))
                return
            end
            t.exec(name .. ".choose" .. i, t.chat.choose, ch)
        else
            t.check(name .. ".done", r == "ok", "drain " .. tostring(r) .. " kind=" .. tostring(k) .. " after " .. i .. " choice(s)")
            return
        end
    end
end

local function stage(t, want)
    local _, v = t.var.server("varb3311_fris_quest")
    t.check("var.stage=" .. tostring(want), v == want, "varb3311_fris_quest server=" .. tostring(v))
end

local function count(t, item)
    t.ticks(2)
    local _, c = t.inv.count(item)
    return c or 0
end

local function near(t, name, x, z, r)
    local _, tl = t.world.tile()
    local ok = tl ~= nil and math.abs(tl.x - x) <= r and math.abs(tl.z - z) <= r
    t.check(name, ok, "tile " .. tostring(tl and tl.x) .. "," .. tostring(tl and tl.z) .. "," .. tostring(tl and tl.level) .. " want within " .. r .. " of " .. x .. "," .. z)
end

-- The act: Mawnis shouts one instruction at a time (server var varp7215_fris_jester_want);
-- the player clicks that button on the frisd_jestertask panel.
local function perform(t, name)
    for guard = 1, 60 do
        local _, st = t.var.server("varp7214_fris_jester_step")
        if st ~= nil and st > 0 then break end
        t.chat.drain({ stop_at = "options" })
        t.ticks(2)
    end
    t.ticks(2)
    local _, w0 = t.ui.widget("frisd_jestertask:frisd_dancebutton")
    t.check(name .. ".panel_open", w0 ~= nil, "frisd_jestertask panel mounted: " .. tostring(w0))
    local done, n = false, 0
    for tick = 1, 260 do
        local _, step = t.var.server("varp7214_fris_jester_step")
        if step == 0 and n > 0 then done = true; break end
        local _, want = t.var.server("varp7215_fris_jester_want")
        if want ~= nil and want > 0 then
            n = n + 1
            local btn = BUTTONS[want]
            local _, w = t.ui.widget("frisd_jestertask:" .. btn)
            local pr = t.ui.invoke(w, 1)
            t.check(name .. ".press" .. n .. "." .. btn, pr == "ok", "invoked " .. btn .. " for want=" .. tostring(want))
        end
        t.ticks(1)
    end
    t.check(name .. ".act_over", done, "instructions pressed: " .. n)
end

return {
    id = "thefremennikisles",
    fixture = "fresh_lumbridge.ini",
    setup = {
        "::clearinv",
        "::setlevel mining 2",   -- the king asks 7 coal at Mining 2-54 (fris_shared.rs2 fris_ore_type); the guide lists Coal as brought
        "::fremennikisles",      -- quest start: Fremennik Trials done, Mord at 2644,3709
        "::give raw_tuna 1",     -- guide item requirement of talkToGjuki: Raw tuna
        "::give coal 7",         -- guide item requirement of bringOreToGjuki: Coal (Mining 2 variant)
        "::setlevel crafting 30",      -- leg 2: spinning yak hair into rope needs Crafting 30 (spinning.dbrow spin_yak_hair)
        "::setlevel woodcutting 56",   -- leg 2: splitting arctic pine logs needs Woodcutting 56 (fris_bridges.rs2 fris_stump_split)
        "::setlevel construction 20",  -- leg 2: repairing a bridge needs Construction 20 (fris_bridges.rs2 fris_bridge_repair)
        "::give knife 1",              -- leg 2: guide item "Knife" (repairBridge)
        "::give bronze_axe 1",         -- leg 2: guide item "Any axe" (split logs)
        "::give rune_scimitar 1",      -- leg 2: guide "Melee gear" (yaks drop the hair)
        "::give lobster 4",            -- leg 2: guide "Food" for the yak and troll fights
        "::setlevel attack 40",        -- leg 2: melee levels for the yak field (hp 10 died to a yak, run 1)
        "::setlevel strength 40",
        "::setlevel defence 30",
        "::setlevel hitpoints 40",
    },
    bind = {
        varp = "varb3311_fris_quest",
        constants = { not_started = 0, started = 5, king_met = 10, cat_fed = 20, need_ore = 30, ore_handed = 40,
            get_outfit = 50, spy1_briefed = 55, spy1_done = 60, help_mawnis = 90, complete = 340 },
        row = "quest_thefremennikisles",
        display = "The Fremennik Isles",
        points = 1,
    },
    legs = {
        { name = "mord_to_slug_report", run = function(t)
            t.ticks(3)
            t.expect("quest.stage.not_started", t.quest.expect_stage("not_started"))

            -- LEG 1 BEGIN: talkToMord
            t.exec("talkToMord", t.player.talk_to, "fris_r_ferryman_rellekka", 1)
            convo(t, "talkToMord-dialog", { "Yes.", "Can you ferry me to Jatizso?" })
            t.expect("quest.stage.started", t.quest.expect_stage("started"))
            t.ticks(4)
            near(t, "travelToJatizso", 2420, 3782, 6)

            -- Jatizso: dock -> outer city wall gate -> King's hall (door on the north side)
            t.player.walk_to(2412, 3796, 60)
            near(t, "walk-talkToGjuki", 2412, 3796, 1)
            t.exec("talkToGjuki-openCityGate", t.player.click_loc, "frisd_outer_city_wall_door_left", 1)
            t.ticks(2)
            t.player.walk_to(2407, 3807, 60)
            near(t, "walk-talkToGjuki-hall", 2407, 3807, 1)
            t.exec("talkToGjuki-openHallDoor", t.player.click_loc, "frisd_town_wall_door", 1)
            t.ticks(2)
            t.exec("talkToGjuki", t.player.talk_to, "fris_r_king", 1)
            convo(t, "talkToGjuki-dialog", {})
            t.expect("quest.stage.king_met", t.quest.expect_stage("king_met"))

            -- feed Hrafn the raw tuna (stage 10 -> 20)
            local cat = t.player.by_symbol("npc", "fris_r_kingscat")
            t.exec("feedHrafn", t.player.use_on, "raw_tuna", cat)
            convo(t, "feedHrafn-dialog", {})
            t.expect("quest.stage.cat_fed", t.quest.expect_stage("cat_fed"))

            t.exec("continueTalkingToGjuki", t.player.talk_to, "fris_r_king", 1)
            convo(t, "continueTalkingToGjuki-dialog", {})
            t.expect("quest.stage.need_ore", t.quest.expect_stage("need_ore"))

            local coins0 = count(t, "coins")
            t.exec("bringOreToGjuki", t.player.talk_to, "fris_r_king", 1)
            -- read the hand-in up to Thorkel's "takes lumps" box, then close it: the stage is 40 and
            -- the king's mission is a second talk (the guide's talkToGjukiAfterOre)
            t.exec("bringOreToGjuki-dialog", t.chat.drain, { stop_at = "mesbox" })
            t.check("bringOreToGjuki.box", t.chat.kind() == "mesbox", "page kind " .. tostring(t.chat.kind()) .. ": " .. tostring(select(2, t.chat.text())))
            local cr = t.chat.close()
            t.check("bringOreToGjuki-close", cr == "ok", "chat.close -> " .. tostring(cr) .. ", page kind now " .. tostring(t.chat.kind()))
            t.ticks(2)
            t.expect("quest.stage.ore_handed", t.quest.expect_stage("ore_handed"))
            t.exec("talkToGjukiAfterOre", t.player.talk_to, "fris_r_king", 1)
            convo(t, "talkToGjukiAfterOre-dialog", {})
            t.check("bringOreToGjuki.paid", count(t, "coins") == coins0 + 10000 and count(t, "coal") == 0,
                "coins " .. coins0 .. " -> " .. count(t, "coins") .. ", coal left " .. count(t, "coal"))
            t.expect("quest.stage.get_outfit", t.quest.expect_stage("get_outfit"))

            -- the jester outfit, from the chest behind the throne
            t.player.walk_to(2407, 3801, 20)
            near(t, "walk-getJesterOutfit", 2407, 3801, 1)
            t.exec("getJesterOutfit-open", t.player.click_loc, "fris_chest_closed", 1)
            t.ticks(2)
            t.exec("getJesterOutfit", t.player.click_loc, "fris_chest_open", 1)
            convo(t, "getJesterOutfit-dialog", { "Take the jester's hat.", "Take the jester's top.",
                "Take the jester's tights.", "Take the jester's boots.", "Leave the chest." })
            local got = {}
            for _, it in ipairs(JESTER) do got[#got + 1] = it .. "=" .. count(t, it) end
            t.check("getJesterOutfit.items", count(t, "frisd_jester_hat") == 1 and count(t, "frisd_jester_top") == 1
                and count(t, "frisd_jester_legs") == 1 and count(t, "frisd_jester_boots") == 1, table.concat(got, " "))

            -- back out of the hall and the gate to the dock, then ferry home
            t.exec("goto-returnToRellekkaFromJatizso", t.player.goto_tile, 2420, 3783, 0)
            t.exec("returnToRellekkaFromJatizso", t.player.talk_to, "fris_r_ferryman_izso", 1)
            convo(t, "returnToRellekkaFromJatizso-dialog", { "Can you ferry me to Rellekka?" })
            t.ticks(4)
            near(t, "returnToRellekka.landed", 2644, 3709, 6)
            t.exec("travelToNeitiznot", t.player.talk_to, "fris_r_ferry_rellikka", 1)
            convo(t, "travelToNeitiznot-dialog", { "Can you ferry me to Neitiznot?" })
            t.ticks(4)
            near(t, "travelToNeitiznot.landed", 2311, 3782, 6)

            -- Slug, in the outfit with empty hands
            t.exec("goto-talkToSlug", t.player.goto_tile, 2336, 3809, 0)
            for _, it in ipairs(JESTER) do
                t.exec("wear-" .. it, t.player.equip, it)
                t.ticks(1)
            end
            t.exec("talkToSlug", t.player.talk_to, "fris_spymaster", 1)
            convo(t, "talkToSlug-dialog", { "Free stuff please.", "I am ready." })
            t.expect("quest.stage.spy1_briefed", t.quest.expect_stage("spy1_briefed"))

            -- Mawnis's hall is entered from the east (notes)
            t.exec("goto-goSpyOnMawnis", t.player.goto_tile, 2341, 3799, 0)
            t.exec("goSpyOnMawnis", t.player.talk_to, "fris_r_burgher_crown", 1)
            convo(t, "goSpyOnMawnis-dialog", {})
            perform(t, "performForMawnis")
            t.ticks(6)
            convo(t, "performForMawnis-end", {})
            t.expect("quest.stage.spy1_done", t.quest.expect_stage("spy1_done"))

            t.exec("goto-tellSlugReport1", t.player.goto_tile, 2336, 3809, 0)
            local c1 = count(t, "coins")
            t.exec("tellSlugReport1", t.player.talk_to, "fris_spymaster", 1)
            convo(t, "tellSlugReport1-dialog", { "Yes I have.", "They will be ready in two days.",
                "Seventeen militia have been trained.", "There are two bridges to repair." })
            t.check("tellSlugReport1.paid", count(t, "coins") == c1 + 2500, "coins " .. c1 .. " -> " .. count(t, "coins"))
            t.expect("quest.stage.help_mawnis", t.quest.expect_stage("help_mawnis"))

            -- take the outfit off: stage 90 Mawnis wants it OFF (notes)
            for _, it in ipairs(JESTER) do
                t.exec("remove-" .. it, t.player.unequip, it)
                t.ticks(1)
            end
            local _, tl = t.world.tile()
            local _, sv = t.var.server("varb3311_fris_quest")
            t.check("leg.1.end", sv == 90, "tile " .. tl.x .. "," .. tl.z .. "," .. tl.level .. " stage=" .. tostring(sv)
                .. "; backpack: jester hat/top/tights/boots (unworn), coins, knife none")
            -- LEG 1 END
        end },

        { name = "mawnis_bridges", run = function(t)
            t.ticks(3)
            -- LEG 2 BEGIN: talkToMawnis
            t.exec("wield-sword", t.player.equip, "rune_scimitar")
            t.ticks(1)
            t.exec("goto-talkToMawnis", t.player.goto_tile, 2341, 3799, 0)
            t.exec("talkToMawnis", t.player.talk_to, "fris_r_burgher_crown", 1)
            convo(t, "talkToMawnis-dialog", {})
            stage(t, 100)

            -- rope: kill yaks for their hair, spin it at the wheel (2352,3794)
            t.exec("goto-yaks", t.player.goto_tile, 2322, 3796, 0)
            for i = 1, 12 do
                if count(t, "yak_hair") >= 8 then break end
                t.exec("yak" .. i .. "-attack", t.player.attack, "yak", 2, 20)
                t.exec("yak" .. i .. "-dead", t.npc.await_dead_engaged, 200, 3, { eat = { item = "lobster", below = 8 } })
                t.ticks(1)
                t.exec("yak" .. i .. "-hair", t.player.click_obj, "yak_hair", 3)
            end
            t.check("yakhair.8", count(t, "yak_hair") >= 8, "yak hair in the backpack: " .. count(t, "yak_hair"))
            t.exec("goto-spinWheel", t.player.goto_tile, 2352, 3796, 0)
            local wheel = t.player.by_symbol("loc", "iznot_spinning_wheel")
            for i = 1, 8 do
                t.ticks(4)
                if i > 1 then t.player.walk_to(2350 + (i % 2) * 2, 3796, 10); t.ticks(3) end  -- a step away so the next click has a walk flag to settle on
                t.exec("spinRope" .. i, t.player.use_on, "yak_hair", wheel)
                local mr = t.ui.await_open("skillmulti", 10)
                local cr, cell = t.ui.widget("skillmulti:a")
                t.check("spinRope" .. i .. ".menu", mr == "ok" and cr == "ok", "skillmulti menu=" .. tostring(mr) .. " cell=" .. tostring(cr))
                t.ui.invoke(cell, 1)
                t.exec("spinRope" .. i .. ".got", t.inv.await, "rope", i, 20)
            end
            t.ticks(2)

            -- bring the rope to Mawnis (stage 100 -> 110)
            t.exec("goto-talkToMawnisWithLogs", t.player.goto_tile, 2341, 3799, 0)
            t.exec("talkToMawnisWithLogs", t.player.talk_to, "fris_r_burgher_crown", 1)
            convo(t, "talkToMawnisWithLogs-dialog", {})
            stage(t, 110)

            -- 8 arctic pine logs, split on the stump
            local spots = { { 2314, 2315, 3788 }, { 2318, 2319, 3787 }, { 2321, 2322, 3786 }, { 2324, 2325, 3788 }, { 2327, 2328, 3790 }, { 2333, 2334, 3792 }, { 2337, 2338, 3791 }, { 2347, 2348, 3793 } }
            for i = 1, 8 do
                local sp = spots[i]
                t.exec("chop" .. i .. "-goto", t.player.goto_tile, sp[1], sp[3] + 1, 0)
                t.exec("chop" .. i, t.player.click_loc, "arctic_pine", 1, { at = { sp[2], sp[3] } })
                t.exec("chop" .. i .. ".got", t.inv.await, "arctic_pine_log", i, 150)
            end
            t.exec("goto-stump", t.player.goto_tile, 2342, 3806, 0)
            local stump = t.player.by_symbol("loc", "iznot_shield_stump")
            t.exec("splitLogs", t.player.use_on, "arctic_pine_log", stump)
            convo(t, "splitLogs-dialog", { "Split logs" })
            t.exec("splitLogs.got", t.inv.await, "arctic_pine_split", 8, 60)
            t.ticks(2)

            t.exec("goto-talkToMawnisAfterItems", t.player.goto_tile, 2341, 3799, 0)
            t.exec("talkToMawnisAfterItems", t.player.talk_to, "fris_r_burgher_crown", 1)
            convo(t, "talkToMawnisAfterItems-dialog", {})
            stage(t, 140)

            -- bridges
            t.exec("goto-repairBridge1", t.player.goto_tile, 2314, 3838, 0)
            t.exec("repairBridge1", t.player.click_loc, "frisb_bridge_3_s", 2)
            t.ticks(12)
            near(t, "repairBridge1.crossed", 2314, 3848, 3)
            t.exec("repairBridge1-back", t.player.click_loc, "frisb_bridge_3_n", 1)
            t.ticks(6)
            near(t, "repairBridge1-back.crossed", 2314, 3840, 3)
            t.exec("goto-repairBridge2", t.player.goto_tile, 2355, 3838, 0)
            t.exec("repairBridge2", t.player.click_loc, "frisb_bridge_4_s", 2)
            t.ticks(12)
            near(t, "repairBridge2.crossed", 2355, 3848, 3)
            t.exec("repairBridge2-back", t.player.click_loc, "frisb_bridge_4_n", 1)
            t.ticks(6)
            near(t, "repairBridge2-back.crossed", 2355, 3840, 3)

            t.exec("goto-talkToMawnisAfterRepair", t.player.goto_tile, 2341, 3799, 0)
            t.exec("talkToMawnisAfterRepair", t.player.talk_to, "fris_r_burgher_crown", 1)
            convo(t, "talkToMawnisAfterRepair-dialog", {})
            stage(t, 160)
            local _, tl = t.world.tile()
            local _, sv = t.var.server("varb3311_fris_quest")
            t.check("leg.2.end", sv == 160, "tile " .. tl.x .. "," .. tl.z .. "," .. tl.level .. " stage=" .. tostring(sv)
                .. "; backpack: 8 rope, 8 split logs, knife, axe, jester pieces, coins; rune scimitar worn")
            -- LEG 2 END
        end },
    },
}

end)()

if type(QUEST) == "table" and QUEST.legs ~= nil then
    local legs_quest = QUEST
    QUEST = { setup = legs_quest.setup, run = function(t)
        return t.core_legs_drive(legs_quest, { from = LEG_FROM, only = LEG_ONLY, tile = LEG_TILE })
    end }
end
if type(QUEST) ~= "table" or type(QUEST.run) ~= "function" then
    error("quest file did not return { run = function(t) ... end }"
        .. " or { legs = { { name =, run = function(t) ... end }, ... } }")
end
local quest_setup = QUEST.setup
-- A setup that is not a list of cheat lines is a setup nobody reads:
-- refuse it rather than run the quest against an unstated world.
if quest_setup ~= nil and type(quest_setup) ~= "table" then
    error("quest file's setup is a " .. type(quest_setup)
        .. ", not a table of cheat lines")
end
-- A checkpoint run resumes a player who already went through setup
-- (and legs 1..K-1): the setup list is NOT run again.
if LEG_FROM and LEG_FROM > 1 then
    quest_setup = nil
end
local quest_run = QUEST.run
QUEST.run = function(t)
    -- WAIT FOR THE LOGIN GRANT before the first setup cheat.
    --
    -- The backpack a fixture starts with is not in the fixture: the
    -- containers are adopted EMPTY (torirs_server_world.c, "what goes
    -- in them the first time a character connects is content's") and
    -- content's [login,_] -> [proc,newplayer_inv] fills them on a
    -- later tick than the one this script starts on.  Measured
    -- 2026-09-19 (build/quest_gate/closer_setup2 row 1,
    -- closer_setup3): `::clearinv` issued on the first frame answers
    -- "Cleared 0 item(s).", the fourteen tutorial slots land behind
    -- it, and a `::give` before the grant is overwritten by it -- a
    -- setup list that answered `ok` three times and left the world it
    -- promised in none of them.  A fixed `t.ticks(n)` does not fix it
    -- (the grant landed on tick 1 in one run and after three cheats in
    -- the next); the arrival itself is the signal, so wait for it.
    --
    -- Bounded, and proceeding either way: a fixture whose character
    -- really does hold nothing pays the budget and runs its setup
    -- anyway, rather than failing a quest over an empty backpack.
    t.await({ level = function()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return true
            end
        end
        return false
    end, note = "setup: the login grant" }, 10)
    t.settle()
    -- A CHEAT'S REPLY OUTRUNS ITS EFFECT by exactly one server tick.
    --
    -- t.cheat waits for the reply line (core.lua: QD.cheat ->
    -- msg.await), and the server SAYS `Gave 3 x Egg (1944).` from
    -- inside the ladder branch itself, while the backpack the same
    -- branch just wrote reaches the client in the container
    -- listener's UPDATE_INV at the END of that tick
    -- (torirs_server_world.c, the ::give branch: `the backpack's
    -- listener sends an UPDATE_INV without this branch knowing a
    -- packet exists`).  So the setup loop used to hand run() a client
    -- that had heard about the items and not yet received them, and
    -- every quest whose first rows read t.inv.count saw an empty
    -- backpack from a setup that had answered `ok` three times.
    -- Measured 2026-09-21 (build/quest_gate/lag_probe): row `lag.t0`
    -- FAIL `egg: absent`, row `lag.t1` -- one t.ticks(1) later --
    -- PASS `3`.  Two seam fixers reported it as `::give from setup
    -- lands nothing` (docs/QUEST_AUTHORING.md trap 23).
    --
    -- A ::give is therefore not done when it answers: it is done when
    -- the CLIENT can count the items, which is also the only check
    -- that catches the ladder's own silent misses -- `::give
    -- nosuchitemname` and an ambiguous name both `say()` their
    -- complaint and return RAN, i.e. `ok`, having given nothing
    -- (same file, `No item named '%s'.` / `Which %s? %s`).  Each one
    -- is now a FAIL row named after the cheat, exactly like a cheat
    -- that answered no_row.
    local function setup_give(text)
        local name, count = string.match(text, "^%s*:*give%s+([%w_]+)%s*(%d*)")
        if not name then
            return nil
        end
        local wanted = tonumber(count)
        if not wanted or wanted < 1 then
            wanted = 1
        end
        return name, wanted
    end
    -- Name-free fingerprint of the backpack: every slot's count, plus
    -- one per occupied slot so an item ARRIVING in an empty slot
    -- moves it too.  What the fallback below watches when a ::give
    -- names something this client cannot count.
    local function setup_backpack_mark()
        local mark = 0
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                mark = mark + cell.count + 1
            end
        end
        return mark
    end
    local function setup_backpack_empty()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return false
            end
        end
        return true
    end
    -- `::setlevel <stat> <level>` -> stat, level; nil for any other line.
    -- A line that STARTS as a setlevel (the engine's own strncmp prefix)
    -- but does not parse is ("", nil): the engine answers ok to it
    -- and sets nothing.
    local function setup_setlevel(text)
        if not string.match(text, "^%s*:*setlevel") then
            return nil
        end
        local stat, level = string.match(text, "^%s*:*setlevel%s+(%a[%w_]*)%s+(%d+)%s*$")
        if not stat then
            return "", nil
        end
        return stat, tonumber(level)
    end
    -- `::wield <item>` -> item; nil for any other line.  The cheat
    -- answers once the synthesized Wield click is SENT (seam pass 29:
    -- it used to take only an obj id, print its Usage line for a name
    -- and answer ok -- arthur fought Mordred unarmed behind a green
    -- setup), and content may still refuse the wield (a level, a
    -- quest), so the line is done only when the WORN container holds
    -- the item (QD.ui._worn_count, ui.lua).
    local function setup_wield(text)
        return string.match(text, "^%s*:*wield%s+([%w_]+)%s*$")
    end
    local function setup_last_lines(n)
        local lines_result, rows = t.msg.last(n)
        if lines_result ~= "ok" or type(rows) ~= "table" then
            return "(no chat lines)"
        end
        local texts = {}
        for i = 1, #rows do
            texts[#texts + 1] = "'" .. tostring(rows[i].text) .. "'"
        end
        return table.concat(texts, " / ")
    end
    local function setup_failed(cheat, why)
        t.step("setup." .. cheat, "FAIL",
            why .. " -- the world this quest assumes was never stated")
        t.finish(1)
    end
    if type(quest_setup) == "table" then
        for _, cheat in ipairs(quest_setup) do
            -- Counted BEFORE the cheat: a setup list that gives the
            -- same item twice, or gives one the login grant already
            -- put there, is waiting for an INCREASE, not for a total.
            local give_name, give_count = setup_give(cheat)
            local before = nil
            local before_mark = nil
            if give_name then
                local count_result, count_total = t.inv.count(give_name)
                if count_result == "ok" then
                    before = count_total
                else
                    -- A name this client cannot resolve to an obj: the
                    -- server's own cheat_obj_from_name is fuzzy and may
                    -- still have matched one -- but `::give
                    -- nosuchitemname` reaches the SAME `ok` (it say()s
                    -- `No item named` and returns RAN), so the whole
                    -- backpack is watched for any movement instead of
                    -- taking the cheat at its word.
                    before_mark = setup_backpack_mark()
                end
            end
            local wield_name = setup_wield(cheat)
            local worn_before = nil
            if wield_name then
                local worn_result, worn_count = t.ui._worn_count(wield_name)
                if worn_result ~= "ok" then
                    setup_failed(cheat, "cannot read the worn container for "
                        .. wield_name .. " (" .. tostring(worn_result) .. " "
                        .. tostring(worn_count) .. "), so a wield could never be"
                        .. " proved")
                    return
                end
                worn_before = worn_count
            elseif string.match(cheat, "^%s*:*wield") then
                setup_failed(cheat, "not `::wield <item_name>`: a line the"
                    .. " read-back cannot name is a wield nobody can prove")
                return
            end
            local level_stat, level_wanted = setup_setlevel(cheat)
            if level_stat == "" then
                setup_failed(cheat, "not `::setlevel <stat name> <level>`: the"
                    .. " engine answers ok to it and sets nothing, and a numeric"
                    .. " stat id cannot be read back to prove it landed")
                return
            end
            local setup_result, setup_detail = t.cheat(cheat)
            if setup_result ~= "ok" then
                setup_failed(cheat, "setup cheat answered "
                    .. tostring(setup_result)
                    .. " (" .. tostring(setup_detail) .. "); last lines: "
                    .. setup_last_lines(2))
                return
            end
            if before ~= nil then
                local landed = t.inv.await(give_name, before + give_count, 10)
                if landed ~= "ok" then
                    local after_result, after_total = t.inv.count(give_name)
                    -- Short of the count asked for is the BACKPACK's
                    -- limit speaking (`Gave 21 x Egg (1944), 7 did not
                    -- fit.`), not a setup that did not happen; nothing
                    -- arriving at all is.
                    if after_result ~= "ok" or after_total <= before then
                        setup_failed(cheat, "the cheat answered ok and no "
                            .. give_name
                            .. " reached the backpack within 10 ticks (held "
                            .. tostring(before) .. " before, "
                            .. tostring(after_total) .. " after)")
                        return
                    end
                end
            elseif before_mark ~= nil then
                local moved = t.await({ level = function()
                    return setup_backpack_mark() ~= before_mark
                end, note = "setup: ::give reaching the backpack" }, 10)
                if moved ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the backpack"
                        .. " did not change within 10 ticks (" .. give_name
                        .. " is not an obj this client can count, so every"
                        .. " slot was watched instead)")
                    return
                end
            elseif worn_before ~= nil then
                local worn_last = worn_before
                local worn_landed = t.await({ level = function()
                    local read_result, reading = t.ui._worn_count(wield_name)
                    if read_result == "ok" then
                        worn_last = reading
                    end
                    return read_result == "ok" and reading > worn_before
                end, note = "setup: ::wield reaching the worn container" }, 10)
                if worn_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. wield_name
                        .. " is not worn 10 ticks later (worn " .. tostring(worn_before)
                        .. " before, " .. tostring(worn_last) .. " after); last lines: "
                        .. setup_last_lines(3))
                    return
                end
            elseif level_stat ~= nil then
                -- ok is not a level: wait for the client's reading.
                local level_last = "unread"
                local level_landed = t.await({ level = function()
                    local read_result, reading = t.skill.read(level_stat)
                    if read_result ~= "ok" then
                        level_last = tostring(read_result) .. " " .. tostring(reading)
                        return false
                    end
                    level_last = "stated=" .. tostring(reading.stated)
                        .. " base_level=" .. tostring(reading.base_level)
                    return reading.stated and reading.base_level == level_wanted
                end, note = "setup: ::setlevel reaching the client" }, 10)
                if level_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. level_stat
                        .. " never read base_level " .. tostring(level_wanted)
                        .. " within 10 ticks (last reading: " .. level_last .. ")")
                    return
                end
            elseif string.match(cheat, "^%s*:*clearinv") then
                -- The same race, and the one cheat every generated
                -- setup list opens with: an unfinished ::clearinv also
                -- makes the NEXT give's before-count wrong.
                local cleared = t.await({ level = setup_backpack_empty,
                    note = "setup: ::clearinv reaching the client" }, 10)
                if cleared ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the"
                        .. " backpack still holds items 10 ticks later")
                    return
                end
            end
        end
        -- Every OTHER cheat (::setvar, a quest's own reset
        -- debugproc) has the same one-tick reply/effect gap with no
        -- single reading to wait on, so the loop ends on the tick
        -- boundary its last reply outran.  run()'s first row reads a
        -- client that has seen the setup, which is what `setup` means.
        t.ticks(1)
        t.settle()
    end
    return quest_run(t)
end
return QUEST
