local LEG_FROM = nil
local LEG_ONLY = false
local LEG_TILE = nil
local QUEST = (function()
return {
    id = "rt_dbg3", fixture = "fresh_lumbridge.ini", setup = {},
    run = function(t)
        t.ticks(3)
        t.cheat("::royaltroublerun", true)
        t.ticks(4)
        t.check("royaltroublerun", select(1, t.msg.expect("royaltroublerun OK")) == "ok", "debugproc stage walk reports OK")
        t.finish(0)
    end,
}

end)()

if type(QUEST) == "table" and QUEST.legs ~= nil then
    local legs_quest = QUEST
    QUEST = { setup = legs_quest.setup, run = function(t)
        return t.core_legs_drive(legs_quest, { from = LEG_FROM, only = LEG_ONLY, tile = LEG_TILE })
    end }
end
if type(QUEST) ~= "table" or type(QUEST.run) ~= "function" then
    error("quest file did not return { run = function(t) ... end }"
        .. " or { legs = { { name =, run = function(t) ... end }, ... } }")
end
local quest_setup = QUEST.setup
-- A setup that is not a list of cheat lines is a setup nobody reads:
-- refuse it rather than run the quest against an unstated world.
if quest_setup ~= nil and type(quest_setup) ~= "table" then
    error("quest file's setup is a " .. type(quest_setup)
        .. ", not a table of cheat lines")
end
-- A checkpoint run resumes a player who already went through setup
-- (and legs 1..K-1): the setup list is NOT run again.
if LEG_FROM and LEG_FROM > 1 then
    quest_setup = nil
end
-- --script mode: no setup list, nothing to wrap.
if quest_setup == nil or next(quest_setup) == nil then
    return QUEST
end
local quest_run = QUEST.run
QUEST.run = function(t)
    -- WAIT FOR THE LOGIN GRANT before the first setup cheat.
    --
    -- The backpack a fixture starts with is not in the fixture: the
    -- containers are adopted EMPTY (torirs_server_world.c, "what goes
    -- in them the first time a character connects is content's") and
    -- content's [login,_] -> [proc,newplayer_inv] fills them on a
    -- later tick than the one this script starts on.  Measured
    -- 2026-09-19 (build/quest_gate/closer_setup2 row 1,
    -- closer_setup3): `::clearinv` issued on the first frame answers
    -- "Cleared 0 item(s).", the fourteen tutorial slots land behind
    -- it, and a `::give` before the grant is overwritten by it -- a
    -- setup list that answered `ok` three times and left the world it
    -- promised in none of them.  A fixed `t.ticks(n)` does not fix it
    -- (the grant landed on tick 1 in one run and after three cheats in
    -- the next); the arrival itself is the signal, so wait for it.
    --
    -- Bounded, and proceeding either way: a fixture whose character
    -- really does hold nothing pays the budget and runs its setup
    -- anyway, rather than failing a quest over an empty backpack.
    t.await({ level = function()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return true
            end
        end
        return false
    end, note = "setup: the login grant" }, 10)
    t.settle()
    -- A CHEAT'S REPLY OUTRUNS ITS EFFECT by exactly one server tick.
    --
    -- t.cheat waits for the reply line (core.lua: QD.cheat ->
    -- msg.await), and the server SAYS `Gave 3 x Egg (1944).` from
    -- inside the ladder branch itself, while the backpack the same
    -- branch just wrote reaches the client in the container
    -- listener's UPDATE_INV at the END of that tick
    -- (torirs_server_world.c, the ::give branch: `the backpack's
    -- listener sends an UPDATE_INV without this branch knowing a
    -- packet exists`).  So the setup loop used to hand run() a client
    -- that had heard about the items and not yet received them, and
    -- every quest whose first rows read t.inv.count saw an empty
    -- backpack from a setup that had answered `ok` three times.
    -- Measured 2026-09-21 (build/quest_gate/lag_probe): row `lag.t0`
    -- FAIL `egg: absent`, row `lag.t1` -- one t.ticks(1) later --
    -- PASS `3`.  Two seam fixers reported it as `::give from setup
    -- lands nothing` (docs/QUEST_AUTHORING.md trap 23).
    --
    -- A ::give is therefore not done when it answers: it is done when
    -- the CLIENT can count the items, which is also the only check
    -- that catches the ladder's own silent misses -- `::give
    -- nosuchitemname` and an ambiguous name both `say()` their
    -- complaint and return RAN, i.e. `ok`, having given nothing
    -- (same file, `No item named '%s'.` / `Which %s? %s`).  Each one
    -- is now a FAIL row named after the cheat, exactly like a cheat
    -- that answered no_row.
    local function setup_give(text)
        local name, count = string.match(text, "^%s*:*give%s+([%w_]+)%s*(%d*)")
        if not name then
            return nil
        end
        local wanted = tonumber(count)
        if not wanted or wanted < 1 then
            wanted = 1
        end
        return name, wanted
    end
    -- Name-free fingerprint of the backpack: every slot's count, plus
    -- one per occupied slot so an item ARRIVING in an empty slot
    -- moves it too.  What the fallback below watches when a ::give
    -- names something this client cannot count.
    local function setup_backpack_mark()
        local mark = 0
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                mark = mark + cell.count + 1
            end
        end
        return mark
    end
    local function setup_backpack_empty()
        for slot = 0, 27 do
            local slot_result, cell = t.inv.slot(slot)
            if slot_result == "ok" and cell.name ~= "" and cell.count ~= 0 then
                return false
            end
        end
        return true
    end
    -- `::setlevel <stat> <level>` -> stat, level; nil for any other line.
    -- A line that STARTS as a setlevel (the engine's own strncmp prefix)
    -- but does not parse is ("", nil): the engine answers ok to it
    -- and sets nothing.
    local function setup_setlevel(text)
        if not string.match(text, "^%s*:*setlevel") then
            return nil
        end
        local stat, level = string.match(text, "^%s*:*setlevel%s+(%a[%w_]*)%s+(%d+)%s*$")
        if not stat then
            return "", nil
        end
        return stat, tonumber(level)
    end
    -- `::wield <item>` -> item; nil for any other line.  The cheat
    -- answers once the synthesized Wield click is SENT (seam pass 29:
    -- it used to take only an obj id, print its Usage line for a name
    -- and answer ok -- arthur fought Mordred unarmed behind a green
    -- setup), and content may still refuse the wield (a level, a
    -- quest), so the line is done only when the WORN container holds
    -- the item (QD.ui._worn_count, ui.lua).
    local function setup_wield(text)
        return string.match(text, "^%s*:*wield%s+([%w_]+)%s*$")
    end
    local function setup_last_lines(n)
        local lines_result, rows = t.msg.last(n)
        if lines_result ~= "ok" or type(rows) ~= "table" then
            return "(no chat lines)"
        end
        local texts = {}
        for i = 1, #rows do
            texts[#texts + 1] = "'" .. tostring(rows[i].text) .. "'"
        end
        return table.concat(texts, " / ")
    end
    local function setup_failed(cheat, why)
        t.step("setup." .. cheat, "FAIL",
            why .. " -- the world this quest assumes was never stated")
        t.finish(1)
    end
    if type(quest_setup) == "table" then
        for _, cheat in ipairs(quest_setup) do
            -- Counted BEFORE the cheat: a setup list that gives the
            -- same item twice, or gives one the login grant already
            -- put there, is waiting for an INCREASE, not for a total.
            local give_name, give_count = setup_give(cheat)
            local before = nil
            local before_mark = nil
            if give_name then
                local count_result, count_total = t.inv.count(give_name)
                if count_result == "ok" then
                    before = count_total
                else
                    -- A name this client cannot resolve to an obj: the
                    -- server's own cheat_obj_from_name is fuzzy and may
                    -- still have matched one -- but `::give
                    -- nosuchitemname` reaches the SAME `ok` (it say()s
                    -- `No item named` and returns RAN), so the whole
                    -- backpack is watched for any movement instead of
                    -- taking the cheat at its word.
                    before_mark = setup_backpack_mark()
                end
            end
            local wield_name = setup_wield(cheat)
            local worn_before = nil
            if wield_name then
                local worn_result, worn_count = t.ui._worn_count(wield_name)
                if worn_result ~= "ok" then
                    setup_failed(cheat, "cannot read the worn container for "
                        .. wield_name .. " (" .. tostring(worn_result) .. " "
                        .. tostring(worn_count) .. "), so a wield could never be"
                        .. " proved")
                    return
                end
                worn_before = worn_count
            elseif string.match(cheat, "^%s*:*wield") then
                setup_failed(cheat, "not `::wield <item_name>`: a line the"
                    .. " read-back cannot name is a wield nobody can prove")
                return
            end
            local level_stat, level_wanted = setup_setlevel(cheat)
            if level_stat == "" then
                setup_failed(cheat, "not `::setlevel <stat name> <level>`: the"
                    .. " engine answers ok to it and sets nothing, and a numeric"
                    .. " stat id cannot be read back to prove it landed")
                return
            end
            local setup_result, setup_detail = t.cheat(cheat)
            if setup_result ~= "ok" then
                setup_failed(cheat, "setup cheat answered "
                    .. tostring(setup_result)
                    .. " (" .. tostring(setup_detail) .. "); last lines: "
                    .. setup_last_lines(2))
                return
            end
            if before ~= nil then
                local landed = t.inv.await(give_name, before + give_count, 10)
                if landed ~= "ok" then
                    local after_result, after_total = t.inv.count(give_name)
                    -- Short of the count asked for is the BACKPACK's
                    -- limit speaking (`Gave 21 x Egg (1944), 7 did not
                    -- fit.`), not a setup that did not happen; nothing
                    -- arriving at all is.
                    if after_result ~= "ok" or after_total <= before then
                        setup_failed(cheat, "the cheat answered ok and no "
                            .. give_name
                            .. " reached the backpack within 10 ticks (held "
                            .. tostring(before) .. " before, "
                            .. tostring(after_total) .. " after)")
                        return
                    end
                end
            elseif before_mark ~= nil then
                local moved = t.await({ level = function()
                    return setup_backpack_mark() ~= before_mark
                end, note = "setup: ::give reaching the backpack" }, 10)
                if moved ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the backpack"
                        .. " did not change within 10 ticks (" .. give_name
                        .. " is not an obj this client can count, so every"
                        .. " slot was watched instead)")
                    return
                end
            elseif worn_before ~= nil then
                local worn_last = worn_before
                local worn_landed = t.await({ level = function()
                    local read_result, reading = t.ui._worn_count(wield_name)
                    if read_result == "ok" then
                        worn_last = reading
                    end
                    return read_result == "ok" and reading > worn_before
                end, note = "setup: ::wield reaching the worn container" }, 10)
                if worn_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. wield_name
                        .. " is not worn 10 ticks later (worn " .. tostring(worn_before)
                        .. " before, " .. tostring(worn_last) .. " after); last lines: "
                        .. setup_last_lines(3))
                    return
                end
            elseif level_stat ~= nil then
                -- ok is not a level: wait for the client's reading.
                local level_last = "unread"
                local level_landed = t.await({ level = function()
                    local read_result, reading = t.skill.read(level_stat)
                    if read_result ~= "ok" then
                        level_last = tostring(read_result) .. " " .. tostring(reading)
                        return false
                    end
                    level_last = "stated=" .. tostring(reading.stated)
                        .. " base_level=" .. tostring(reading.base_level)
                    return reading.stated and reading.base_level == level_wanted
                end, note = "setup: ::setlevel reaching the client" }, 10)
                if level_landed ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and " .. level_stat
                        .. " never read base_level " .. tostring(level_wanted)
                        .. " within 10 ticks (last reading: " .. level_last .. ")")
                    return
                end
            elseif string.match(cheat, "^%s*:*clearinv") then
                -- The same race, and the one cheat every generated
                -- setup list opens with: an unfinished ::clearinv also
                -- makes the NEXT give's before-count wrong.
                local cleared = t.await({ level = setup_backpack_empty,
                    note = "setup: ::clearinv reaching the client" }, 10)
                if cleared ~= "ok" then
                    setup_failed(cheat, "the cheat answered ok and the"
                        .. " backpack still holds items 10 ticks later")
                    return
                end
            end
        end
        -- Every OTHER cheat (::setvar, a quest's own reset
        -- debugproc) has the same one-tick reply/effect gap with no
        -- single reading to wait on, so the loop ends on the tick
        -- boundary its last reply outran.  run()'s first row reads a
        -- client that has seen the setup, which is what `setup` means.
        t.ticks(1)
        t.settle()
    end
    return quest_run(t)
end
return QUEST
