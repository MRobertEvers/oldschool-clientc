D3D9 debug runtime, the x86 build that loads on Windows XP.

WHAT

  d3d9d.dll       3,083,608 bytes   md5 929e0ccfde6e2e5cd558ce6fd33eee48
  d3dx9d_33.dll   3,795,800 bytes   md5 032dafa1733136b836f18f0ed39291a3

Both lifted from DXSDK_Jun10.exe (DirectX SDK, June 2010), from the cabinet at
offset 391168, path "DXSDK\Developer Runtime\x86\".

WHY THESE TWO FILES AND NOT THE FIRST ONES THE SDK HANDS YOU

That cabinet holds THREE x86 builds of d3d9d.dll, all under the same internal
path and name. `expand.exe` yields the first of them, and the first one does
not work on XP:

  2,650,456   imports dwmapi.dll                         -> Vista+
  2,719,064   imports API-MS-Win-Core-*, dwmapi.dll       -> Windows 7+
  3,083,608   imports d3d8thk.dll, d3dx9d_33.dll          -> XP           <- this one

dwmapi.dll is the Desktop Window Manager and does not exist on XP, so the first
build fails to load and Direct3D silently falls back to the retail runtime --
which looks exactly like "this card cannot do D3D9". Tell them apart by the PE
import table, not by size or date.

Picking a specific one needs 7-Zip: the cabinet is LZX-compressed, which
`expand` cannot address by index and Python cannot decode. The 7-Zip x64
installer wants elevation; `msiexec /a 7z<ver>-x64.msi /qn TARGETDIR=<dir>`
extracts 7z.exe without it. Then:

  7z x <cab> -o<dir> -aou "DXSDK\Developer Runtime\x86\d3d9d.dll"

-aou auto-renames the duplicates to d3d9d.dll / d3d9d_1.dll / d3d9d_2.dll.

HOW TO INSTALL -- BESIDE THE EXE, NOT IN system32

Put BOTH files in the same directory as torirs.exe, and set

  HKLM\SOFTWARE\Microsoft\Direct3D\LoadDebugRuntime = 1   (REG_DWORD)

The application directory leads the default DLL search order, so d3d9.dll finds
d3d9d.dll there and d3d9d.dll finds d3dx9d_33.dll beside it.

In system32 both fail with err 999. From a private directory d3dx9d_33.dll
loads on its own, and d3d9d.dll loads only under LOAD_WITH_ALTERED_SEARCH_PATH
-- i.e. only when the loader looks next to the DLL for its dependency. Keeping
the pair together is the whole trick, and it means no system-wide change:
uninstalling is deleting two files.

WHAT IT BUYS

D3DQUERYTYPE_RESOURCEMANAGER, which the retail runtime refuses. That query
returns D3DRESOURCESTATS per resource type -- bThrashing, NumEvicts,
NumVidCreates, WorkingSetBytes -- i.e. whether MANAGED textures are thrashing
against local VRAM. TORIRS_D3D9_VRAM=<frame> in this client prints it.

It does NOT add hardware capability. On the GeForce4 MX 440 the TIMESTAMP,
TIMESTAMPFREQ, TIMESTAMPDISJOINT and OCCLUSION queries are unsupported by the
driver and stay unsupported with the debug runtime loaded, so there is no GPU
timing to be had on that card by this route.

DO NOT LEAVE IT INSTALLED WHILE BENCHMARKING. The debug runtime validates
aggressively and is slower; numbers taken with these two files present are not
comparable to retail ones.

LICENCE

Microsoft DirectX SDK "Developer Runtime". Development use; not part of the
redistributable runtime. Vendored here for the same reason lib/ vendors the
toolchains -- so the lane is reproducible without a 572 MB download -- but it
is Microsoft's binary, not this project's.
