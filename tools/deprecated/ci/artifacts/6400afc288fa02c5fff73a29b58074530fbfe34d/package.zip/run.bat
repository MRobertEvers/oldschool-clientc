@echo off
echo stub CI run succeeded.
